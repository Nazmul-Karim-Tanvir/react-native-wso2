import mime from 'mime';
import * as ImageManipulator from "expo-image-manipulator";
import * as DeviceInfo from "expo-device";
import * as Application from 'expo-application';
import * as SecureStore from 'expo-secure-store';
import {Image, Platform} from 'react-native';
import AsyncStorage from "@react-native-async-storage/async-storage";
import { AppType } from '../apiRequests/base-url-config';
import * as Sharing from 'expo-sharing';
import * as FileSystem from "expo-file-system";
import { getRandomValues } from "expo-crypto";

export const saveAndShareCRMData = async (crmData) => {
    try {
      // Convert payload to JSON string
      const jsonString = JSON.stringify(crmData, null, 2);
  
      // Save to a temporary file
      const fileUri = FileSystem.documentDirectory + "crmData.txt";
      await FileSystem.writeAsStringAsync(fileUri, jsonString, {
        encoding: FileSystem.EncodingType.UTF8,
      });
  
      // Check if sharing is available
      const isAvailable = await Sharing.isAvailableAsync();
      if (!isAvailable) {
        console.warn("Sharing is not available on this platform.");
        return;
      }
  
      // Open share dialog
      await Sharing.shareAsync(fileUri);
      console.log("✅ CRM data saved and ready to share:", fileUri);
    } catch (error) {
      console.error("❌ Error saving or sharing CRM data:", error);
    }
  };

export function uriToFile(uri) {
    console.log("URI to File: ", uri)
    const fileName = uri.split('/').pop(); // Extract file name
    const fileType = mime.getType(uri) || 'image/jpeg';

    return {
        uri,
        name: fileName,
        type: fileType,
    };
}


// export async function uriToFile(uri) {
//     const fileInfo = await FileSystem.getInfoAsync(uri);
//     if (!fileInfo.exists) {
//       throw new Error('File does not exist: ' + uri);
//     }
//     //console.log("file info",fileInfo)

//     const fileName = uri.split('/').pop();
//     const fileType = mime.getType(uri) || 'image/jpeg';

//     return {
//       uri,
//       name: fileName,
//       type: fileType,
//     };
//   }


// export async function uriToBase64(uri) {
//     if(uri === ""){
//         console.log("No Image Found...1");
//         return uri;
//     }
//     else {
//         const ManipulatedImage = await ImageManipulator.manipulateAsync(uri, [], {base64: true});
//         return 'data:image/jpeg;base64,' + ManipulatedImage?.base64;
//     }
// }


export async function uriToBase64(uri) {
    try {
      if (!uri) return "";
  
      let localUri = uri;
  
      // If the image is remote (https://...), download it first
      if (uri.startsWith("http")) {
        const fileName = uri.split("/").pop();
        const localPath = FileSystem.documentDirectory + fileName;
        const downloadResumable = await FileSystem.downloadAsync(uri, localPath);
        localUri = downloadResumable.uri;
      }
  
      const ManipulatedImage = await ImageManipulator.manipulateAsync(localUri, [], { base64: true });
      return "data:image/jpeg;base64," + ManipulatedImage.base64;
    } catch (error) {
      console.error("uriToBase64 failed:", error);
      return "";
    }
  }

export const cropImage = async (imageUri, xPercent=1,yPercent=1,widthPert=1,heightPert=1) => {
    try {
        // const ImageSizeData = await new Promise((resolve, reject) => {
        //     Image.getSize(imageUri.uri, (width, height) => resolve({ width, height }), reject);
        // });
        //
        // imageUri = await ImageManipulator.manipulateAsync(
        //     imageUri,
        //     [{ resize: {width: Platform.OS === "android" ? 1000 : ImageSizeData?.width} }]
        // );
        // Get image dimensions
        const { width, height } = imageUri;

       // Ensure crop dimensions are within bounds
        let cropWidth = width * widthPert;
        let cropHeight = height * heightPert;
        const cropOriginX = width * xPercent;
        const cropOriginY = height * yPercent;

        if (cropOriginX + cropWidth > width) {
            cropWidth = width - cropOriginX;
        }
        if (cropOriginY + cropHeight > height) {
            cropHeight = height - cropOriginY;
        }

        const cropRegion = {
            originX: cropOriginX, // Start from the left
            originY: cropOriginY, // Start from the top
            width: cropWidth, // Full width
            height: cropHeight, // Crop the top 25% of the height
        };
        console.log(cropRegion);

        return await ImageManipulator.manipulateAsync(
            imageUri.uri,
            [{crop: cropRegion}],
            {base64: true}
        );

    } catch (error) {
        console.error("Error cropping image:", error);
    }
};

// Custom UUID v4 generator using expo-crypto
export const generateUUIDv4= async()=> {
  try {
    const random = new Uint8Array(16);
    getRandomValues(random); // Use expo-crypto's getRandomValues
    // Set version (4) and variant (8, 9, a, or b) per RFC 4122
    random[6] = (random[6] & 0x0f) | 0x40; // Version 4
    random[8] = (random[8] & 0x3f) | 0x80; // Variant 10xx
    const bytes = [...random].map(b => b.toString(16).padStart(2, '0'));
    return [
      bytes.slice(0, 4).join(''),
      bytes.slice(4, 6).join(''),
      bytes.slice(6, 8).join(''),
      bytes.slice(8, 10).join(''),
      bytes.slice(10, 16).join(''),
    ].join('-');
  } catch (error) {
    console.error('Failed to generate UUID:', error);
    // Fallback to simpler random ID
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}

// Helper to get or create a persistent device ID
export const getOrCreateDeviceId = async (DEVICE_ID_KEY = 'uniqueDeviceId') => {
  try {
    // Retrieve deviceId from SecureStore
    let deviceId = await SecureStore.getItemAsync(DEVICE_ID_KEY);
    console.log('Retrieved deviceId from SecureStore:', deviceId); // Debug log

    if (!deviceId) {
      if (Platform.OS === 'android' && Application.getAndroidId()) {
        deviceId = Application.getAndroidId(); // Stable across reinstalls unless factory reset
      } else if (Platform.OS === 'ios') {
        deviceId = await Application.getIosIdForVendorAsync(); // Stable until all vendor apps are uninstalled
      } else {
        deviceId = generateUUIDv4(); // Use UUID v4 generator
      }
      console.log('Generated deviceId:', deviceId); // Debug log
      // Ensure deviceId is a string before storing
      await SecureStore.setItemAsync(DEVICE_ID_KEY, String(deviceId));
    }

    return String(deviceId); // Ensure the return value is a string
  } catch (error) {
    console.error('Failed to get or create device ID:', error);
    const fallbackId = generateUUIDv4();
    console.log('Fallback deviceId:', fallbackId); // Debug log
    return fallbackId;
  }
};

export const DeviceInformation = async () => {
  const deviceId = await getOrCreateDeviceId();
  console.log("Device ID:", deviceId);
    return JSON.stringify({
        AppType:AppType,
        deviceId : deviceId,
        isBrowser: false,
        ModelName: DeviceInfo.modelName,
        // Brand: DeviceInfo.brand,
        // DeviceName: DeviceInfo.deviceName,
        // DeviceType: DeviceInfo.deviceType,
        OSName: DeviceInfo.osName,
        OSVersion: DeviceInfo.osVersion,
        Manufacturer: DeviceInfo.manufacturer,
        // Location: JSON.parse(await AsyncStorage.getItem("UserLocation")),
    })
    // return "string";
}

export const getFileInfo = (uri) => {
    // Get file extension
    const extension = uri.split('.').pop().toLowerCase();

    // Map extensions to MIME types
    const mimeTypes = {
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'heic': 'image/heic'
    };

    // Generate unique name with timestamp
    const timestamp = new Date().getTime();
    const fileName = `image_${timestamp}.${extension}`;

    return {
      name: fileName,
      type: mimeTypes[extension] || 'image/jpeg'
    };
  };

export const CompanyID =()=>{
    if(AppType==='fl-app'){
        return "1";
    }
    else if(AppType==='aml-app'){
        return "2";
    }
    else if(AppType==='il-app'){
        return "3";
    }
    else if(AppType==='sl-app'){
        return "4";
    }
}
