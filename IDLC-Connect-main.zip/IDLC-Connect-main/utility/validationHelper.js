class ValidationHelper{

    static isLogin() {
        return !this.isEmpty(sessionStorage.getItem("token"));
    }
    static isAdmin() {
        return sessionStorage.getItem("IsAdmin") === "true";
    }


    static IsUndefined(value) {
        return typeof value === 'undefined';
    }

    static isString(value) {
        return typeof value === 'string';
    }

    static isNumber(value) {
        return typeof value === 'number';
    }

    static isZero(value) {
        return parseFloat(value) === 0;
    }

    static isNullOrUndefined(value) {
        return value === null || typeof value === 'undefined';
    }

    static isValidPhotoExtension(filename) {

        const fileExtension = filename.split('.').pop().toLowerCase();
        const allowedExtensions = ['.JPEG','.JPG','.PNG','.png', '.jpg', '.jpeg', '.gif','.GIF'];
        return allowedExtensions.includes(fileExtension);
    }


    static isValidFileExtension(filename) {

        const fileExtension = filename.split('.').pop().toLowerCase();
        const allowedExtensions = ['.PDF','.pdf','.JPEG','.JPG','.PNG','.png', '.jpg', '.jpeg', '.gif','.GIF'];
        return allowedExtensions.includes(fileExtension);
    }


    static IsNull(value) {
        return value == null;
    }

    static isArray(value) {
        return Array.isArray(value);
    }

    static isEmptyArray(value) {
        return Array.isArray(value) && value.length === 0;
    }

    static isEmpty(value) {
        return value === null || value === undefined || value.length === 0;
    }

    static isNID(value) {
        const nidRegex = /^(\d{10}|\d{13}|\d{17})$/;
        return nidRegex.test(value);
    }

    static isEmail(value) {
        const emailRegex = /\S+@\S+\.\S+/;
        return emailRegex.test(value);
    }

    static isMobile(value) {
        const MobileRegx = /^(?:\+88|88)?01[3-9]\d{8}$/;
        return MobileRegx.test(value);
    }
    static isPostCode(value) {
        const postCodeRegex = /^\d{4}$/;
        return postCodeRegex.test(value);
    }
    

    static isForeignMobile(value) {
        const foreignMobileRegex = /^(?!\+?88|01[3-9])\+?\d+$/;
        return foreignMobileRegex.test(value);
    }

    static IsDate(value) {
        const DATERegex = /^\d{4}-\d{2}-\d{2}$/;
        return DATERegex.test(value);
    }

    static isDate(value) {
        const date = new Date(value);
        return !isNaN(date.getTime());
    }

    static isURL(value) {
        const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
        return urlRegex.test(value);
    }

    static isIPAddress(value) {
        const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        const ipv6Regex = /^(?:[A-F0-9]{1,4}:){7}[A-F0-9]{1,4}$/i;
        return ipv4Regex.test(value) || ipv6Regex.test(value);
    }



    static isPasswordConfirmed(password, confirmPassword) {
        return password === confirmPassword;
    }

    static isValidJSON(jsonString) {
        try {
            JSON.parse(jsonString);
            return true;
        } catch (error) {
            return false;
        }
    }

    static isObject(value) {
        return typeof value === 'object' && value !== null;
    }

    static isEmptyObject(obj) {
        // Check if the argument is an object and not null
        if (typeof obj !== 'object' || obj === null) {
            return false;
        }
        // Check if the object has no own enumerable properties
        for (let key in obj) {
            if (obj.hasOwnProperty(key)) {
                return false; // If the object has any own properties, it's not empty
            }
        }
        return true; // If the loop completes without finding any own properties, the object is empty
    }

    static delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    static isEightCharactersLong(value) {
        return value.length >= 8;
    }
    static hasUpperAndLowerCase(value) {
        const upperCaseRegex = /[A-Z]/;
        const lowerCaseRegex = /[a-z]/;
        return value?.length > 0 && upperCaseRegex.test(value) && lowerCaseRegex.test(value);
    }
    static isContainSpecialCharacter(value) {
        // const specialCharacterRegex = /[!@#$%^&*(),.?":{}|<>]/;
        const  specialCharacterRegex = /[^A-Za-z0-9]/;
        // console.log("specialCharacterRegex",specialCharacterRegex.test(value))
        return specialCharacterRegex.test(value);
    }


}
export default ValidationHelper
