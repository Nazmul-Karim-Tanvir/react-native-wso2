const dotenv = require('dotenv');
dotenv.config();

const getAppName = () => {
    const APP_VARIANT = process.env.APP_VARIANT;
    switch (APP_VARIANT) {
        case 'aml-app':
            return 'IDLC Connect AML';
        case 'sl-app':
            return 'IDLC Connect SL';
        case 'il-app':
            return 'IDLC Connect IL';
        case 'fl-app':
            return 'IDLC Connect FL';
        default:
            return 'IDLC Connect';
    }
};

const getUniqueIdentifierAndroid = () => {
    const APP_VARIANT = process.env.APP_VARIANT;
    switch (APP_VARIANT) {
        case 'aml-app':
            return 'com.idlc.idlc_connect_aml_app.dev';
        case 'sl-app':
            return 'com.idlc.idlc_connect_sl_app.dev';
        case 'il-app':
            return 'com.idlc.idlc_connect_il_app.dev';
        case 'fl-app':
            return 'com.idlc.idlc_connect_fl_app.dev';
        default:
            return 'com.idlc.idlc_connect';
    }
};

const getUniqueIdentifierIOS = () => {
    const APP_VARIANT = process.env.APP_VARIANT;
    switch (APP_VARIANT) {
        case 'aml-app':
            return 'com.idlc.idlc-connect-aml-app.dev';
        case 'sl-app':
            return 'com.idlc.idlc-connect-sl-app.dev';
        case 'il-app':
            return 'com.idlc.idlc-connect-il-app.dev';
        case 'fl-app':
            return 'com.idlc.idlc-connect-fl-app.dev';
        default:
            return 'com.idlc.idlc-connect';
    }
};

export default ({config}) => ({
    expo: {
        ...config,
        name: getAppName(),
        slug: "idlc-connect",
        version: "1.0.0",
        orientation: "portrait",
        icon: "./assets/images/icon.png",
        scheme: "myapp",
        userInterfaceStyle: "automatic",
        newArchEnabled: true,
        ios: {
            supportsTablet: true, bundleIdentifier: getUniqueIdentifierIOS(), infoPlist: {
                NSLocationWhenInUseUsageDescription: "This app requires access to your location to scan and decode barcodes.",
                NSLocationAlwaysUsageDescription: "This app uses your location to provide location-based features.",
                NSCameraUsageDescription: "$(PRODUCT_NAME) needs access to your Camera.",
                NSMicrophoneUsageDescription: "$(PRODUCT_NAME) needs access to your Microphone.",
                ITSAppUsesNonExemptEncryption: false,
                UIBackgroundModes: ["remote-notification"],
            }
        },
        android: {
            adaptiveIcon: {
                foregroundImage: "./assets/images/idlcIcon.png", backgroundColor: "#F6F3FE"
            },
            googleServicesFile: `./assets/files/google-services-${process.env.APP_VARIANT}.json`,
            package: getUniqueIdentifierAndroid(),
            permissions: ["android.permission.RECORD_AUDIO", "android.permission.CAMERA", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"],
            useNextNotificationsApi: true,
            notification: {
                "icon": "./assets/images/IDLC_Logo_mini.svg" // Example path
            }
        },
        web: {
            bundler: "metro", output: "static", favicon: "./assets/images/favicon.png"
        },
        plugins: ["expo-router", "expo-asset", ["expo-splash-screen", {
            image: "./assets/images/idlcIcon.png", imageWidth: 200, resizeMode: "contain", backgroundColor: "#F6F3FE"
        }], ["expo-image-picker", {
            photosPermission: "The app accesses your photos to let you share them with your friends."
        }], ["react-native-vision-camera", {
            enableFrameProcessors: true,
            cameraPermissionText: "$(PRODUCT_NAME) needs access to your Camera.",
            enableCameraPermission: true,
            enableMicrophonePermission: true,
            microphonePermissionText: "$(PRODUCT_NAME) needs access to your Microphone."
        }], ["expo-build-properties", {
            android: {
                minSdkVersion: 26, usesCleartextTraffic: true
            }, ios: {
                deploymentTarget: "15.1"
            }
        }], ["expo-font", {
            fonts: ["./assets/fonts/SpaceMono-Regular.ttf"]
        }], ["expo-location", {
            locationAlwaysPermission: "Allow $(PRODUCT_NAME) to use your location."
        }], ["expo-notifications", {
            icon: "./assets/images/idlcIcon.png", color: "#ffffff"
        }], ["expo-local-authentication", {
            faceIDPermission: "Allow $(PRODUCT_NAME) to use Face ID."
        }]],
        experiments: {
            typedRoutes: true
        },
        extra: {
            APP_VARIANT: process.env.APP_VARIANT,
            BaseUrl: process.env.BASE_URL,
            BasePath: process.env.BASE_PATH,
            router: {
                origin: false
            },
            eas: {
                "projectId": "30423ed5-21a2-451c-bfff-17dcf009c9ce"
            }
        }
    }
});
