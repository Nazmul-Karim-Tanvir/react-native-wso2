import {create} from 'zustand';

const initialState = {
    stage: '',
    nidInfo: {
        FullName: '',
        FatherName: '',
        MotherName: '',
        NidNo: '',
        BirthDate:'',
        Address: ''
    },
    ekyc1: {
        NidNumber: '',
        NidName: '',
        Dob: '',
        NidFrontImg: null,
    },
    ekyc2: {
        NidBackImg: null,
        ExtractedName: "",
        ExtractedDOB: ""
    },
    ekyc3: {
        photoBase64: "",
        blinkCount: 0,
        faceExpression: '',
        photoPath: null,
        nidPhoto: '',
        photoVerificationResult: ''
    },
    ekyc4: {
        FatherName:"",
        MotherName:"",
        MailingAddress:"",
        DivisionCode:"",
        Division:"",
        DistrictCode:"",
        District:"",
        PostCode:"",
        PoliceStationCode:"",
        PoliceStation:""
    },
}

const ekycStore = create((set, get) => ({
    ...initialState,
    setStage: (data) => set(() => ({stage: data})),
    setNidInfo: (data) => set(() => ({nidInfo: data})),
    setEkyc1: (data) => set(() => ({ekyc1: data})),
    setEkyc2: (data) => set(() => ({ekyc2: data})),
    setEkyc3: (data) => set(() => ({ekyc3: data})),
    setEkyc4: (data) => set(() => ({ekyc4: data})),
    onChangeEkyc1: (data) => set((state) => ({ekyc1: {...state.ekyc1, ...data}})),
    onChangeEkyc2: (data) => set((state) => ({ekyc2: {...state.ekyc2, ...data}})),
    onChangeEkyc3: (data) => set((state) => ({ekyc3: {...state.ekyc3, ...data}})),
    onChangeEkyc4: (data) => set((state) => ({ekyc4: {...state.ekyc4, ...data}})),
    resetEkyc1: ()=>set(() => ({ekyc1: initialState.ekyc1})),
    resetEkyc2: ()=>set(() => ({ekyc2: initialState.ekyc2})),
    resetEkyc3: ()=>set(() => ({ekyc3: initialState.ekyc3})),
    resetEkyc4: ()=>set(() => ({ekyc4: initialState.ekyc4})),
}));

export default ekycStore;
