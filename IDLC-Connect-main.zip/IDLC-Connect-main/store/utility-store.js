import {create} from 'zustand';

const initialState = {
    isLoading: false,
    focusOn: "",
    errorMessage: ""
}

const utilityStore = create(set => ({
    ...initialState,
    setIsLoading: (data) => set(() => ({isLoading: data})),
    setFocusOn: (data) => set(() => ({focusOn: data})),
    setErrorMessage: (data) => set(() => ({errorMessage: data})),
    resetFocus:()=>set(() => ({focusOn: initialState.focusOn}))
}));

export default utilityStore;
