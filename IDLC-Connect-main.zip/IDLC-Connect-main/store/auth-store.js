import {create} from 'zustand';
import {DeviceInformation} from "../utility/utility-functions";

const initialState = {
    preLogin: {
        MobileNumber: '',
        WhatsAppNumber: '',
        EmailAddress: '',
        DeviceInfo: "string"
    },
    otpData: {
        ReferenceID: "",
        DeviceInfo: "string",
        OtpCode: ""
    },
    loginData: {
        mobileEmail:"",
        password: "",
    }
}

const authStore = create((set, get) => ({
    ...initialState,
    setPreLogin: (data) => set(() => ({preLogin: data})),
    onChangePreLogin: (data) => set(() => ({preLogin: {...get().preLogin, ...data}})),
    setOtpData: (data) => set(() => ({otpData: data})),
    onChangeOtpData: (data) => set(() => ({otpData: {...get().otpData, ...data}})),
    setLoginData: (data) => set(() => ({loginData: data})),
    onChangeLoginData: (data) => set(() => ({loginData: {...get().loginData, ...data}})),
    resetLoginData: () => set(() => ({loginData: initialState?.loginData})),
}));

export default authStore;
