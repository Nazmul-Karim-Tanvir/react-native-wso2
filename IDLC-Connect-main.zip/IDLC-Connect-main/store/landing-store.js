import {create} from 'zustand';

const initialState = {
    branchList: []
}

const landingStore = create((set, get) => ({
    ...initialState,
    setBranchList: (data) => set(() => ({branchList: data})),
}));

export default landingStore;
