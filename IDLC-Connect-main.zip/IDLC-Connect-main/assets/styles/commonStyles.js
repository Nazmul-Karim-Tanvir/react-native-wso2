export const FontStyle = {
    regular: 'K2D-Regular',
    bold: 'K2D-Bold',
    semiBold:'K2D-SemiBold',
    medium: 'K2D-Medium',
    light:'K2D-Light',
    italic:'K2D-Italic'
}