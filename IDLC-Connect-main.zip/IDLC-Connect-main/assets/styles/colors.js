export const Colors = {
    primary: '#CC0A13',
    secondary: '#777777',
    dark: '#323232'
}