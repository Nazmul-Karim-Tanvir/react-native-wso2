import React from 'react';
import {Image, SafeAreaView, StyleSheet, TouchableOpacity, View} from "react-native";
import {AntDesign} from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import MarketComponent from "../components/ui-custom-component/MarketComponent";
import {AppType} from "../apiRequests/base-url-config";
import {useRouter} from "expo-router";

const AuthNavLayout = ({navigation}) => {
    const router = useRouter();

    const handleGoBack = () => {
        router.canGoBack() && router.back();
    }
    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.header}>
                <TouchableOpacity onPress={handleGoBack} style={{padding: 5}}>
                    <AntDesign name="arrowleft" size={24} color="black" />
                </TouchableOpacity>
                <TouchableOpacity onPress={async () => {
                    navigation.replace('index');
                }}>
                    <Image source={require('../assets/images/IDLC_LOGO.png')} style={styles.image} />
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
};

export default AuthNavLayout;

export const LandingNavLayout = () => {
    const router = useRouter();

    const handleUserClick = async () => {
        await AsyncStorage.setItem("RedirectTo", "/");
        router.push('page-phone-entry');
    }

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.header}>
                <Image source={require('../assets/images/IDLC_LOGO.png')} style={styles.image} />
                {(AppType.split("-").find(item => item === "sl" || item === "il"))? <MarketComponent/> : null }
                <View style={{width: 120, justifyContent: 'center', alignItems: 'flex-end'}}>
                    <TouchableOpacity onPress={handleUserClick} style={{width: 40, height: 40, borderRadius: 50, borderWidth: 1, borderColor: '#000000', justifyContent: 'center', alignItems: 'center'}}>
                        <AntDesign name="user" size={24} color="black" />
                    </TouchableOpacity>
                </View>

            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    header: {
        height: 60,
        backgroundColor: '#ffffff',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
    },
    headerTitle: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
        width: 100
    },
    safeArea: {
        backgroundColor: 'transparent',
    },
    image: {
        height: 50,
        width: 120,
        resizeMode: 'contain'
    },
})
