import React from 'react';
import {StyleSheet, Text, View} from "react-native";
import IDLCLogo from "../../assets/images/IDLC_Logo_mini.svg";
import CButton from "../../components/ui-custom-component/paper-button";
import {FontStyle} from "../../assets/styles/commonStyles";
import {useRouter} from "expo-router";
import Foundation from "react-native-vector-icons/Foundation";

const PageMultipleCif = () => {
    const router = useRouter();

    return (
        <View style={styles.container}>
            <View style={{alignItems: "center"}}>
                <IDLCLogo width={64} height={64} style={{marginBottom: 30}} />
            </View>

            <View style={styles.cardStyle}>
                <View style={styles.cardHeader}>
                    <Foundation name="alert" style={{marginEnd: 10, color: '#ffe6b0'}} size={40}/>
                    <Text style={{fontSize: 18, flex: 1, color: '#ffe6b0', lineHeight: 20, fontFamily: FontStyle.semiBold}}>
                        Multiple Customer Found against this phone number
                    </Text>
                </View>
                <View style={{borderTopWidth: 1, borderColor: 'red'}}></View>
                <View style={{flexDirection: 'row', alignItems: "center", margin: 15,}}>
                    <Text style={{fontSize: 14, flex: 1, color: 'black', lineHeight: 16, fontFamily: FontStyle.medium}}>
                        Please Contact your RM or Contact IDLC at 16409 for assistance
                    </Text>
                </View>
            </View>
            <CButton onPress={() => router.push("/")} buttonStyles={{marginTop: 20}}>Home</CButton>
        </View>
    );
};

export default PageMultipleCif;

const styles = StyleSheet.create({
    container: {
        flex: 1, justifyContent: "space-evenly", alignItems: "center", padding: 30
    },
    cardStyle: {
        backgroundColor: 'white', borderWidth: 1, borderRadius: 8, width: '100%', borderColor: 'red'
    },
    cardHeader: {
        flexDirection: 'row', alignItems: "center", padding: 15, backgroundColor: 'red', borderRadius: 6, borderBottomStartRadius: 0, borderBottomEndRadius: 0
    }
})
