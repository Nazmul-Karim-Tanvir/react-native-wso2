import React, {useEffect, useRef, useState} from 'react';
import WebView from "react-native-webview";
import {useLocalSearchParams, useRouter} from "expo-router";
import {ActivityIndicator, Alert, BackHandler, Platform, StyleSheet, View, Text} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import utilityStore from "../../store/utility-store";
import {AppType} from "../../apiRequests/base-url-config";
import DownloadOpenPdf, {openPDF, openImage, DownloadOpenImage} from "../../utility/download-open-pdf";
import * as Notifications from "expo-notifications";
import LottieView from "lottie-react-native";

const PageWebview = () => {
    const router = useRouter();
    const {isLoading, setIsLoading} = utilityStore();
    const [redirectTo, setRedirectTo] = useState('');
    const {Token, UserDetail} = useLocalSearchParams();
    const webViewRef = useRef(null); // Reference to the WebView
    const [canGoBack, setCanGoBack] = useState(false);

    // Handle hardware back button
    React.useEffect(() => {
        const backHandler = BackHandler.addEventListener("hardwareBackPress", () => {
            if (canGoBack) {
                webViewRef.current.goBack(); // Navigate back in WebView history
                return true; // Prevent default back button behavior
            } else {
                Alert.alert(
                    "Exit App",
                    "Are you sure you want to exit?",
                    [
                        {text: "Cancel", style: "cancel"},
                        {
                            text: "Logout", onPress: async () => {
                                router.back();
                                await AsyncStorage.setItem("RedirectTo", "/");
                            }
                        },
                        {
                            text: "Exit", onPress: async () => {
                                router.dismissAll();
                                BackHandler.exitApp();
                                await AsyncStorage.setItem("RedirectTo", "/");
                            }
                        },
                    ],
                    {cancelable: true}
                );
                return true;
            }
        });
        return () => backHandler.remove(); // Cleanup on unmount
    }, [canGoBack]);

    useEffect(() => {
        (async () => {
            let path = await AsyncStorage.getItem("RedirectTo");
            console.log("redirect-path", path);
            setRedirectTo(path || "/");
        })()
        console.log("user Details,", UserDetail);
    }, [])

    const InjectedJavascript = `
        let meta = document.createElement('meta'); 
        meta.setAttribute('name', 'viewport'); 
        meta.setAttribute('content', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0'); 
        document.getElementsByTagName('head')[0].appendChild(meta);
    `;

    const InjectedJSBeforeLoaded = `
        sessionStorage.setItem('Token', ${Token});
        sessionStorage.setItem('UserDetail', ${UserDetail});
    `

    React.useEffect(() => {
        const subscription = Notifications.addNotificationResponseReceivedListener(async res => {
            const {pdfUri, imgUri} = res.notification.request.content.data;

            if (pdfUri && pdfUri.toLowerCase().includes('.pdf')) {
                await openPDF(pdfUri);
            } else if (imgUri && imgUri.toLowerCase().includes('.png')) {
                await openImage(imgUri);
            } else {
                webViewRef.current.injectJavaScript(`window.location.href = 'https://app7.idlc.com:9999/${AppType}/notifications'`);
            }
        });
        return () => subscription.remove();
    }, []);

    return (
        <View style={styles.container}>
            {
                isLoading && <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color={isLoading ? "white" : "black"}/>
                </View>
            }
            <WebView
                ref={webViewRef}
                style={styles.webViewContainer}
                source={{uri: `https://app7.idlc.com:9999/${AppType}${redirectTo}`}}
                injectedJavascript={InjectedJavascript}
                injectedJavaScriptBeforeContentLoaded={InjectedJSBeforeLoaded}
                onNavigationStateChange={(navState) => {
                    setCanGoBack(navState.canGoBack);
                    console.log("navUrl", navState.url);
                    let urlArr = navState.url.split('/');
                    if (urlArr[urlArr.length - 1] === 'login') {
                        router.replace("page-login");
                    } else if (urlArr[urlArr.length - 1].includes("pdf")) {
                        console.log(urlArr);
                        router.push(navState.url);
                    }
                    setIsLoading(false);
                }}
                incognito={true}
                javaScriptCanOpenWindowsAutomatically={true}

                onOpenWindow={async (syntheticEvent) => {
                    const {targetUrl} = await syntheticEvent?.nativeEvent;
                    console.log("targetUrl", targetUrl)
                    if (targetUrl.toLowerCase().includes('.pdf')) {
                        console.log('Intercepted OpenWindow for pdfs', targetUrl)
                        Platform.OS === "android" && await DownloadOpenPdf(targetUrl);
                    } else if (targetUrl.toLowerCase().includes('.png')) {
                        console.log('Intercepted OpenWindow for images', targetUrl)
                        Platform.OS === "android" && await DownloadOpenImage(targetUrl);
                    }
                }}

                onShouldStartLoadWithRequest={(request) => {
                    console.log("request", request.url);
                    if (request.url.toLowerCase().includes('.pdf')) {
                        console.log("PDF URL detected:", request.url);
                        Platform.OS === "ios" && DownloadOpenPdf(request.url);
                        return false; // Prevent WebView from opening the PDF
                    }

                    if (request.url.includes('/login')) {
                        router.replace("page-login");
                        return false;
                    }
                    return true; // Allow WebView to load URL
                }}

                renderError={(errorName) => (
                    <View style={styles.animationContainer}>
                        <LottieView
                            autoPlay
                            loop
                            style={{
                                width: 200,
                                height: 200,
                            }}
                            source={require('../../assets/animation/loading6.json')}
                        />
                    </View>
                )}
                setSupportMultipleWindows={true}
                setBuiltInZoomControls={false}
            />
        </View>

    );
};

export default PageWebview;

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    loadingContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        zIndex: 1,
    },
    webViewContainer: {
        flex: 1, justifyContent: "center"
    },
    animationContainer: {
        position: 'absolute',
        top: 0,
        bottom: 0, left: 0, right: 0,
        backgroundColor: 'rgba(0,0,0,0.25)',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000
    },
})
