import React, {useState,useEffect,useRef} from 'react';
import {Text, View, StyleSheet, KeyboardAvoidingView, Platform, Keyboard} from "react-native";
import {useNavigation, useRouter} from "expo-router";
import IDLCLogo from "../../assets/images/IDLC_Logo_mini.svg";
import CButton from "../../components/ui-custom-component/paper-button";
import OtpInputComponent from "../../components/ui-custom-component/otp-input-component";
import {GetEkycDataRequest, VerifyOTPRequest} from "../../apiRequests/auth/auth-requests";
import AsyncStorage from "@react-native-async-storage/async-storage";
import authStore from "../../store/auth-store";
import {DeviceInformation} from "../../utility/utility-functions";
import { FontStyle } from '../../assets/styles/commonStyles';
import validationHelper from "../../utility/validationHelper";
import {Toast} from "toastify-react-native";
import {UserLoginRequests} from "../../apiRequests/auth/auth-requests";
import ValidateLogin from '../../validation/ValidateLogin';
import { useSmsUserConsent } from '@eabdullazyanov/react-native-sms-user-consent';


const PageOtpVerification = () => {
    const router = useRouter();
    const {otpData, onChangeOtpData, preLogin,loginData, onChangeLoginData} = authStore();
    // const [code, setCode] = useState();
    const otpRef = useRef(null);

    const retrievedCode = useSmsUserConsent(6);

    useEffect(() => {
      if (retrievedCode) {
        // setCode(retrievedCode);
        otpRef.current.setValue(retrievedCode); // Manually set OTP
        console.log("ReceivedCode",retrievedCode)
        onChangeOtpData({otpCode: retrievedCode});
        console.log("otpData using UseRef", otpRef.current.value)
    }
    }, [retrievedCode]);



    const handleAutoLogin = async () => {
        if(ValidateLogin(loginData)){
            let data = {
                "emailOrMobileNumber": loginData?.mobileEmail,
                "userPass": loginData?.password,
                "deviceInfo": await DeviceInformation(),
                "pushNotificationToken": await AsyncStorage.getItem("PushToken")
            }
            Keyboard.dismiss();
            const success = await UserLoginRequests(data);
            if(success){
                router.push({
                    pathname: 'page-webview',
                    params: {
                        Token: JSON.stringify(await AsyncStorage.getItem("Token")),
                        UserDetail: JSON.stringify(await AsyncStorage.getItem("UserDetail"))
                    }})
                onChangeLoginData({password: ""})
            }
        }
    }


    const handleContinue = async () => {
        console.log("otpCode in handleContinue",otpData?.otpCode)
        onChangeLoginData({mobileEmail: preLogin?.MobileNumber})
        if(validationHelper.isEmpty(authStore.getState().otpData.otpCode) || authStore.getState().otpData.otpCode.length < 6) {
            Toast.error("Valid OTP Code is required.");
        }
        else {
            let data = {
                "ReferenceID": await AsyncStorage.getItem("ReferenceID"),
                "DeviceInfo": await DeviceInformation(),
                "OtpCode": authStore.getState().otpData.otpCode,
            }
            Keyboard.dismiss();
            console.log("Data in otp Verify", data);
            let Step = await VerifyOTPRequest(data, preLogin?.MobileNumber);
            console.log("step", "|"+Step+"|", loginData)
            //console.log("Mobile number in otp verification",preLogin?.MobileNumber)
            // await AsyncStorage.setItem("MobileNumber", preLogin?.MobileNumber)
            // console.log(loginData?.mobileEmail,loginData?.password)
            Step === "Step-2-NID-Front" && router.replace("page-ekyc?goToStep=1");
            Step === "Step-3-NID-Back" && router.replace("page-ekyc?goToStep=2");
            Step === "Step-4-Live-Photo" && router.replace("page-ekyc?goToStep=3");
            Step === "Step-5-NID-Info-Confirm" && router.replace("page-ekyc?goToStep=4");
            Step === "Step-6-Set-Password" && router.replace("page-set-password");
            Step === "Completed" && ((loginData?.mobileEmail !== '' && loginData?.password !== '')
              ? await handleAutoLogin() : router.replace("page-login"));
            Step === "ResetPassword" && router.replace("page-set-password");
        }
    }

    return (
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <View style={styles.container}>
            <View style={{alignItems: "center"}}>
                <IDLCLogo width={64} height={64} />
                <Text style={styles.headerText}>Please input the 6 digit OTP sent to your mobile for verification</Text>
            </View>

            <OtpInputComponent
                otpRef={otpRef}
                value={otpData?.otpCode}
                onValueChange={(val) => {onChangeOtpData({otpCode: val})}}
               // onValueChange={setCode}
                onFilled={handleContinue}
            />
            <CButton icon='arrow-right' onPress={handleContinue} ButtonStyles={{marginTop: 20}}>Next</CButton>
            <View></View>
        </View>
        </KeyboardAvoidingView>
    );
};

export default PageOtpVerification;

const styles = StyleSheet.create({
    container: {
        flex: 1, justifyContent: "space-evenly", alignItems: "center", padding: 30
    },
    headerText: {
        fontSize: 22,
        textAlign: "center",
        marginTop: 30,
        fontFamily: FontStyle?.regular
    }
})
