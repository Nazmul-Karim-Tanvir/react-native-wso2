import {StyleSheet, View} from 'react-native';
import React, {useEffect} from "react";
import SectionFooterButtons from "../../components/landing-page/section-footer-buttons";
import SectionCarousel from "../../components/landing-page/section-carousel";
import SectionProduct from "../../components/landing-page/section-product";
import {GetBranches} from "../../apiRequests/auth/common-requests";
import {AppType} from "../../apiRequests/base-url-config";
import SectionProductOthers from "../../components/landing-page/section-product-others";
import MarqueeComponent from "../../components/ui-custom-component/MarqueeComponent";
import * as Location from "expo-location";
import AsyncStorage from "@react-native-async-storage/async-storage";
import landingStore from "../../store/landing-store";
import authStore from "../../store/auth-store";
import {router} from "expo-router";
import validationHelper from "../../utility/validationHelper";
import { registerForPushNotificationsAsync } from '../../utility/pushToken';
import { CompanyID } from '../../utility/utility-functions';
import PushNotification from "../../components/ui-custom-component/push-Notification";

export default function HomeScreen() {
    const {branchList} = landingStore();
    const {loginData } = authStore();

    useEffect(() => {
        (async () => {
            let { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') {
                alert('Permission to access location was denied');
                return;
            }
            let location = await Location.getCurrentPositionAsync({});
            const {latitude, longitude} = location.coords;
            let address = await Location.reverseGeocodeAsync({latitude, longitude});
            console.log(address);
            await AsyncStorage.setItem("UserLocation", JSON.stringify(address[0]));
        })()
    }, []);

    useEffect(() => {
        (async () => {
            branchList?.length <= 0 && await GetBranches();
        })()
    }, []);

    useEffect(() => {
        registerForPushNotificationsAsync().then(token =>
            {
                //console.log("token",token+CompanyID());
                AsyncStorage.setItem("PushToken",token+CompanyID());
            });

        (async () => {
            if(validationHelper.isEmpty(loginData.mobileEmail)){
                let userMobileNumber = await AsyncStorage.getItem("MobileNumber");
                userMobileNumber && router.replace("page-login");
            }
        })()
    }, [])

    return (
        <View style={styles.container}>
            <View>
                {(AppType.split("-").find(item => item === "sl" || item === "il")) ? <MarqueeComponent /> : null }
                {(AppType.split("-").find(item => item === "sl" || item === "il" || item === "aml")) ? <SectionProductOthers /> : <SectionProduct/>}
                <SectionCarousel />
            </View>
             <PushNotification />
            <SectionFooterButtons />
        </View>
    );
}


const styles = StyleSheet.create({
    container: {
        flex: 1, flexDirection: "column", justifyContent: 'space-between'
    },
});
