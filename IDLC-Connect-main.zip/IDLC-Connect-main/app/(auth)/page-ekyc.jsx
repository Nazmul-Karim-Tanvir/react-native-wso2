import React, {useEffect, useState} from 'react';
import {Keyboard, View} from "react-native";
import {useGlobalSearchParams, useRouter} from "expo-router";
import Ekyc1 from "../../components/ekyc/ekyc-1";
import Ekyc2 from "../../components/ekyc/ekyc-2";
import Ekyc3 from "../../components/ekyc/ekyc-3";
import Ekyc4 from "../../components/ekyc/ekyc-4";
import Ekyc4_1 from '../../components/ekyc/ekyc-4_1';
import AuthStepper from "../../components/ui-custom-component/auth-stepper";
import ekycStore from "../../store/ekyc-store";
import {CRM_Contact_Create_Req, EkycProcessRequest} from "../../apiRequests/auth/auth-requests";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {uriToFile} from "../../utility/utility-functions";
import moment from "moment";
import validationHelper from "../../utility/validationHelper";
import {Toast} from "toastify-react-native";
import ValidateEkyc4 from "../../validation/ValidateEkyc4";
import authStore from '../../store/auth-store';

export default function PageEkyc () {
    const router = useRouter();
    const {goToStep} = useGlobalSearchParams();
    const {stage, ekyc1, ekyc2, ekyc3, ekyc4, resetEkyc1, resetEkyc2, resetEkyc3, resetEkyc4} = ekycStore();
    const { preLogin } = authStore();
    const [step, setStep] = useState(1);
    const [steps] = useState([
        {
            StepName: 'NID - Front',
            StepContent: <Ekyc1 />
        },
        {
            StepName: 'NID - Back',
            StepContent: <Ekyc2 />
        },
        {
            StepName: 'Live Photo',
            StepContent: <Ekyc3 />
        },
        {
            StepName: 'Personal Information',
            StepContent: <Ekyc4_1/>
        },
    ])

    useEffect(() => {
        console.log(goToStep, ekyc1);
        setStep(parseInt(goToStep || 1));

        if(goToStep === "1"){
            resetEkyc1();
            resetEkyc2();
            resetEkyc3();
            resetEkyc4();
        }
        else if(goToStep === "2"){
            resetEkyc2();
            resetEkyc3();
            resetEkyc4();
        }
        else if(goToStep === "3"){
            resetEkyc3();
            resetEkyc4();
        }
        else if(goToStep === "4"){
            resetEkyc4();
        }
    }, []);

    const handleContinue = async () => {
        if(step === 4) {
            if(stage === "Step-5-NID-Info-Confirm") {
                if(ValidateEkyc4(ekyc4)){
                    let formData = new FormData();
                    formData.append("Stage", "Step-5-NID-Info-Confirm");
                    formData.append("FathersName", ekyc4?.FatherName);
                    formData.append("MothersName", ekyc4?.MotherName);
                    formData.append("MailingAddress", ekyc4?.MailingAddress);
                    formData.append("PostalCode", ekyc4?.PostCode);
                    formData.append("District", ekyc4?.District);
                    formData.append("Division", ekyc4?.Division);
                    formData.append("PoliceStation", ekyc4?.PoliceStation);
                    formData.append("RegistrationReferenceID", await AsyncStorage.getItem("RegistrationReferenceID"));
                    console.log(formData);
                    Keyboard.dismiss();
                    let success = await EkycProcessRequest(formData, "Step-6-Set-Password");
                    
                    await CRM_Contact_Create_Req(preLogin,ekyc1,ekyc2,ekyc3,ekyc4);

                    success && router.push("page-set-password");
                }
            }
            console.log("staggge!!!",stage);



        }
        else {
            console.log("Not Step 4");
        }
    }

    const handleNext = async () => {
        if(step === 1) {
            if(stage === "Step-2-NID-Front"){
                if(validationHelper.isEmpty(ekyc1.NidFrontImg)) {
                    Toast.error("NID's Front Image is required to proceed");
                    return false;
                }
                else {
                    console.log("NidFrontImg", await uriToFile(ekyc1?.NidFrontImg))
                    let formData = new FormData();
                    formData.append("Stage", "Step-2-NID-Front");
                    formData.append("Ocrname", ekyc1?.NidName);
                    formData.append("Ocrdob", ekyc1?.Dob ? moment(ekyc1?.Dob, "YYYY-MM-DD").format("DD-MM-YYYY") : null);
                    formData.append("Ocrnid", ekyc1?.NidNumber);
                    formData.append("NidFrontImg", uriToFile(ekyc1?.NidFrontImg));
                    formData.append("RegistrationReferenceID", await AsyncStorage.getItem("RegistrationReferenceID"));
                    console.log("ffmm",formData);
                    if(validationHelper.isEmpty(ekyc1?.NidName) || validationHelper.isEmpty(ekyc1?.Dob) || validationHelper.isEmpty(ekyc1?.NidNumber)) {
                        Toast.error("Please attach a valid NID!!");
                        return false;
                    }
                    else return await EkycProcessRequest(formData, "Step-3-NID-Back");
                }
            }
            else return true;
        }
        else if(step === 2) {
            //console.log("ddd",step,stage)
            if(stage === "Step-3-NID-Back") {
                if(validationHelper.isEmpty(ekyc2.NidBackImg)) {
                    Toast.error("NID's Back Image is required to proceed");
                    return false;
                }
                // else if(ekyc2?.ExtractedName !== ekyc1?.NidName && ekyc2?.ExtractedDOB !== ekyc1?.Dob) {
                //     Toast.error("NID's Back Image is not valid, Please attach a valid NID's Back Image");
                //     return false;
                // }
                else {
                    //console.log("vvvv",ekyc2?.NidBackImg)
                    //console.log("NidBackImg",  uriToFile(ekyc2?.NidBackImg))
                    let formData = new FormData();
                    formData.append("Stage", "Step-3-NID-Back");
                    formData.append("NidBackImg",  uriToFile(ekyc2?.NidBackImg));
                    formData.append("RegistrationReferenceID", await AsyncStorage.getItem("RegistrationReferenceID"));
                    console.log("ffmm",formData);
                    return await EkycProcessRequest(formData, "Step-4-Live-Photo");
                }
            }
            else return true;
        }
        else if(step === 3) {
            if(stage === "Step-4-Live-Photo") {
                if(validationHelper.isEmpty(ekyc3.photoPath)) {
                    Toast.error("User's Live face verification is required to proceed");
                    return false;
                }
                else {
                    let formData = new FormData();
                    formData.append("Stage", "Step-4-Live-Photo");
                    formData.append("LivePhoto", uriToFile(ekyc3?.photoPath));
                    formData.append("PhotoVerificationResult", ekyc3?.photoVerificationResult);
                    formData.append("RegistrationReferenceID", await AsyncStorage.getItem("RegistrationReferenceID"));
                    console.log("lllvv",formData);
                    return await EkycProcessRequest(formData, "Step-5-NID-Info-Confirm");
                }
            }
            else {
                console.log("Not Step 4")
                return true;
            }
        }
        else return false;
    }

    return (
        <AuthStepper
            currentStep={step}
            setCurrentStep={setStep}
            steps={steps}
            onStepNext={handleNext}
            onStepComplete={handleContinue}
        >
            {steps[step-1]?.StepContent}
        </AuthStepper>
    );
};
