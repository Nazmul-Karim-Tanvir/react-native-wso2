import React, {useMemo, useState} from 'react';
import {Dimensions, Image, StyleSheet, Text, View} from "react-native";
import {Colors} from "../../assets/styles/colors";
import Icon from "react-native-vector-icons/Ionicons";
import landingStore from "../../store/landing-store";
import RnTable from "../../components/ui-custom-component/RNTable/RNTable";
import ModalComponent from "../../components/ui-custom-component/modal-component";
import { FontStyle } from '../../assets/styles/commonStyles';

const PageBranch = () => {
    const {branchList} = landingStore();
    const [showContactDetails, setShowContactDetails] = useState(false);
    const [selectedContact, setSelectedContact] = useState(null);
    const RowData = useMemo(() => branchList, [branchList]);
    const ColData = useMemo(() => [
        {
            header: "BranchName",
            accessor: "name",
            hideHeader: true,
            cell: (value) => <Text style={{fontSize: 22,fontFamily: FontStyle?.regular, lineHeight: 24}}>{value}</Text>,
            align: "full",
        },
        {
            header: "Contact",
            hideHeader: true,
            cell: (value) => <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center',}}>
                <View
                    style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center', marginRight: 15}}>
                    <Icon name="mail-outline" size={15} style={{marginRight: 5}}/>
                    <Text style={{fontSize: 14, flexWrap: 'wrap',fontFamily:FontStyle?.light, lineHeight: 16}}>{value?.email}</Text>
                </View>
                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center'}}>
                    <Icon name="call-outline" size={15} style={{marginRight: 5}}/>
                    <Text style={{fontSize: 14, flexWrap: 'wrap',fontFamily: FontStyle?.light, lineHeight: 16}}>{value?.telephone}</Text>
                </View>
            </View>,
            align: "left",
        },
        {
            header: "Address",
            accessor: "address",
            hideHeader: true,
            cell: (value) => <View
                style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                <Icon name="home-outline" size={15} style={{marginRight: 5, marginTop: 5}}/>
                <Text style={{fontSize: 15,fontFamily: FontStyle?.light, lineHeight: 16}}>{value}</Text>
            </View>,
            align: "left",
        },
    ], []);

    const ContactDetails = <View style={{padding: 10, maxWidth: "100%"}}>
        <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start'}}>
            <View style={{
                flexDirection: 'column',
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                maxWidth: Dimensions.get('window').width - 110,
            }}>
                <Text style={{
                    fontSize: 18,
                    textAlign: 'left',
                    fontFamily:FontStyle?.regular, lineHeight: 20
                }}>{selectedContact?.manager_name}</Text>
                <Text style={{fontSize: 14,fontFamily:FontStyle?.light}}>{selectedContact?.manager_designation}</Text>
                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center', marginTop: 5}}>
                    <Icon name="mail-outline" size={15} style={{marginRight: 5}}/>
                    <Text style={{fontSize: 13,fontFamily:FontStyle?.light, lineHeight: 15}}>{selectedContact?.manager_email}</Text>
                </View>
                <View style={{
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                    marginTop: 5,
                    marginBottom: 20,
                }}>
                    <Icon name="call-outline" size={15} style={{marginRight: 5}}/>
                    <Text style={{fontSize: 13, fontFamily:FontStyle?.light, lineHeight: 15}}>{selectedContact?.manager_phone}</Text>
                </View>
            </View>
            <Image
                source={{uri: selectedContact?.manager_image}}
                style={{
                    width: 100,
                    height: 100,
                    resizeMode: "cover",
                    borderRadius: 100,
                    borderWidth: 1,
                    borderColor: "#b5b5b5",
                }}
            />
        </View>
        <View style={{flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start'}}>
            <Text style={{fontSize: 18, textAlign: 'left', fontFamily:FontStyle?.regular}}>{selectedContact?.name}</Text>
            <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center'}}>
                <Icon name="mail-outline" size={15} style={{marginRight: 5}}/>
                <Text style={{
                    fontSize: 14,
                    flexWrap: 'wrap',
                    marginRight: 15, fontFamily:FontStyle?.light, lineHeight: 16
                }}>{selectedContact?.email}</Text>
                <Icon name="call-outline" size={15} style={{marginRight: 5}}/>
                <Text style={{
                    fontSize: 13,
                    flexWrap: 'wrap', fontFamily:FontStyle?.light, lineHeight: 15
                }}>{selectedContact?.telephone}</Text>
            </View>
            <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', paddingEnd: 10}}>
                <Icon name="home-outline" size={15} style={{marginRight: 5, marginTop: 5}}/>
                <Text style={{fontSize: 13, fontFamily:FontStyle?.light, lineHeight: 15}}>{selectedContact?.address}</Text>
            </View>
        </View>
    </View>
    return (
        <View>
            <View style={styles.headerContainer}>
                <Text style={styles.headerText}>Contact Us</Text>
            </View>
            <View style={{height: Dimensions.get('window').height-150, marginHorizontal: 5}}>
            {
                branchList?.length === 0 ?
                    <Image style={{width: '100%', resizeMode: 'contain'}} source={require("../../assets/images/icon.png")}/> :
                    <RnTable
                        rows={RowData}
                        columns={ColData}
                        onClick={(data, idx) => {
                            setSelectedContact(data);
                            setShowContactDetails(true);
                        }}
                        isCollapsable={false}
                    />
            }
            </View>
            <ModalComponent
                title="Contact Details"
                visible={showContactDetails}
                hideModal={() => setShowContactDetails(false)}
                content={ContactDetails}
                // position='bottom'
            />
        </View>
    );
};

export default PageBranch;

const styles = StyleSheet.create({
    headerContainer: {
        backgroundColor: '#fff', padding: 8, borderRadius: 8, borderColor: Colors.primary, borderWidth: 1, margin: 10
    },
    headerText: {
        color: Colors.primary, fontSize: 20, textAlign: 'center', fontWeight: 'bold',fontFamily: FontStyle?.regular
    }
})
