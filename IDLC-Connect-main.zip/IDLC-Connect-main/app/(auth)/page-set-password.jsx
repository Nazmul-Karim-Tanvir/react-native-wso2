import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  KeyboardAvoidingView,
  Platform, Keyboard,
} from "react-native";
import {useNavigation, useRouter} from "expo-router";
import IDLCLogo from "../../assets/images/IDLC_Logo_mini.svg";
import PTextInput from "../../components/ui-custom-component/paper-text-input";
import CButton from "../../components/ui-custom-component/paper-button";
import PassIcon from "react-native-vector-icons/Ionicons";
import AntDesign from "react-native-vector-icons/AntDesign";
import authStore from "../../store/auth-store";
import {
  EkycProcessRequest,
  SetNewPasswordRequest,
} from "../../apiRequests/auth/auth-requests";
import { DeviceInformation } from "../../utility/utility-functions";
import AsyncStorage from "@react-native-async-storage/async-storage";
import ekycStore from "../../store/ekyc-store";
import { Octicons, FontAwesome6, MaterialIcons } from "@expo/vector-icons";
import { Colors } from "../../assets/styles/colors";
import ValidationHelper from "../../utility/validationHelper";
import { FontStyle } from "../../assets/styles/commonStyles";
import validationHelper from "../../utility/validationHelper";
import {Toast} from "toastify-react-native";
import { CRM_Contact_Create_Req } from "../../apiRequests/auth/auth-requests";
const PageSetPassword = () => {
  const router = useRouter();
  const { loginData,preLogin, onChangeLoginData } = authStore();
  const {stage, ekyc1, ekyc2, ekyc3, ekyc4} = ekycStore();

  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);

  useEffect(() => {
    (async () => {
      let userMobileNumber = await AsyncStorage.getItem("MobileNumber");
      // console.log("userMobileFromPrelogin",preLogin?.MobileNumber)
      // console.log("userMobileNumberFromSession", userMobileNumber);
      userMobileNumber && onChangeLoginData({ mobileEmail: preLogin?.MobileNumber });
    })();
  }, []);

  const handleContinue = async () => {
    if(validationHelper.isEmpty(loginData?.password)) {
      Toast.error("A new password is required");
    }
    else if(validationHelper.isEmpty(confirmPassword)) {
      Toast.error("Please enter the password again");
    }
    else if(loginData?.password !== confirmPassword) {
      Toast.error("Password and Confirm Password didn't match");
    }
    else {
      if (stage === "ResetPassword") {
        const data = {
          UserReferenceID: await AsyncStorage.getItem("UserReferenceID"),
          NewPassword: loginData?.password,
          DeviceInfo: await DeviceInformation(),
        };
        console.log(data);
        Keyboard.dismiss();
        let success = await SetNewPasswordRequest(data);
        success && router.push("page-login");
      }
       else {
        let formData = new FormData();
        formData.append("Stage", "Step-6-Set-Password");
        formData.append("NewPassword", loginData?.password);
        formData.append(
          "RegistrationReferenceID",
          await AsyncStorage.getItem("RegistrationReferenceID")
        );
        console.log(formData);
        Keyboard.dismiss();
        let success = await EkycProcessRequest(formData, "Complete");
        if(success) {
          onChangeLoginData({ password: '' });
          //await CRM_Contact_Create_Req(preLogin,ekyc1,ekyc2,ekyc3,ekyc4);
          router.push("page-login");
        }
      }
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1 }}
    >
      <View style={styles.container}>
        <View style={{ alignItems: "center" }}>
          <IDLCLogo width={64} height={64} />
          <Text style={styles.headerText}>Set New Password</Text>
        </View>

        <View style={{ width: "100%" }}>
          <PTextInput
            value={loginData?.mobileEmail}
            onChange={(data) => {
              onChangeLoginData({ mobileEmail: data });
            }}
            leftIcon={<AntDesign name="user" size={20} color="#FFFFFF" />}
            label="Email or Mobile No."
            placeholder="Enter Mobile No or Email"
            style={{ marginBlock: 5 }}
            disabled
          />
          <PTextInput
            //   value={loginData?.password}
            onChange={(data) => {
              onChangeLoginData({ password: data });
            }}
            leftIcon={<PassIcon name="key-outline" size={20} color="#FFFFFF" />}
            rightIcon={
              <MaterialIcons
                name={passwordVisible ? "visibility-off" : "visibility"}
                size={26}
                color="#808080"
              />
            }
            rightIconPress={() => setPasswordVisible(!passwordVisible)}
            label="Password"
            secureTextEntry={!passwordVisible}
            placeholder="Set New Password"
            style={{ marginBlock: 5 }}
          />

          {!ValidationHelper.isEightCharactersLong(loginData?.password) ||
          !ValidationHelper.hasUpperAndLowerCase(loginData?.password) ||
          !ValidationHelper.isContainSpecialCharacter(loginData?.password) ||
          ValidationHelper.isEmpty(loginData?.password) ? (
            <View style={[styles.instructionContainer]}>
              {!ValidationHelper.isEightCharactersLong(loginData?.password) ? (
                <View style={styles.instructionStyle}>
                  <FontAwesome6
                    name={"square"}
                    size={20}
                    color={Colors.primary}
                  />
                  <Text style={[styles.instructionText, Colors.primary]}>
                    At least 8 Characters
                  </Text>
                </View>
              ) : (
                <View style={styles.instructionStyle}>
                  <FontAwesome6
                    name={"check-square"}
                    size={20}
                    color={"green"}
                  />
                  <Text style={[styles.instructionText, { color: "green" }]}>
                    At least 8 Characters
                  </Text>
                </View>
              )}
              {ValidationHelper.hasUpperAndLowerCase(loginData?.password) ? (
                <View style={[styles.instructionStyle, { marginTop: 5 }]}>
                  <FontAwesome6
                    name={"check-square"}
                    size={20}
                    color={"green"}
                  />
                  <Text style={[styles.instructionText, { color: "green" }]}>
                    1 Upper case & 1 Lower case
                  </Text>
                </View>
              ) : (
                  <View style={[styles.instructionStyle, { marginTop: 5 }]}>
                    <FontAwesome6
                        name={"square"}
                        size={20}
                        color={Colors.primary}
                    />
                    <Text
                        style={[styles.instructionText, { color: Colors.primary }]}
                    >
                      1 Upper case & 1 Lower case
                    </Text>
                  </View>
              ) }

              {!ValidationHelper.isContainSpecialCharacter(
                loginData?.password
              ) ? (
                <View style={[styles.instructionStyle, { marginTop: 5 }]}>
                  <FontAwesome6
                    name={"square"}
                    size={20}
                    color={Colors.primary}
                  />
                  <Text style={[styles.instructionText, Colors.primary]}>
                    1 Special Character
                  </Text>
                </View>
              ) : (
                <View style={[styles.instructionStyle, { marginTop: 5 }]}>
                  <FontAwesome6 name={"check-square"} size={20} color={"green"} />
                  <Text style={[styles.instructionText, { color: "green" }]}>
                    1 Special Character
                  </Text>
                </View>
              )}
            </View>
          ) : null}

          <PTextInput
            value={confirmPassword}
            onChange={setConfirmPassword}
            leftIcon={<PassIcon name="key-outline" size={20} color="#FFFFFF" />}
            rightIcon={
              <MaterialIcons
                name={confirmPasswordVisible ? "visibility-off" : "visibility"}
                size={26}
                color="#808080"
              />
            }
            rightIconPress={() =>
              setConfirmPasswordVisible(!confirmPasswordVisible)
            }
            label="Confirm Password"
            secureTextEntry={!confirmPasswordVisible}
            placeholder="Confirm New Password"
            style={{ marginBlock: 5 }}
          />

          {!ValidationHelper.isPasswordConfirmed(
            loginData?.password,
            confirmPassword
          ) || ValidationHelper.isEmpty(confirmPassword) ? (
            <View style={[styles.instructionContainer]}>
              <View style={styles.instructionStyle}>
                <FontAwesome6
                  name={"square"}
                  size={20}
                  color={Colors.primary}
                />
                <Text style={[styles.instructionText, Colors.primary]}>
                  Password & Confirm password match
                </Text>
              </View>
            </View>
          ) : null}

          <CButton
            icon="arrow-right"
            onPress={handleContinue}
            buttonStyles={{ marginTop: 20 }}
          >
            Next
          </CButton>
        </View>
        <View></View>
      </View>
    </KeyboardAvoidingView>
  );
};

export default PageSetPassword;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "space-evenly",
    alignItems: "center",
    padding: 30,
  },
  headerText: {
    fontSize: 24,
    textAlign: "center",
    marginTop: 30,
    fontFamily: FontStyle?.regular,
  },
  instructionContainer: {
    width: "100%",
    marginTop: 20,
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#CC0A13",
    backgroundColor: "rgb(254,226,226)",
  },
  instructionStyle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },

  instructionText: {
    fontSize: 16,
    marginLeft: 15,
    color: Colors.primary,
    fontFamily: FontStyle?.medium,
  },
});
