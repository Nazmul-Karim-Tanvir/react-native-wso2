import React from 'react';
import {Stack} from "expo-router";
import AuthNavLayout, {LandingNavLayout} from "../../layout/auth-nav-layout";
import {SafeAreaView} from "react-native-safe-area-context";
import FullScreenLoading from "../../layout/full-screen-loading";
import ToastManager from "toastify-react-native";
import {FontStyle} from "../../assets/styles/commonStyles";

const _AuthLayout = () => {
    return (
        <SafeAreaView style={{flex: 1}}>
            <FullScreenLoading />
            <Stack screenOptions={{header: AuthNavLayout, contentStyle: {backgroundColor: "#F6F3FE"}}}>
                <Stack.Screen name="index" options={{header: LandingNavLayout}} />
                <Stack.Screen name="page-webview" options={{headerShown: false}} />
            </Stack>
            <ToastManager textStyle={{fontSize: 16, fontFamily: FontStyle.medium}} height='auto' style={{paddingRight: 30}} />
        </SafeAreaView>
    );
};

export default _AuthLayout;
