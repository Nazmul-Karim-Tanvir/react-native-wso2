// import React, { useEffect, useRef, useState } from 'react';
// import { StyleSheet, Text, View, KeyboardAvoidingView, Platform, Keyboard, TouchableOpacity, Alert, Linking } from 'react-native';
// import { useRouter } from 'expo-router';
// import * as LocalAuthentication from 'expo-local-authentication';
// import * as SecureStore from 'expo-secure-store';
// import IDLCLogo from '../../assets/images/IDLC_Logo_mini.svg';
// import PTextInput from '../../components/ui-custom-component/paper-text-input';
// import CButton from '../../components/ui-custom-component/paper-button';
// import PersonIcon from 'react-native-vector-icons/FontAwesome5';
// import PassIcon from 'react-native-vector-icons/Ionicons';
// import authStore from '../../store/auth-store';
// import ekycStore from '../../store/ekyc-store';
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import { UserLoginRequests } from '../../apiRequests/auth/auth-requests';
// import { DeviceInformation } from '../../utility/utility-functions';
// import { FontStyle } from '../../assets/styles/commonStyles';
// import { MaterialIcons } from '@expo/vector-icons';
// import ValidateLogin from '../../validation/ValidateLogin';
// import DownloadOpenPdf from '../../utility/download-open-pdf';
//
//
// const PageLogin = () => {
//   const router = useRouter();
//   const { loginData, onChangeLoginData } = authStore();
//   const { ekyc1 } = ekycStore();
//   const inputRef = useRef(null);
//   const [passwordVisible, setPasswordVisible] = useState(false);
//   const [userName, setUserName] = useState('');
//   const [isBiometricSupported, setIsBiometricSupported] = useState(false);
//   const [isBiometricEnrolled, setIsBiometricEnrolled] = useState(false);
//   const [biometricType, setBiometricType] = useState('Biometrics');
//   const [credentialsStored, setCredentialsStored] = useState(false);
//
//   useEffect(() => {
//     (async () => {
//       // Retrieve stored data
//       let userMobileNumber = await AsyncStorage.getItem('MobileNumber');
//       let clientName = await AsyncStorage.getItem('ClientName');
//       let pushToken = await AsyncStorage.getItem('PushToken');
//       console.log('Push Token in Login: ', pushToken);
//       setUserName(clientName);
//       userMobileNumber && onChangeLoginData({ mobileEmail: loginData?.mobileEmail || userMobileNumber });
//
//       // Check for stored credentials
//       const credentialsJson = await SecureStore.getItemAsync('userCredentials');
//       setCredentialsStored(!!credentialsJson);
//
//       // Check biometric hardware
//       const compatible = await LocalAuthentication.hasHardwareAsync();
//       console.log('Biometric Hardware Supported:', compatible);
//       setIsBiometricSupported(compatible);
//
//       if (compatible) {
//         const enrolled = await LocalAuthentication.isEnrolledAsync();
//         console.log('Biometric Enrolled:', enrolled);
//         setIsBiometricEnrolled(enrolled);
//
//         // Get supported biometric types
//         const types = await LocalAuthentication.supportedAuthenticationTypesAsync();
//         console.log('Supported Biometric Types:', types);
//         const typeNames = types.map(type => {
//           switch (type) {
//             case LocalAuthentication.AuthenticationType.FINGERPRINT:
//               return 'Fingerprint';
//             case LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION:
//               return 'Face ID';
//             case LocalAuthentication.AuthenticationType.IRIS:
//               return 'Iris';
//             default:
//               return 'Biometrics';
//           }
//         });
//         console.log('types', typeNames);
//
//         // Prioritize Face ID for testing
//         let selectedType = typeNames.includes('Face ID') ? 'Face ID' : typeNames.includes('Fingerprint') ? 'Fingerprint' : 'Biometrics';
//         console.log('Selected Biometric Type:', selectedType);
//         setBiometricType(selectedType);
//       }
//     })();
//
//     const focusTimeout = setTimeout(() => {
//       if (inputRef.current) {
//         inputRef.current.focus();
//       }
//     }, 400);
//
//     return () => clearTimeout(focusTimeout);
//   }, []);
//
//   const handleContinue = async (credentials = null) => {
//     // Ignore event objects passed from onPress
//     if (credentials && typeof credentials === 'object' && credentials.nativeEvent) {
//       console.warn('Unexpected event object received in handleContinue:', credentials);
//       credentials = null; // Use loginData instead
//     }
//
//     const dataToValidate = credentials || loginData;
//     if (ValidateLogin(dataToValidate)) {
//       let data = {
//         emailOrMobileNumber: dataToValidate?.mobileEmail,
//         userPass: dataToValidate?.password,
//         deviceInfo: await DeviceInformation(),
//         pushNotificationToken: await AsyncStorage.getItem('PushToken'),
//       };
//       Keyboard.dismiss();
//       const success = await UserLoginRequests(data);
//       if (success) {
//         try {
//           await SecureStore.setItemAsync('userCredentials', JSON.stringify({
//             mobileEmail: dataToValidate.mobileEmail,
//             password: dataToValidate.password,
//           }));
//           setCredentialsStored(true);
//           console.log('Credentials stored successfully');
//         } catch (error) {
//           console.error('Error storing credentials:', error);
//           Alert.alert('Error', 'Failed to store credentials for biometric login.');
//         }
//         router.push({
//           pathname: 'page-webview',
//           params: {
//             Token: JSON.stringify(await AsyncStorage.getItem('Token')),
//             UserDetail: JSON.stringify(await AsyncStorage.getItem('UserDetail')),
//           },
//         });
//         onChangeLoginData({ password: '' });
//       }
//     }
//   };
//
//   const handleBiometricLogin = async () => {
//     if (!isBiometricSupported) {
//       Alert.alert('Error', 'Biometric hardware is not available on this device.');
//       return;
//     }
//     if (!isBiometricEnrolled) {
//       Alert.alert(
//           'Biometric Not Enrolled',
//           `Please enroll ${biometricType.toLowerCase()} in your device settings to use this feature.`,
//           [
//             { text: 'Cancel', style: 'cancel' },
//             {
//               text: 'Go to Settings',
//               onPress: () => Linking.openSettings(),
//             },
//           ]
//       );
//       return;
//     }
//     if (!credentialsStored) {
//       Alert.alert('Error', 'Please login with email/password first to enable biometric login.');
//       return;
//     }
//
//     try {
//       const result = await LocalAuthentication.authenticateAsync({
//         promptMessage: `Login with ${biometricType}`,
//         fallbackLabel: 'Use PIN',
//         cancelLabel: 'Cancel',
//         disableDeviceFallback: false,
//       });
//       console.log('Biometric Auth Result:', result);
//
//       if (result.success) {
//         const credentialsJson = await SecureStore.getItemAsync('userCredentials');
//         if (credentialsJson) {
//           const credentials = JSON.parse(credentialsJson);
//           await handleContinue(credentials);
//         } else {
//           Alert.alert('Error', 'No stored credentials found. Please login with email/password first.');
//         }
//       } else {
//         Alert.alert(
//             'Authentication Failed',
//             biometricType === 'Face ID'
//                 ? 'Facial recognition failed. Ensure your face is visible and try again, or use PIN/fingerprint.'
//                 : `Error: ${result.error}`,
//         );
//       }
//     } catch (error) {
//       console.error('Biometric Auth Error:', error);
//       Alert.alert(
//           'Error',
//           `An unexpected error occurred during ${biometricType.toLowerCase()} authentication. Please try again or use email/password.`,
//       );
//     }
//   };
//
//   return (
//       <KeyboardAvoidingView behavior={Platform.OS === 'android' ? undefined : 'padding'} style={{ flex: 1 }}>
//         <View style={styles.container}>
//           <View style={{ alignItems: 'center' }}>
//             <TouchableOpacity onPress={async () => {
//               await DownloadOpenPdf('https://pdfobject.com/pdf/sample.pdf');
//             }}>
//               <IDLCLogo width={64} height={64} style={{ marginBottom: 30 }} />
//             </TouchableOpacity>
//             <Text style={styles.subheaderText}>Good Morning, Mr. {userName?.split(' ')[userName?.split(' ').length - 1]}</Text>
//             <Text style={styles.headerText}>Login to IDLC App</Text>
//           </View>
//
//           <View style={{ width: '100%' }}>
//             <TouchableOpacity onPress={() => router.push('page-phone-entry')}>
//               <PTextInput
//                   value={loginData?.mobileEmail}
//                   onChange={(data) => { onChangeLoginData({ mobileEmail: data }); }}
//                   leftIcon={<PersonIcon name="user" size={20} color="#FFFFFF" />}
//                   label="Email or Mobile No."
//                   placeholder="Enter Mobile No or Email"
//                   style={{ marginBlock: 5 }}
//                   readOnly
//               />
//             </TouchableOpacity>
//             <PTextInput
//                 ref={inputRef}
//                 value={loginData?.password}
//                 onChange={(data) => { onChangeLoginData({ password: data }); }}
//                 leftIcon={<PassIcon name="key-outline" size={22} color="#FFFFFF" />}
//                 rightIcon={<MaterialIcons name={passwordVisible ? 'visibility' : 'visibility-off'} size={26} color="#808080" />}
//                 rightIconPress={() => setPasswordVisible(!passwordVisible)}
//                 label="Password"
//                 secureTextEntry={!passwordVisible}
//                 placeholder="Enter Password"
//                 style={{ marginBlock: 5 }}
//             />
//             <View style={{ flexDirection: 'row', justifyContent: 'flex-end' }}>
//               <CButton
//                   onPress={() => router.push('page-forgot-password')}
//                   mode="link"
//                   textStyle={{ fontSize: 16 }}
//                   buttonStyles={{ padding: 0, marginBlock: 10 }}
//               >
//                 Forgot Password?
//               </CButton>
//             </View>
//
//             <CButton
//                 icon="arrow-right"
//                 onPress={() => handleContinue()}
//                 buttonStyles={{ marginTop: 20 }}
//             >
//               Login
//             </CButton>
//             {isBiometricSupported && credentialsStored && (
//                 <CButton
//                     icon={biometricType === 'Face ID' ? 'face-recognition' : 'fingerprint'}
//                     onPress={handleBiometricLogin}
//                     buttonStyles={{ marginTop: 10 }}
//                 >
//                   Login with {biometricType}
//                 </CButton>
//             )}
//             {isBiometricSupported && !isBiometricEnrolled && (
//                 <Text style={{ textAlign: 'center', marginTop: 10, color: '#FF0000' }}>
//                   {biometricType} not enrolled.{' '}
//                   <Text
//                       style={{ color: '#0000FF', textDecorationLine: 'underline' }}
//                       onPress={() => Linking.openSettings()}
//                   >
//                     Enroll in Settings
//                   </Text>
//                 </Text>
//             )}
//             {isBiometricSupported && biometricType === 'Face ID' && (
//                 <Text style={{ textAlign: 'center', marginTop: 10, color: '#666' }}>
//                   If facial recognition doesn’t work, your device may default to fingerprint or PIN.
//                 </Text>
//             )}
//           </View>
//           <View></View>
//         </View>
//       </KeyboardAvoidingView>
//   );
// };
//
// export default PageLogin;
//
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'space-evenly',
//     alignItems: 'center',
//     padding: 30,
//   },
//   subheaderText: {
//     fontSize: 15,
//     textAlign: 'center',
//     fontFamily: FontStyle?.light,
//   },
//   headerText: {
//     fontSize: 30,
//     textAlign: 'center',
//     fontFamily: FontStyle?.medium,
//   },
// });


import React, { useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View, KeyboardAvoidingView, Platform, Keyboard, TouchableOpacity, Alert, Linking, LinearGradient } from 'react-native';
import { useRouter } from 'expo-router';
import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';
import IDLCLogo from '../../assets/images/IDLC_Logo_mini.svg';
import f1Svg from '../../assets/images/f1.svg';
import PTextInput from '../../components/ui-custom-component/paper-text-input';
import CButton from '../../components/ui-custom-component/paper-button';
import PersonIcon from 'react-native-vector-icons/FontAwesome5';
import PassIcon from 'react-native-vector-icons/Ionicons';
import authStore from '../../store/auth-store';
import ekycStore from '../../store/ekyc-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { UserLoginRequests } from '../../apiRequests/auth/auth-requests';
import { DeviceInformation } from '../../utility/utility-functions';
import { FontStyle } from '../../assets/styles/commonStyles';
import { MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';
import ValidateLogin from '../../validation/ValidateLogin';
import DownloadOpenPdf from '../../utility/download-open-pdf';
import { SvgXml } from 'react-native-svg';
import {Toast} from "toastify-react-native";
import { CRM_Contact_Create_Req } from '../../apiRequests/auth/auth-requests';


// Fallback SVG if f1.svg fails
const fallbackSvg = `
<svg width="72" height="75" viewBox="0 0 72 75" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M9.90361 69.1299C9.78161 69.1299 9.68262 69.0299 9.68262 68.9089V5.72394C9.68262 5.60194 9.78161 5.50293 9.90361 5.50293C10.0256 5.50293 10.1246 5.60294 10.1246 5.72394V68.9089C10.1256 69.0299 10.0256 69.1299 9.90361 69.1299Z" fill="#E9E9E9"/>
<path d="M20.2064 69.1299C20.0844 69.1299 19.9854 69.0299 19.9854 68.9089V5.72394C19.9854 5.60194 20.0844 5.50293 20.2064 5.50293C20.3284 5.50293 20.4273 5.60294 20.4273 5.72394V68.9089C20.4283 69.0299 20.3294 69.1299 20.2064 69.1299Z" fill="#E9E9E9"/>
<path d="M30.511 69.1299C30.389 69.1299 30.29 69.0299 30.29 68.9089V5.72394C30.29 5.60194 30.389 5.50293 30.511 5.50293C30.633 5.50293 30.7321 5.60294 30.7321 5.72394V68.9089C30.7321 69.0299 30.633 69.1299 30.511 69.1299Z" fill="#E9E9E9"/>
<path d="M40.8138 69.1299C40.6918 69.1299 40.5928 69.0299 40.5928 68.9089V5.72394C40.5928 5.60194 40.6918 5.50293 40.8138 5.50293C40.9358 5.50293 41.0348 5.60294 41.0348 5.72394V68.9089C41.0348 69.0299 40.9358 69.1299 40.8138 69.1299Z" fill="#E9E9E9"/>
<path d="M51.1165 69.1299C50.9945 69.1299 50.8955 69.0299 50.8955 68.9089V5.72394C50.8955 5.60194 50.9945 5.50293 51.1165 5.50293C51.2385 5.50293 51.3385 5.60294 51.3385 5.72394V68.9089C51.3385 69.0299 51.2395 69.1299 51.1165 69.1299Z" fill="#E9E9E9"/>
<path d="M61.4192 69.1299C61.2972 69.1299 61.1982 69.0299 61.1982 68.9089V5.72394C61.1982 5.60194 61.2972 5.50293 61.4192 5.50293C61.5412 5.50293 61.6402 5.60294 61.6402 5.72394V68.9089C61.6412 69.0299 61.5422 69.1299 61.4192 69.1299Z" fill="#E9E9E9"/>
<path d="M64.5887 11.7789H6.73466C6.61266 11.7789 6.51367 11.6799 6.51367 11.5579C6.51367 11.4359 6.61266 11.3369 6.73466 11.3369H64.5887C64.7107 11.3369 64.8097 11.4359 64.8097 11.5579C64.8097 11.6799 64.7107 11.7789 64.5887 11.7789Z" fill="#E9E9E9"/>
<path d="M64.5887 22.0827H6.73466C6.61266 22.0827 6.51367 21.9837 6.51367 21.8617C6.51367 21.7397 6.61266 21.6396 6.73466 21.6396H64.5887C64.7107 21.6396 64.8097 21.7397 64.8097 21.8617C64.8097 21.9837 64.7107 22.0827 64.5887 22.0827Z" fill="#E9E9E9"/>
<path d="M64.5887 32.3863H6.73466C6.61266 32.3863 6.51367 32.2863 6.51367 32.1653C6.51367 32.0433 6.61266 31.9443 6.73466 31.9443H64.5887C64.7107 31.9443 64.8097 32.0433 64.8097 32.1653C64.8097 32.2873 64.7107 32.3863 64.5887 32.3863Z" fill="#E9E9E9"/>
<path d="M64.5887 42.6901H6.73466C6.61266 42.6901 6.51367 42.5901 6.51367 42.4691C6.51367 42.3471 6.61266 42.2471 6.73466 42.2471H64.5887C64.7107 42.2471 64.8097 42.3471 64.8097 42.4691C64.8097 42.5901 64.7107 42.6901 64.5887 42.6901Z" fill="#E9E9E9"/>
<path d="M64.5887 52.9918H6.73466C6.61266 52.9918 6.51367 52.8928 6.51367 52.7708C6.51367 52.6488 6.61266 52.5498 6.73466 52.5498H64.5887C64.7107 52.5498 64.8097 52.6488 64.8097 52.7708C64.8097 52.8928 64.7107 52.9918 64.5887 52.9918Z" fill="#E9E9E9"/>
<path d="M64.5887 63.2955H6.73466C6.61266 63.2955 6.51367 63.1965 6.51367 63.0745C6.51367 62.9525 6.61266 62.8535 6.73466 62.8535H64.5887C64.7107 62.8535 64.8097 62.9525 64.8097 63.0745C64.8097 63.1965 64.7107 63.2955 64.5887 63.2955Z" fill="#E9E9E9"/>
<path d="M20.0412 22.1298C19.8962 22.1298 19.7493 22.0937 19.6133 22.0187C19.1853 21.7817 19.0303 21.2418 19.2673 20.8148C21.9253 16.0168 27.1593 10.5187 33.8793 9.47775C38.0773 8.82575 42.5902 9.88574 45.9512 12.3127C46.3482 12.5987 46.4383 13.1517 46.1513 13.5497C45.8663 13.9477 45.3123 14.0368 44.9143 13.7498C41.9663 11.6238 37.8432 10.6558 34.1492 11.2298C28.0622 12.1738 23.2712 17.2437 20.8162 21.6747C20.6562 21.9657 20.3532 22.1298 20.0412 22.1298Z" fill="url(#paint0_linear_3676_216)"/>
<path d="M35.6303 65.3423C34.5593 65.3423 33.4723 65.2494 32.3713 65.0614C25.2663 63.8504 19.1753 59.0543 16.4763 52.5443C13.1493 44.5213 13.5943 33.9403 17.6983 23.5153C17.8783 23.0603 18.3913 22.8373 18.8473 23.0153C19.3033 23.1943 19.5263 23.7094 19.3473 24.1644C15.4103 34.1664 14.9603 44.2634 18.1133 51.8664C20.5813 57.8174 26.1593 62.2044 32.6693 63.3154C37.7993 64.1864 42.6243 62.7903 46.6273 59.2663C52.2273 54.3353 55.6173 45.7143 55.2623 37.3033C54.5623 20.7003 47.2383 16.0683 47.1643 16.0233C46.7473 15.7703 46.6113 15.2274 46.8623 14.8094C47.1133 14.3904 47.6533 14.2513 48.0713 14.5013C48.4063 14.6993 56.2893 19.5654 57.0333 37.2294C57.4093 46.1534 53.7843 55.3253 47.7993 60.5963C44.2373 63.7313 40.0803 65.3423 35.6303 65.3423Z" fill="url(#paint1_linear_3676_216)"/>
<path d="M23.494 56.5739C23.253 56.5739 23.013 56.4759 22.838 56.2829C16.761 49.5929 17.453 39.7889 18.502 32.9969C20.018 23.1829 26.921 12.7539 36.728 12.7539H36.7291C46.1311 12.7539 50.6491 22.6779 50.8371 23.0999C51.0361 23.5469 50.8341 24.0699 50.3881 24.2689C49.9441 24.4669 49.419 24.2679 49.218 23.8209C49.176 23.7279 44.971 14.5269 36.73 14.5269C28.229 14.5259 21.678 24.0549 20.254 33.2679C19.26 39.7019 18.5831 48.9639 24.1511 55.0939C24.4801 55.4559 24.4531 56.0159 24.0911 56.3449C23.9201 56.4979 23.707 56.5739 23.494 56.5739Z" fill="url(#paint2_linear_3676_216)"/>
<path d="M51.0901 49.8735C50.9891 49.8735 50.8871 49.8565 50.7871 49.8195C50.3271 49.6515 50.0901 49.1435 50.2581 48.6835C54.6151 36.7295 50.3661 26.7195 50.3221 26.6195C50.1271 26.1715 50.3321 25.6485 50.7801 25.4535C51.2281 25.2595 51.7501 25.4615 51.9461 25.9095C52.1361 26.3425 56.5321 36.6425 51.9231 49.2915C51.7911 49.6495 51.4521 49.8735 51.0901 49.8735Z" fill="url(#paint3_linear_3676_216)"/>
<path d="M34.9551 62.2141C31.1511 62.2141 27.88 60.8992 25.036 58.2432C24.679 57.9092 24.659 57.3481 24.993 56.9911C25.327 56.6341 25.8881 56.6152 26.2451 56.9492C29.7171 60.1912 33.7601 61.1471 38.9681 59.9571C46.1471 58.3161 48.8341 51.6152 48.8601 51.5482C49.0381 51.0932 49.55 50.8671 50.006 51.0431C50.462 51.2201 50.6881 51.7312 50.5131 52.1872C50.3931 52.4982 47.4811 59.8291 39.3621 61.6851C37.8191 62.0371 36.3511 62.2141 34.9551 62.2141Z" fill="url(#paint4_linear_3676_216)"/>
<path d="M35.1016 58.8356C33.2736 58.8356 31.4577 58.3856 29.7237 57.4726C23.6817 54.2916 20.3587 46.2617 21.4527 37.4877C21.5127 37.0017 21.9586 36.6566 22.4416 36.7186C22.9276 36.7796 23.2717 37.2227 23.2117 37.7077C22.0527 46.9997 26.0627 53.5416 30.5507 55.9036C34.5157 57.9926 39.0297 57.1987 42.9357 53.7327C49.4997 47.9067 50.4887 36.1366 47.6517 28.1236C46.4817 24.8176 43.6106 19.2297 37.5326 18.9537C27.0556 18.4697 23.5666 34.6777 23.5326 34.8417C23.4336 35.3207 22.9657 35.6277 22.4857 35.5307C22.0067 35.4307 21.6987 34.9627 21.7977 34.4837C21.9487 33.7537 25.6287 16.6386 37.6137 17.1836C42.8097 17.4196 47.0777 21.1916 49.3227 27.5316C52.3547 36.0986 51.2347 48.7366 44.1117 55.0576C41.2947 57.5576 38.1806 58.8356 35.1016 58.8356Z" fill="url(#paint5_linear_3676_216)"/>
<path d="M35.4163 55.7711C34.9503 55.7711 34.5593 55.4081 34.5323 54.9361C34.5043 54.4481 34.8773 54.0291 35.3653 54.0011C35.8473 53.9701 46.4973 53.0991 46.0323 37.9571C45.8413 31.7181 44.3363 27.3481 41.5603 24.9701C39.1733 22.9251 36.5683 23.0661 35.8243 23.1571C30.1153 23.8651 27.3363 31.7661 26.5943 36.3241C26.0573 39.6281 24.9433 50.6371 33.1813 53.5621C33.6423 53.7261 33.8833 54.2331 33.7203 54.6941C33.5573 55.1541 33.0493 55.3971 32.5893 55.2321C23.0573 51.8491 24.2523 39.6871 24.8463 36.0411C25.8653 29.7761 29.2953 22.1811 35.6063 21.4001C36.5313 21.2861 39.7743 21.1071 42.7133 23.6251C45.8843 26.3411 47.5973 31.1461 47.8043 37.9041C48.3233 54.8331 35.5973 55.7631 35.4683 55.7701C35.4513 55.7701 35.4333 55.7711 35.4163 55.7711Z" fill="url(#paint6_linear_3676_216)"/>
<path d="M35.0759 52.2546C34.6059 52.2546 34.2139 51.8856 34.1919 51.4106C34.1689 50.9236 34.5449 50.5086 35.0319 50.4836C35.3379 50.4666 42.4329 49.9516 42.4329 39.7766C42.4329 34.2536 41.1899 30.1275 38.9349 28.1565C37.8649 27.2215 36.6139 26.8176 35.3209 26.9956C33.7759 27.2036 29.9139 31.1126 29.3419 36.7656C29.2929 37.2526 28.8539 37.5996 28.3709 37.5586C27.8839 37.5096 27.5289 37.0745 27.5789 36.5875C28.2169 30.2905 32.5179 25.5866 35.0829 25.2396C36.8759 25.0006 38.6559 25.5596 40.1009 26.8226C41.9729 28.4586 44.2049 32.0345 44.2049 39.7775C44.2049 51.6895 35.2089 52.2506 35.1179 52.2546C35.1039 52.2546 35.0899 52.2546 35.0759 52.2546Z" fill="url(#paint7_linear_3676_216)"/>
<path d="M32.5207 51.5532C32.3887 51.5532 32.2537 51.5242 32.1267 51.4602C26.4077 48.6112 27.3886 40.0332 27.4336 39.6682C27.4926 39.1832 27.9397 38.8382 28.4197 38.8972C28.9047 38.9562 29.2507 39.3972 29.1927 39.8832C29.1837 39.9592 28.3207 47.5832 32.9167 49.8722C33.3547 50.0912 33.5327 50.6222 33.3147 51.0612C33.1587 51.3732 32.8457 51.5532 32.5207 51.5532Z" fill="url(#paint8_linear_3676_216)"/>
<path d="M36.988 48.9314C36.7 48.9314 36.418 48.7924 36.248 48.5344C35.978 48.1264 36.091 47.5764 36.499 47.3064C38.311 46.1084 39.222 43.1504 39.47 40.7824C39.793 37.7034 39.142 33.2694 37.529 31.4784C37.091 30.9924 36.627 30.7554 36.109 30.7554C34.399 30.7554 32.363 35.3254 31.877 38.2894C31.313 41.7324 32.227 45.2804 33.421 46.1534C33.728 46.3764 34.018 46.3924 34.389 46.2024C35.415 45.6804 36.176 43.9154 36.423 41.4804C36.714 38.6234 36.218 36.1354 35.784 35.3624C34.172 37.3704 34.365 41.9464 35.098 43.5394C35.303 43.9844 35.108 44.5104 34.664 44.7144C34.221 44.9204 33.694 44.7244 33.489 44.2804C32.554 42.2484 32.241 36.6944 34.552 34.0754C35.253 33.2814 35.976 33.4144 36.256 33.5074C37.701 33.9944 38.113 36.7704 38.231 38.3814C38.485 41.8754 37.843 46.4334 35.194 47.7824C34.227 48.2744 33.227 48.2044 32.376 47.5834C30.243 46.0244 29.558 41.4864 30.129 38.0014C30.422 36.2124 32.408 28.9834 36.109 28.9834C37.128 28.9834 38.075 29.4354 38.846 30.2914C41.133 32.8314 41.524 38.1864 41.233 40.9674C41.053 42.6904 40.325 46.9014 37.476 48.7844C37.326 48.8844 37.156 48.9314 36.988 48.9314Z" fill="url(#paint9_linear_3676_216)"/>
<path d="M20.0412 22.1298C19.8962 22.1298 19.7493 22.0937 19.6133 22.0187C19.1853 21.7817 19.0303 21.2418 19.2673 20.8148C21.9253 16.0168 27.1593 10.5187 33.8793 9.47775C38.0773 8.82575 42.5902 9.88574 45.9512 12.3127C46.3482 12.5987 46.4383 13.1517 46.1513 13.5497C45.8663 13.9477 45.3123 14.0368 44.9143 13.7498C41.9663 11.6238 37.8432 10.6558 34.1492 11.2298C28.0622 12.1738 23.2712 17.2437 20.8162 21.6747C20.6562 21.9657 20.3532 22.1298 20.0412 22.1298Z" fill="url(#paint10_linear_3676_216)"/>
<path d="M35.6303 65.3423C34.5593 65.3423 33.4723 65.2494 32.3713 65.0614C25.2663 63.8504 19.1753 59.0543 16.4763 52.5443C13.1493 44.5213 13.5943 33.9403 17.6983 23.5153C17.8783 23.0603 18.3913 22.8373 18.8473 23.0153C19.3033 23.1943 19.5263 23.7094 19.3473 24.1644C15.4103 34.1664 14.9603 44.2634 18.1133 51.8664C20.5813 57.8174 26.1593 62.2044 32.6693 63.3154C37.7993 64.1864 42.6243 62.7903 46.6273 59.2663C52.2273 54.3353 55.6173 45.7143 55.2623 37.3033C54.5623 20.7003 47.2383 16.0683 47.1643 16.0233C46.7473 15.7703 46.6113 15.2274 46.8623 14.8094C47.1133 14.3904 47.6533 14.2513 48.0713 14.5013C48.4063 14.6993 56.2893 19.5654 57.0333 37.2294C57.4093 46.1534 53.7843 55.3253 47.7993 60.5963C44.2373 63.7313 40.0803 65.3423 35.6303 65.3423Z" fill="url(#paint11_linear_3676_216)"/>
<path d="M23.494 56.5739C23.253 56.5739 23.013 56.4759 22.838 56.2829C16.761 49.5929 17.453 39.7889 18.502 32.9969C20.018 23.1829 26.921 12.7539 36.728 12.7539H36.7291C46.1311 12.7539 50.6491 22.6779 50.8371 23.0999C51.0361 23.5469 50.8341 24.0699 50.3881 24.2689C49.9441 24.4669 49.419 24.2679 49.218 23.8209C49.176 23.7279 44.971 14.5269 36.73 14.5269C28.229 14.5259 21.678 24.0549 20.254 33.2679C19.26 39.7019 18.5831 48.9639 24.1511 55.0939C24.4801 55.4559 24.4531 56.0159 24.0911 56.3449C23.9201 56.4979 23.707 56.5739 23.494 56.5739Z" fill="url(#paint12_linear_3676_216)"/>
<path d="M51.0901 49.8735C50.9891 49.8735 50.8871 49.8565 50.7871 49.8195C50.3271 49.6515 50.0901 49.1435 50.2581 48.6835C54.6151 36.7295 50.3661 26.7195 50.3221 26.6195C50.1271 26.1715 50.3321 25.6485 50.7801 25.4535C51.2281 25.2595 51.7501 25.4615 51.9461 25.9095C52.1361 26.3425 56.5321 36.6425 51.9231 49.2915C51.7911 49.6495 51.4521 49.8735 51.0901 49.8735Z" fill="url(#paint13_linear_3676_216)"/>
<path d="M34.9551 62.2141C31.1511 62.2141 27.88 60.8992 25.036 58.2432C24.679 57.9092 24.659 57.3481 24.993 56.9911C25.327 56.6341 25.8881 56.6152 26.2451 56.9492C29.7171 60.1912 33.7601 61.1471 38.9681 59.9571C46.1471 58.3161 48.8341 51.6152 48.8601 51.5482C49.0381 51.0932 49.55 50.8671 50.006 51.0431C50.462 51.2201 50.6881 51.7312 50.5131 52.1872C50.3931 52.4982 47.4811 59.8291 39.3621 61.6851C37.8191 62.0371 36.3511 62.2141 34.9551 62.2141Z" fill="url(#paint14_linear_3676_216)"/>
<path d="M35.1016 58.8356C33.2736 58.8356 31.4577 58.3856 29.7237 57.4726C23.6817 54.2916 20.3587 46.2617 21.4527 37.4877C21.5127 37.0017 21.9586 36.6566 22.4416 36.7186C22.9276 36.7796 23.2717 37.2227 23.2117 37.7077C22.0527 46.9997 26.0627 53.5416 30.5507 55.9036C34.5157 57.9926 39.0297 57.1987 42.9357 53.7327C49.4997 47.9067 50.4887 36.1366 47.6517 28.1236C46.4817 24.8176 43.6106 19.2297 37.5326 18.9537C27.0556 18.4697 23.5666 34.6777 23.5326 34.8417C23.4336 35.3207 22.9657 35.6277 22.4857 35.5307C22.0067 35.4307 21.6987 34.9627 21.7977 34.4837C21.9487 33.7537 25.6287 16.6386 37.6137 17.1836C42.8097 17.4196 47.0777 21.1916 49.3227 27.5316C52.3547 36.0986 51.2347 48.7366 44.1117 55.0576C41.2947 57.5576 38.1806 58.8356 35.1016 58.8356Z" fill="url(#paint15_linear_3676_216)"/>
<path d="M35.4163 55.7711C34.9503 55.7711 34.5593 55.4081 34.5323 54.9361C34.5043 54.4481 34.8773 54.0291 35.3653 54.0011C35.8473 53.9701 46.4973 53.0991 46.0323 37.9571C45.8413 31.7181 44.3363 27.3481 41.5603 24.9701C39.1733 22.9251 36.5683 23.0661 35.8243 23.1571C30.1153 23.8651 27.3363 31.7661 26.5943 36.3241C26.0573 39.6281 24.9433 50.6371 33.1813 53.5621C33.6423 53.7261 33.8833 54.2331 33.7203 54.6941C33.5573 55.1541 33.0493 55.3971 32.5893 55.2321C23.0573 51.8491 24.2523 39.6871 24.8463 36.0411C25.8653 29.7761 29.2953 22.1811 35.6063 21.4001C36.5313 21.2861 39.7743 21.1071 42.7133 23.6251C45.8843 26.3411 47.5973 31.1461 47.8043 37.9041C48.3233 54.8331 35.5973 55.7631 35.4683 55.7701C35.4513 55.7701 35.4333 55.7711 35.4163 55.7711Z" fill="url(#paint16_linear_3676_216)"/>
<path d="M35.0759 52.2546C34.6059 52.2546 34.2139 51.8856 34.1919 51.4106C34.1689 50.9236 34.5449 50.5086 35.0319 50.4836C35.3379 50.4666 42.4329 49.9516 42.4329 39.7766C42.4329 34.2536 41.1899 30.1275 38.9349 28.1565C37.8649 27.2215 36.6139 26.8176 35.3209 26.9956C33.7759 27.2036 29.9139 31.1126 29.3419 36.7656C29.2929 37.2526 28.8539 37.5996 28.3709 37.5586C27.8839 37.5096 27.5289 37.0745 27.5789 36.5875C28.2169 30.2905 32.5179 25.5866 35.0829 25.2396C36.8759 25.0006 38.6559 25.5596 40.1009 26.8226C41.9729 28.4586 44.2049 32.0345 44.2049 39.7775C44.2049 51.6895 35.2089 52.2506 35.1179 52.2546C35.1039 52.2546 35.0899 52.2546 35.0759 52.2546Z" fill="url(#paint17_linear_3676_216)"/>
<path d="M32.5207 51.5532C32.3887 51.5532 32.2537 51.5242 32.1267 51.4602C26.4077 48.6112 27.3886 40.0332 27.4336 39.6682C27.4926 39.1832 27.9397 38.8382 28.4197 38.8972C28.9047 38.9562 29.2507 39.3972 29.1927 39.8832C29.1837 39.9592 28.3207 47.5832 32.9167 49.8722C33.3547 50.0912 33.5327 50.6222 33.3147 51.0612C33.1587 51.3732 32.8457 51.5532 32.5207 51.5532Z" fill="url(#paint18_linear_3676_216)"/>
<path d="M36.988 48.9314C36.7 48.9314 36.418 48.7924 36.248 48.5344C35.978 48.1264 36.091 47.5764 36.499 47.3064C38.311 46.1084 39.222 43.1504 39.47 40.7824C39.793 37.7034 39.142 33.2694 37.529 31.4784C37.091 30.9924 36.627 30.7554 36.109 30.7554C34.399 30.7554 32.363 35.3254 31.877 38.2894C31.313 41.7324 32.227 45.2804 33.421 46.1534C33.728 46.3764 34.018 46.3924 34.389 46.2024C35.415 45.6804 36.176 43.9154 36.423 41.4804C36.714 38.6234 36.218 36.1354 35.784 35.3624C34.172 37.3704 34.365 41.9464 35.098 43.5394C35.303 43.9844 35.108 44.5104 34.664 44.7144C34.221 44.9204 33.694 44.7244 33.489 44.2804C32.554 42.2484 32.241 36.6944 34.552 34.0754C35.253 33.2814 35.976 33.4144 36.256 33.5074C37.701 33.9944 38.113 36.7704 38.231 38.3814C38.485 41.8754 37.843 46.4334 35.194 47.7824C34.227 48.2744 33.227 48.2044 32.376 47.5834C30.243 46.0244 29.558 41.4864 30.129 38.0014C30.422 36.2124 32.408 28.9834 36.109 28.9834C37.128 28.9834 38.075 29.4354 38.846 30.2914C41.133 32.8314 41.524 38.1864 41.233 40.9674C41.053 42.6904 40.325 46.9014 37.476 48.7844C37.326 48.8844 37.156 48.9314 36.988 48.9314Z" fill="url(#paint19_linear_3676_216)"/>
<path d="M0 9.44699H1.69199V1.69299H9.44699V0H0V9.44699Z" fill="url(#paint20_linear_3676_216)" fill-opacity="0.8"/>
<path d="M61.8779 0V1.69299H69.6319V9.44699H71.3249V0H61.8779Z" fill="url(#paint21_linear_3676_216)" fill-opacity="0.8"/>
<path d="M69.6319 72.9386H61.8779V74.6316H71.3249V65.1846H69.6319V72.9386Z" fill="url(#paint22_linear_3676_216)" fill-opacity="0.8"/>
<path d="M1.69199 65.1846H0V74.6316H9.44699V72.9386H1.69199V65.1846Z" fill="url(#paint23_linear_3676_216)" fill-opacity="0.8"/>
<path d="M5 13.2279H6.47364V6.47451H13.2279V5H5V13.2279Z" fill="url(#paint24_linear_3676_216)" fill-opacity="0.8"/>
<path d="M58.8926 5V6.47451H65.6459V13.2279H67.1204V5H58.8926Z" fill="url(#paint25_linear_3676_216)" fill-opacity="0.8"/>
<path d="M65.6459 68.5258H58.8926V70.0003H67.1204V61.7725H65.6459V68.5258Z" fill="url(#paint26_linear_3676_216)" fill-opacity="0.8"/>
<path d="M6.47364 61.7725H5V70.0003H13.2279V68.5258H6.47364V61.7725Z" fill="url(#paint27_linear_3676_216)" fill-opacity="0.8"/>
<defs>
<linearGradient id="paint0_linear_3676_216" x1="38.0296" y1="9.33738" x2="35.9947" y2="26.3773" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint1_linear_3676_216" x1="44" y1="14.5687" x2="25.0756" y2="77.4722" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint2_linear_3676_216" x1="40.8101" y1="12.9188" x2="23.0728" y2="65.9677" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint3_linear_3676_216" x1="52.8559" y1="25.4721" x2="38.1255" y2="34.558" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint4_linear_3676_216" x1="42.6933" y1="51.0257" x2="41.0521" y2="65.9613" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint5_linear_3676_216" x1="41.8521" y1="17.3277" x2="24.1761" y2="67.1331" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint6_linear_3676_216" x1="40.689" y1="21.4743" x2="25.5413" y2="62.1725" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint7_linear_3676_216" x1="39.1296" y1="25.2874" x2="26.3156" y2="56.4522" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint8_linear_3676_216" x1="31.5568" y1="38.9383" x2="24.5242" y2="52.2723" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint9_linear_3676_216" x1="37.8438" y1="29.0585" x2="27.904" y2="51.5062" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint10_linear_3676_216" x1="38.0296" y1="9.33738" x2="35.9947" y2="26.3773" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint11_linear_3676_216" x1="44" y1="14.5687" x2="25.0756" y2="77.4722" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint12_linear_3676_216" x1="40.8101" y1="12.9188" x2="23.0728" y2="65.9677" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint13_linear_3676_216" x1="52.8559" y1="25.4721" x2="38.1255" y2="34.558" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint14_linear_3676_216" x1="42.6933" y1="51.0257" x2="41.0521" y2="65.9613" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint15_linear_3676_216" x1="41.8521" y1="17.3277" x2="24.1761" y2="67.1331" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint16_linear_3676_216" x1="40.689" y1="21.4743" x2="25.5413" y2="62.1725" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint17_linear_3676_216" x1="39.1296" y1="25.2874" x2="26.3156" y2="56.4522" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint18_linear_3676_216" x1="31.5568" y1="38.9383" x2="24.5242" y2="52.2723" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint19_linear_3676_216" x1="37.8438" y1="29.0585" x2="27.904" y2="51.5062" gradientUnits="userSpaceOnUse">
<stop stop-color="#CC0A13"/>
<stop offset="1" stop-color="#FFBFBF"/>
</linearGradient>
<linearGradient id="paint20_linear_3676_216" x1="12.1051" y1="10.7605" x2="-3.4842" y2="9.50185" gradientUnits="userSpaceOnUse">
<stop offset="0.528846" stop-color="#ED1C24"/>
<stop offset="1" stop-color="#F9857B" stop-opacity="0.5"/>
</linearGradient>
<linearGradient id="paint21_linear_3676_216" x1="73.9831" y1="10.7605" x2="58.3937" y2="9.50185" gradientUnits="userSpaceOnUse">
<stop offset="0.528846" stop-color="#ED1C24"/>
<stop offset="1" stop-color="#F9857B" stop-opacity="0.5"/>
</linearGradient>
<linearGradient id="paint22_linear_3676_216" x1="73.9831" y1="75.9451" x2="58.3937" y2="74.6864" gradientUnits="userSpaceOnUse">
<stop offset="0.528846" stop-color="#ED1C24"/>
<stop offset="1" stop-color="#F9857B" stop-opacity="0.5"/>
</linearGradient>
<linearGradient id="paint23_linear_3676_216" x1="12.1051" y1="75.9451" x2="-3.4842" y2="74.6864" gradientUnits="userSpaceOnUse">
<stop offset="0.528846" stop-color="#ED1C24"/>
<stop offset="1" stop-color="#F9857B" stop-opacity="0.5"/>
</linearGradient>
<linearGradient id="paint24_linear_3676_216" x1="15.543" y1="14.3719" x2="1.96543" y2="13.2757" gradientUnits="userSpaceOnUse">
<stop offset="0.528846" stop-color="#ED1C24"/>
<stop offset="1" stop-color="#F9857B" stop-opacity="0.5"/>
</linearGradient>
<linearGradient id="paint25_linear_3676_216" x1="69.4356" y1="14.3719" x2="55.858" y2="13.2757" gradientUnits="userSpaceOnUse">
<stop offset="0.528846" stop-color="#ED1C24"/>
<stop offset="1" stop-color="#F9857B" stop-opacity="0.5"/>
</linearGradient>
<linearGradient id="paint26_linear_3676_216" x1="69.4356" y1="71.1444" x2="55.858" y2="70.0481" gradientUnits="userSpaceOnUse">
<stop offset="0.528846" stop-color="#ED1C24"/>
<stop offset="1" stop-color="#F9857B" stop-opacity="0.5"/>
</linearGradient>
<linearGradient id="paint27_linear_3676_216" x1="15.543" y1="71.1444" x2="1.96543" y2="70.0481" gradientUnits="userSpaceOnUse">
<stop offset="0.528846" stop-color="#ED1C24"/>
<stop offset="1" stop-color="#F9857B" stop-opacity="0.5"/>
</linearGradient>
</defs>
</svg>

`;

const fingerIconXml = fallbackSvg;

const PageLogin = () => {
  const router = useRouter();
  const { loginData,preLogin, onChangeLoginData } = authStore();
  const {ekyc1, ekyc2, ekyc3, ekyc4} = ekycStore();
  const inputRef = useRef(null);
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [userName, setUserName] = useState('');
  const [isBiometricSupported, setIsBiometricSupported] = useState(false);
  const [isBiometricEnrolled, setIsBiometricEnrolled] = useState(false);
  const [biometricType, setBiometricType] = useState('Biometrics');
  const [credentialsStored, setCredentialsStored] = useState(false);

  useEffect(() => {
    (async () => {
      let userMobileNumber = await AsyncStorage.getItem('MobileNumber');
      let clientName = await AsyncStorage.getItem('ClientName');
      let pushToken = await AsyncStorage.getItem('PushToken');
      console.log('Push Token in Login: ', pushToken);
      setUserName(clientName);
      userMobileNumber && onChangeLoginData({ mobileEmail: loginData?.mobileEmail || userMobileNumber });
      console.log("user Details,", JSON.stringify(await AsyncStorage.getItem('UserDetail')));
      //await CRM_Contact_Create_Req(preLogin,ekyc1,ekyc2,ekyc3,ekyc4);

      // Check for stored credentials
      const credentialsJson = await SecureStore.getItemAsync('userCredentials');
      setCredentialsStored(!!credentialsJson);

      // Check biometric hardware
      const compatible = await LocalAuthentication.hasHardwareAsync();
      console.log('Biometric Hardware Supported:', compatible);
      setIsBiometricSupported(compatible);

      if (compatible) {
        const enrolled = await LocalAuthentication.isEnrolledAsync();
        console.log('Biometric Enrolled:', enrolled);
        setIsBiometricEnrolled(enrolled);

        // Get supported biometric types
        const types = await LocalAuthentication.supportedAuthenticationTypesAsync();
        console.log('Supported Biometric Types:', types);
        const typeNames = types.map(type => {
          switch (type) {
            case LocalAuthentication.AuthenticationType.FINGERPRINT:
              return 'Fingerprint';
            case LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION:
              return 'Face ID';
            case LocalAuthentication.AuthenticationType.IRIS:
              return 'Iris';
            default:
              return 'Biometrics';
          }
        });
        console.log('types', typeNames);

        // PLATFORM
        let selectedType = Platform.OS === 'android' ? 'Fingerprint' : 'Face ID';
        console.log('Selected Biometric Type:', selectedType);
        setBiometricType(selectedType);
      }
    })();

    const focusTimeout = setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }, 400);

    return () => clearTimeout(focusTimeout);
  }, []);

  const handleContinue = async (credentials = null) => {
    // Ignore event objects passed from onPress
    if (credentials && typeof credentials === 'object' && credentials.nativeEvent) {
      console.warn('Unexpected event object received in handleContinue:', credentials);
      credentials = null; // Use loginData instead
    }

    const dataToValidate = credentials || loginData;
    if (ValidateLogin(dataToValidate)) {
      let data = {
        emailOrMobileNumber: dataToValidate?.mobileEmail,
        userPass: dataToValidate?.password,
        deviceInfo: await DeviceInformation(),
        pushNotificationToken: await AsyncStorage.getItem('PushToken'),
      };
      Keyboard.dismiss();
      const success = await UserLoginRequests(data);
      if (success) {
        try {
          await SecureStore.setItemAsync('userCredentials', JSON.stringify({
            mobileEmail: dataToValidate.mobileEmail,
            password: dataToValidate.password,
          }));
          setCredentialsStored(true);
          console.log('Credentials stored successfully');
        } catch (error) {
          console.error('Error storing credentials:', error);
          Alert.alert('Error', 'Failed to store credentials for biometric login.');
        }
        router.push({
          pathname: 'page-webview',
          params: {
            Token: JSON.stringify(await AsyncStorage.getItem('Token')),
            UserDetail: JSON.stringify(await AsyncStorage.getItem('UserDetail')),
          },
        });
        onChangeLoginData({ password: '' });
      }
    }
  };

  const handleBiometricLogin = async () => {
    if (!isBiometricSupported) {
      //Alert.alert('Error', 'Biometric hardware is not available on this device.');
      Toast.error("Biometric hardware is not available on this device.");
      return;
    }
    if (!isBiometricEnrolled) {
      Alert.alert(
          'Biometric Not Enrolled',
          `Please enroll ${biometricType.toLowerCase()} in your device settings to use this feature.`,
          [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Go to Settings',
              onPress: () => Linking.openSettings(),
            },
          ]
      );
      return;
    }
    if (!credentialsStored) {
      Alert.alert('Error', 'Please login with email/password first to enable biometric login.');
      
      return;
    }

    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: `Login With ${biometricType}`,
        cancelLabel: 'Cancel',
        disableDeviceFallback: true,
      });
      console.log('Biometric Auth Result:', result);

      if (result.success) {
        const credentialsJson = await SecureStore.getItemAsync('userCredentials');
        if (credentialsJson) {
          const credentials = JSON.parse(credentialsJson);
          await handleContinue(credentials);
        } else {
          //Alert.alert('Error', 'No stored credentials found. Please login with email/password first.');
          Toast.error("No stored credentials found. Please login with email/password first.");
        }
      } 
      // else {
      //   Alert.alert(
      //       'Authentication Failed',
      //       biometricType === 'Face ID'
      //           ? 'Facial recognition failed. Ensure your face is visible and try again, or use Password.'
      //           : 'Fingerprint authentication failed. Ensure your finger is on the sensor and try again, or use Password.',
      //   );
      // }
    } 
    catch (error) {
      console.error('Biometric Auth Error:', error);
      Toast.error("An unexpected error occurred during ${biometricType.toLowerCase()} authentication. Please try again or use email/password.");
      // Alert.alert(
      //     'Error',
      //     `An unexpected error occurred during ${biometricType.toLowerCase()} authentication. Please try again or use email/password.`,
      // );
    }
  };

  return (
      <KeyboardAvoidingView behavior={Platform.OS === 'android' ? undefined : 'padding'} style={{ flex: 1 }}>
        <View style={styles.container}>
          <View style={styles.headerContainer}>
            <TouchableOpacity onPress={async () => {
              await DownloadOpenPdf('https://pdfobject.com/pdf/sample.pdf');
            }}>
              <IDLCLogo width={64} height={64} style={styles.logo} />
            </TouchableOpacity>
            <Text style={styles.subheaderText}>Good Morning, Mr. {userName?.split(' ')[userName?.split(' ').length - 1]}</Text>
            <Text style={styles.headerText}>Login to IDLC App</Text>
          </View>

          <View style={styles.inputContainer}>
            <TouchableOpacity onPress={() => router.push('page-phone-entry')}>
              <PTextInput
                  value={loginData?.mobileEmail}
                  onChange={(data) => { onChangeLoginData({ mobileEmail: data }); }}
                  leftIcon={<PersonIcon name="user" size={20} color="#FFFFFF" />}
                  label="Email or Mobile No."
                  placeholder="Enter Mobile No or Email"
                  style={styles.input}
                  readOnly
              />
            </TouchableOpacity>
            <PTextInput
                ref={inputRef}
                value={loginData?.password}
                onChange={(data) => { onChangeLoginData({ password: data }); }}
                leftIcon={<PassIcon name="key-outline" size={22} color="#FFFFFF" />}
                rightIcon={<MaterialIcons name={passwordVisible ? 'visibility' : 'visibility-off'} size={26} color="#808080" />}
                rightIconPress={() => setPasswordVisible(!passwordVisible)}
                label="Password"
                secureTextEntry={!passwordVisible}
                placeholder="Enter Password"
                style={styles.input}
            />
            {isBiometricSupported && !isBiometricEnrolled && (
                <Text style={styles.biometricErrorText}>
                  {biometricType} not enrolled.{' '}
                  <Text
                      style={styles.settingsLink}
                      onPress={() => Linking.openSettings()}
                  >
                    Enroll in Settings
                  </Text>
                </Text>
            )}
          </View>

          <View style={styles.actionContainer}>
            <CButton
                icon="arrow-right"
                onPress={() => handleContinue()}
                buttonStyles={styles.loginButton}
            >
              Login
            </CButton>

            {/* Forgot Password - Separate div aligned left with login button */}
            <View style={styles.forgotPasswordContainer}>
              <CButton
                  onPress={() => router.push('page-forgot-password')}
                  mode="link"
                  textStyle={styles.forgotPasswordText}
                  buttonStyles={styles.forgotPasswordButton}
              >
                Forgot Password?
              </CButton>
            </View>

            {/* Biometric Button - Centered */}
            {isBiometricSupported && credentialsStored && (
                <View style={styles.biometricContainer}>
                  <TouchableOpacity
                      onPress={handleBiometricLogin}
                      style={styles.biometricButton}
                      accessibilityLabel={`Login with ${biometricType}`}
                      accessibilityRole="button"
                  >
                    {biometricType === 'Face ID' ? (
                        <MaterialCommunityIcons
                            name="face-recognition"
                            size={40}
                            color="#007AFF"
                            style={styles.biometricIcon}
                        />
                    ) : (
                        <SvgXml
                            xml={fingerIconXml}
                            width={44}
                            height={44}
                            fill="#007AFF"
                            style={styles.biometricIcon}
                        />
                    )}
                  </TouchableOpacity>
                </View>
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
  );
};

export default PageLogin;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-evenly',
    alignItems: 'center',
    padding: 14,
    backgroundColor: '#FFFFFF',
  },
  headerContainer: {
    alignItems: 'center',
    marginTop: 12,
  },
  logo: {
    marginBottom: 10,
  },
  subheaderText: {
    fontSize: 15,
    textAlign: 'center',
    fontFamily: FontStyle?.light,
    marginBottom: 0,
  },
  headerText: {
    fontSize: 30,
    textAlign: 'center',
    fontFamily: FontStyle?.medium,
  },
  inputContainer: {
    width: '100%',
    paddingHorizontal: 12,
  },
  input: {
    marginVertical: 4,
  },
  actionContainer: {
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: 12,
    marginBottom: 12,
  },
  loginButton: {
    marginTop: 10,
  },
  // forgot password
  forgotPasswordContainer: {
    width: '100%',
    alignItems: 'flex-start',
    marginTop: 4,
  },
  forgotPasswordButton: {
    padding: 2,
    paddingLeft: 0,
  },
  forgotPasswordText: {
    fontSize: 14,
    color: '#007AFF',
    textAlign: 'left',
  },
  // biometric - centered
  biometricContainer: {
    width: '100%',
    alignItems: 'center',
    marginTop: 10,
  },
  biometricButton: {
    padding: 12,
    borderRadius: 50,
    backgroundColor: '#F8F9FA',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 0,
  },
  biometricIcon: {
    padding: 0,
  },
  // Keep existing styles for error text
  biometricErrorText: {
    textAlign: 'center',
    marginTop: 8,
    color: '#FF0000',
    fontSize: 14,
  },
  settingsLink: {
    color: '#0000FF',
    textDecorationLine: 'underline',
  },
});