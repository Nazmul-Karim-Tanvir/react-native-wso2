import React, {useEffect, useRef} from 'react';
import {StyleSheet, Text, View, KeyboardAvoidingView, Platform, Keyboard} from "react-native";
import {useNavigation, useRouter} from "expo-router";
import IDLCLogo from "../../assets/images/IDLC_Logo_mini.svg";
import PTextInput from "../../components/ui-custom-component/paper-text-input";
import CButton from "../../components/ui-custom-component/paper-button";
import authStore from "../../store/auth-store";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import {ForgotPasswordRequests} from "../../apiRequests/auth/auth-requests";
import AsyncStorage from "@react-native-async-storage/async-storage";

const PageForgotPassword = () => {
    const router = useRouter();
    const {preLogin, onChangePreLogin}=authStore();
    const inputRef = useRef(null);

    useEffect(() => {
        (async () => {
            let userMobileNumber = await AsyncStorage.getItem("MobileNumber");
            userMobileNumber && onChangePreLogin({"MobileNumber": userMobileNumber});
        })()
        const focusTimeout = setTimeout(() => {
            if (inputRef.current) {
                inputRef.current.focus();
            }
        }, 400); // Add a small delay to ensure the component is fully rendered

        return () => clearTimeout(focusTimeout);
    }, []);

    const handleContinue = async () => {
        Keyboard.dismiss();
        const success = await ForgotPasswordRequests(preLogin)
        success && router.push("page-otp-verification");
    }
    return (
        <KeyboardAvoidingView
              behavior={Platform.OS === "ios" ? "padding" : undefined}
              style={{ flex: 1 }}
            >
        <View style={styles.container}>
            <View style={{alignItems: "center"}}>
                <IDLCLogo width={64} height={64} style={{marginBottom: 30}} />
                <Text style={styles.headerText}>Change Password</Text>
                <Text style={styles.subheaderText}>To change password, you must know your phone number.</Text>
            </View>

            <View style={{width:'100%'}}>
                <PTextInput
                    ref={inputRef}
                    leftIcon= {<MaterialCommunityIcons name="phone" size={26} color="#FFFFFF" />}
                    value={preLogin?.MobileNumber}
                    onChange={(data)=>{onChangePreLogin({MobileNumber: data})}}
                    label="Mobile No."
                    placeholder="Enter Mobile No"
                    style={{marginBlock: 5}}
                    keyboardType='phone-pad'
                />
                <CButton icon='arrow-right' onPress={handleContinue} buttonStyles={{marginTop: 20}}>Next</CButton>
            </View>
            <View></View>
        </View>
        </KeyboardAvoidingView>
    );
};

export default PageForgotPassword;

const styles = StyleSheet.create({
    container: {
        flex: 1, justifyContent: "space-evenly", alignItems: "center", padding: 30
    },
    subheaderText: {
        fontSize: 15,
        textAlign: "center",
    },
    headerText: {
        fontSize: 30,
        textAlign: "center",
    }
})
