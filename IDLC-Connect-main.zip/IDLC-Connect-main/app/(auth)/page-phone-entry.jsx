import React, { useEffect, useRef, useState } from "react";
import {
  Text,
  View,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Keyboard,
  TouchableOpacity,
} from "react-native";
import { useNavigation, useRouter } from "expo-router";
import IDLCLogo from "../../assets/images/IDLC_Logo_mini.svg";
import PTextInput from "../../components/ui-custom-component/paper-text-input";
import CButton from "../../components/ui-custom-component/paper-button";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import { PreLoginRequest } from "../../apiRequests/auth/auth-requests";
import authStore from "../../store/auth-store";
import AsyncStorage from "@react-native-async-storage/async-storage";
import utilityStore from "../../store/utility-store";
import { Toast } from "toastify-react-native";
import { FontStyle } from "../../assets/styles/commonStyles";
import ValidationPhoneEntry from "../../validation/ValidationPhoneEntry";
import { DeviceInformation } from "../../utility/utility-functions";
import { Colors } from "../../assets/styles/colors";
import CustomRadioButton from "../../components/ui-custom-component/RadioButton";
import {Fontisto, Ionicons, MaterialIcons, Zocial} from "@expo/vector-icons";

const PagePhoneEntry = () => {
  const router = useRouter();
  const { preLogin, onChangePreLogin, loginData } = authStore();
  const inputRef = useRef(null);
  const inputRefForeign = useRef(null);

  //const toggleRef = useRef("first");
  const [toggleValue, setToggleValue] = useState("first");
  const [flag, setFlag] = useState(false);

  useEffect(() => {
    (async () => {
      let userMobileNumber = await AsyncStorage.getItem("MobileNumber");
      !preLogin?.userMobileNumber &&
        (await onChangePreLogin({
          MobileNumber: loginData?.mobileEmail || userMobileNumber || "",
          DeviceInfo: await DeviceInformation(),
        }));
      inputRef.current.value = userMobileNumber || "";
    })();
    const focusTimeout = setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }, 1000); // Add a small delay to ensure the component is fully rendered

    return () => clearTimeout(focusTimeout);
  }, []);

  useEffect(() => {
    preLogin.MobileNumber.length > 2 ? handleCheckMobileNumber(preLogin) : setFlag(false);
    const focusTimeout = setTimeout(() => {
      if (inputRefForeign.current) {
        inputRefForeign.current.focus();
      }
    }, 400); // Add a small delay to ensure the component is fully rendered
    return () => clearTimeout(focusTimeout);

  }, [preLogin?.MobileNumber]);


  const handleContinue = async () => {
    console.log("preLogin", preLogin);
    console.log("data",ValidationPhoneEntry(preLogin))
    if (ValidationPhoneEntry(preLogin)) {
      Keyboard.dismiss();
      let message = await PreLoginRequest(preLogin);
      console.log("msg",message)
      if (message === null) {
        console.log("Failed");
      } else if (message === "Completed") {
        await AsyncStorage.setItem("MobileNumber", preLogin?.MobileNumber);
        router.push("page-login");
      } else {
        router.push("page-otp-verification");
        alert(message);
        Toast.success(message);
      }
    }
    else{
      Toast.error("Please enter a valid phone number")
    }
  };
  const handleChange = (value) => {
    setToggleValue(value);
    Keyboard.dismiss();
  };

  const handleCheckMobileNumber = (data) => {
    if (ValidationPhoneEntry(data)==="bd")
      setFlag(false);
    else if (ValidationPhoneEntry(data)==="fr")
      setFlag(true);
    else setFlag(false)
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 30 : 0}
      style={{ flex: 1 }}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.container}>
          <View style={{ alignItems: "center" }}>
            <IDLCLogo onPress={() => router.push("page-existing-nid")} width={64} height={64} />
            <TouchableOpacity onPress={() => router.push("page-multiple-cif")}>
              <Text style={styles.headerText}>
                We need your mobile number to proceed
              </Text>
            </TouchableOpacity>
          </View>

          <View style={{ width: "100%" }}>
            <PTextInput
              ref={inputRef}
              leftIcon={<MaterialCommunityIcons name="phone" size={26} color="#FFFFFF"/>}
              label="Mobile Number"
              placeholder="Enter Your Mobile Number"
              value={preLogin?.MobileNumber || ""}
              keyboardType="phone-pad"
              onChange={(data) => {
                onChangePreLogin({ MobileNumber: data });
              }}
            />
            {flag && (
              <View
                style={[
                  styles.foreignPhnNumContainer,
                  { marginTop: flag ? 15 : 0 },
                ]}
              >
                <Text style={{color: Colors.primary, fontSize: 20, flexShrink: 1, fontFamily: FontStyle?.semiBold}}>
                  Send OTP to
                </Text>
                <View style={styles.lineStyle} />

                <CustomRadioButton onChange={(e) => handleChange(e)} />

                {toggleValue === "first" ? (
                  <PTextInput
                    ref={inputRefForeign}
                    leftIcon={<MaterialCommunityIcons name="phone" size={26} color="#FFFFFF"/>}
                    label="WhatsApp Number"  keyboardType="phone-pad"
                    value={preLogin?.WhatsAppNumber || ""}
                    onChange={(data) => onChangePreLogin({ WhatsAppNumber: data })}
                  />
                ) : (
                  <PTextInput
                    ref={inputRefForeign}
                    leftIcon={<MaterialIcons name="alternate-email" size={26} color="#FFFFFF"/>}
                    label="Email" keyboardType="email-address"
                    value={preLogin?.EmailAddress || ""}
                    onChange={(data) => onChangePreLogin({ EmailAddress: data })}
                  />
                )}
              </View>
            )}
            <CButton icon="arrow-right" onPress={handleContinue} buttonStyles={{ marginTop: flag ? 15 : 20 }}>Next</CButton>
          </View>
          <View></View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default PagePhoneEntry;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "space-evenly",
    alignItems: "center",
    padding: 30,
  },
  headerText: {
    fontSize: 28,
    textAlign: "center",
    marginTop: 30,
    fontFamily: FontStyle?.medium,
    lineHeight: 30,
  },
  foreignPhnNumContainer: {
    width: "100%",
    height: "auto",
    padding: 8,
    // paddingBottom:16,
    //flexDirection: "column",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#D4D4D4",
    // backgroundColor: Colors.primary + '19',
    marginVertical: 10,
    borderRadius: 8,
  },
  lineStyle: {
    height: 1, // Line height
    backgroundColor: "#C0BABA",
    marginTop: 10, // Spacing between text and line
    width: "105%", // Full width
  },
});
