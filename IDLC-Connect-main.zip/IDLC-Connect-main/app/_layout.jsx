import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
    'K2D-Regular': require('../assets/fonts/K2D-Bold.ttf'),
    'K2D-BoldItalic': require('../assets/fonts/K2D-BoldItalic.ttf'),
    'K2D-ExtraBold': require('../assets/fonts/K2D-ExtraBold.ttf'),
    'K2D-Italic': require('../assets/fonts/K2D-Italic.ttf'),
    'K2D-Light': require('../assets/fonts/K2D-Light.ttf'),
    'K2D-Medium': require('../assets/fonts/K2D-Medium.ttf'),
    'K2D-MediumItalic': require('../assets/fonts/K2D-MediumItalic.ttf'),
    'K2D-SemiBold': require('../assets/fonts/K2D-SemiBold.ttf'),

  });

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  return (
    <>
      <Stack screenOptions={{headerShown: false}}>
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="dark" />
    </>
  );
}
