import validationHelper from "../utility/validationHelper";
import {Toast} from "toastify-react-native";

export default function ValidateEkyc4(validationData) {
    //console.log("personal info",validationData)
    if(validationHelper.isEmpty(validationData.FatherName)){
        Toast.error("Father's Name is required in English");
        return false;
    }
    else if(validationHelper.isEmpty(validationData.MotherName)){
        Toast.error("Mother's Name is required in English");
        return false;
    }
    else if(validationHelper.isEmpty(validationData.MailingAddress)){
        Toast.error("Mailing Address is required in English");
        return false;
    }
    else if(validationHelper.isEmpty(validationData.DivisionCode)){
        Toast.error("Division is required");
        return false;
    }
    else if(validationHelper.isEmpty(validationData.DistrictCode)){
        Toast.error("District is required");
        return false;
    }
    else if(validationHelper.isEmpty(validationData.PostCode)){
        Toast.error("Postal Code is required");
        return false;
    }
    else if (!validationHelper.isPostCode(validationData.PostCode)) {
        Toast.error("Postal Code should be 4 digits");
        return false;
    }
    else if(validationHelper.isEmpty(validationData.PoliceStationCode)){
        Toast.error("Police Station is required");
        return false;
    }
    else return true;
}
