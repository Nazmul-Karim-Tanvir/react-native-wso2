import validationHelper from "../utility/validationHelper";
import {Toast} from "toastify-react-native";

export default function ValidateLogin(validationData) {
    if(validationHelper.isEmpty(validationData?.mobileEmail)) {
        Toast.error("Please enter email or mobile number");
        return false;
    }
    else if(validationHelper.isEmpty(validationData?.password)) {
        Toast.error("Please enter password");
        return false;
    }
    else return true;
}
