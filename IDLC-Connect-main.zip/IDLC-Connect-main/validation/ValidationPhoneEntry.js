import validationHelper from "../utility/validationHelper";
import {Toast} from "toastify-react-native";

export default function ValidationPhoneEntry(validationData) {
    if(!validationHelper.isEmpty(validationData?.MobileNumber) && validationHelper.isMobile(validationData?.MobileNumber))
        return "bd";

    if (!validationHelper.isEmpty(validationData?.MobileNumber) && validationHelper.isForeignMobile(validationData?.MobileNumber)) {
        return "fr";
    }
    else return null;
}
