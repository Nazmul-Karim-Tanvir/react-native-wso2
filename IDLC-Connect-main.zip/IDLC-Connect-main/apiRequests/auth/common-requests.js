import axios from "axios";
import {BaseUrl} from "../base-url-config";
import utilityStore from "../../store/utility-store";
import landingStore from "../../store/landing-store";

export async function GetDivisionByCountryCode(countryCode=3) {
    try {
        const res = await axios.get(`${BaseUrl}/ServiceRequest/get/division/by/country/code/${countryCode}`);
        return res.data?.Data;
    }
    catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data);
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return [];
    }
}
export async function GetDistrictByDivisionCode(divisionCode=1) {
    try {
        const res = await axios.get(`${BaseUrl}/ServiceRequest/get/district/by/division/code/${divisionCode}`);
        return res.data?.Data;
    }
    catch (error) {

        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data);
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return [];
    }
}

export async function GetPoliceStationByDivisionDistrictCode(districtCode) {
    try {
        const res = await axios.get(`${BaseUrl}/ServiceRequest/get/policestation/by/district/code/${districtCode}`);
        return res.data?.Data;
    }
    catch (error) {

        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data);
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return [];
    }
}

export async function GetBranches() {
    try {
        utilityStore.getState().setIsLoading(true);
        const res = await axios.get("https://web.idlc.com/api/v1/get-branch?idlc_category=idlc");
        console.log(res.data?.details.filter((item, idx) => idx !== 0).length);
        landingStore.getState().setBranchList(res.data?.details.filter((item, idx) => idx !== 0));
        return true;
    }
    catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data);
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    }
    finally {
        utilityStore.getState().setIsLoading(false);
    }
}
