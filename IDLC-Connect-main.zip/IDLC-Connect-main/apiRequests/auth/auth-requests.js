import axios from "axios";
import {BasePath, BaseUrl} from "../base-url-config";
import AsyncStorage from "@react-native-async-storage/async-storage";
import ekycStore from "../../store/ekyc-store";
import authStore from "../../store/auth-store";
import utilityStore from "../../store/utility-store";
import validationHelper from "../../utility/validationHelper";
import Constants from "expo-constants";
import {Toast} from "toastify-react-native";
import {router} from "expo-router";
import { getFileInfo, uriToBase64,saveAndShareCRMData } from "../../utility/utility-functions";


export async function CRM_MultipleCIF_Check(data) {
    try {
        utilityStore.getState().setIsLoading(true);
        console.log(data);            
        const res = await axios.post(`${BaseUrl}/CRMServiceRequest/get/noofcontactid/by/mobileno/${data}`);
        console.log(res.data.Data);
        return res.data.Data?.["Message"];
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data?.["Data"]?.["Message"]);
            Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return null;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function PreLoginRequest(data) {
    try {
        utilityStore.getState().setIsLoading(true);
        console.log("preLoginData",data);
        const res = await axios.post(`${BaseUrl}/UserAccount/pre/login`, data, {withCredentials: true});
        console.log(res.data.Data);
        res.data.Data?.["RegistrationReferenceID"] && (await AsyncStorage.setItem("RegistrationReferenceID", res.data.Data?.["RegistrationReferenceID"]));
        res.data.Data?.["ReferenceID"] && (await AsyncStorage.setItem("ReferenceID", res.data.Data?.["ReferenceID"]));
        !validationHelper.isEmpty(res.data.Data?.["ClientName"])  && (await AsyncStorage.setItem("ClientName", res.data.Data?.["ClientName"]));
        return res.data.Data?.["Message"];
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data?.["Data"]?.["Message"]);
            Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return null;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function UserLoginRequests(data) {
    try {
        utilityStore.getState().setIsLoading(true);
        console.log("payload",data);
        const res = await axios.post(`${BaseUrl}/UserAccount/login`, data);
        console.log("AccessToken",res.data.Data?.["AccessToken"]);
        await AsyncStorage.setItem("MobileNumber", data?.emailOrMobileNumber);
        await AsyncStorage.setItem("Token", res.data.Data?.["AccessToken"]);
        return await GetUserDetailsRequests(res.data.Data?.["AccessToken"]);
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data?.["Data"]?.["Message"]);
            if(error.response.data?.['Data']?.["Message"] === "Device not registered." || error.response.data?.['Data']?.["Message"] === "User not found."){
                let reqData = {
                    MobileNumber: data?.emailOrMobileNumber,
                    WhatsAppNumber: '',
                    EmailAddress: '',
                    DeviceInfo: data?.deviceInfo,
                }
                console.log(reqData);
                let message = await PreLoginRequest(reqData);
                console.log("Message from Failed login Req",message)
                if (message === null) {
                    console.log("Failed");
                } else if (message === "Completed") {
                    await AsyncStorage.setItem("MobileNumber", reqData?.MobileNumber);
                    router.push("page-login");
                } else {
                    router.push("page-otp-verification");
                    alert(message);
                    Toast.success(message);
                }
            }
            
            else Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");

        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function ForgotPasswordRequests(data) {
    try {
        utilityStore.getState().setIsLoading(true);
        const res = await axios.post(`${BaseUrl}/UserAccount/forgot/password`, data);
        alert(res.data.Data?.['Message']);
        res.data.Data?.["RegistrationReferenceID"] && (await AsyncStorage.setItem("RegistrationReferenceID", res.data.Data?.["RegistrationReferenceID"]));
        res.data.Data?.["ReferenceID"] && (await AsyncStorage.setItem("ReferenceID", res.data.Data?.["ReferenceID"]));
        return true;
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data?.["Data"]?.["Message"]);
            Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function GetUserDetailsRequests(token) {
    try {
        utilityStore.getState().setIsLoading(true);
        const res = await axios.get(`${BaseUrl}/UserAccount/get/user/detail`, {headers: {Authorization: `Bearer ${token}`}});
        console.log("USer Details",res.data.Data);
        await AsyncStorage.setItem("UserDetail", JSON.stringify(res.data.Data));
        return true;
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data?.["Data"]?.["Message"]);
            Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function SetNewPasswordRequest(data) {
    try {
        utilityStore.getState().setIsLoading(true);
        const res = await axios.post(
            `${BaseUrl}/UserAccount/set/new/password`,
            data
        );
        console.log(res.data.Data);
        return res.data.Data?.["Message"];
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data?.["Data"]?.["Message"]);
            Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function VerifyOTPRequest(data, mobileNumber) {
    try {
        utilityStore.getState().setIsLoading(true);
        const res = await axios.post(`${BaseUrl}/UserAccount/verify/otp`, data);
        console.log(res.data.Data);
        ekycStore.getState().setStage(res.data.Data?.["Message"]);
        //console.log("stage in otp verify",res.data.Data?.["Message"])

        let regRefID = await AsyncStorage.getItem("RegistrationReferenceID");
        let userRefID = res.data.Data?.["UserReferenceID"];
        userRefID && await AsyncStorage.setItem("UserReferenceID", userRefID);

        if(!validationHelper.isEmpty(res.data.Data?.["RegistrationReferenceID"])) {
            await GetEkycDataRequest(res.data.Data?.["RegistrationReferenceID"])
        } else {await GetEkycDataRequest(regRefID)}

        !validationHelper.isEmpty(res.data.Data?.["ClientName"])  && (await AsyncStorage.setItem("ClientName", res.data.Data?.["ClientName"]));
        return res.data.Data?.["Message"];
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data?.["Data"]?.["Message"]);
            Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function EkycProcessRequest(data, nextStage = "") {
    try {
        utilityStore.getState().setIsLoading(true);
        const res = await axios.post(
            `${BaseUrl}/UserAccount/update/user/registration`,
            data,
            {
                withCredentials: true,
                headers: {"Content-Type": "multipart/form-data"},
                //transformRequest: () => data,
            }
        );
        console.log(res.data?.Data?.["Message"]);
        !validationHelper.isEmpty(res.data.Data?.["ClientName"]) && (await AsyncStorage.setItem("ClientName", res.data.Data?.["ClientName"]));
        ekycStore.getState().setStage("");
        return true;
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data?.["Data"]?.["Message"]);
            Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function GetEkycDataRequest(RegRefId) {
    try {
        utilityStore.getState().setIsLoading(true);
        const {setEkyc1, setEkyc2, setEkyc3, onChangeEkyc3, setNidInfo} = ekycStore.getState();
        const {onChangeLoginData} = authStore.getState();
        const res = await axios.get(`${BaseUrl}/UserAccount/get/registration/info?RegistrationReferenceID=${RegRefId}`);
        //console.log("ref ------ ID",RegRefId)
        console.log(res.data.Data);
        setEkyc1({
            NidNumber: res.data.Data?.["EkycInfo"]?.["OCRNID"],
            NidName: res.data.Data?.["EkycInfo"]?.["OCRName"],
            Dob: res.data.Data?.["EkycInfo"]?.["OCRDoB"],
            NidFrontImg: validationHelper.isEmpty(res.data.Data?.["registrationDocument"]?.["NIDFrontDocPath"]) ? null : BasePath + res.data.Data?.["registrationDocument"]?.["NIDFrontDocPath"]?.replace(/\\/g, "/"),
        });
        !validationHelper.isEmpty(res.data.Data?.["registrationDocument"]?.["NIDBackDocPath"]) &&
        setEkyc2({
            NidBackImg: BasePath + res.data.Data?.["registrationDocument"]?.["NIDBackDocPath"]?.replace(/\\/g, "/"),
            ExtractedName: res.data.Data?.["EkycInfo"]?.["OCRName"],
            ExtractedDOB: res.data.Data?.["EkycInfo"]?.["OCRDoB"],
        });
        res.data.Data?.["registrationDocument"]?.["PhotoDocPath"]?.length > 0 &&
        setEkyc3({
            photoBase64: "",
            blinkCount: 2,
            faceExpression: "smiling",
            photoPath: BasePath + res.data.Data?.["registrationDocument"]?.["PhotoDocPath"]?.replace(/\\/g, "/"),
            nidPhoto: BasePath + res.data.Data?.["EkycInfo"]?.["ECPhotoDocPath"]?.replace(/\\/g, "/"),
            photoVerificationResult: res.data.Data?.["EkycInfo"]?.["PhotoVerificationResult"],
        });
        if (!validationHelper.isEmpty(res.data.Data?.["EkycInfo"])) {
            setNidInfo({
                FullName: res.data.Data?.["EkycInfo"]?.["ECName"],
                FatherName: res.data.Data?.["EkycInfo"]?.["ECFatherName"],
                MotherName: res.data.Data?.["EkycInfo"]?.["ECMotherName"],
                NidNo: res.data.Data?.["EkycInfo"]?.["OCRNID"],
                BirthDate: res.data.Data?.["EkycInfo"]?.["OCRDoB"],
                Address: res.data.Data?.["EkycInfo"]?.["ECAddress"],
            });
            onChangeEkyc3({
                nidPhoto: BasePath + res.data.Data?.["EkycInfo"]?.["ECPhotoDocPath"]?.replace(/\\/g, "/"),
                photoPath: validationHelper.isEmpty(res.data.Data?.["registrationDocument"]?.["PhotoDocPath"]) ? "" :
                    BasePath + res.data.Data?.["registrationDocument"]?.["PhotoDocPath"]?.replace(/\\/g, "/")
            });
        }
        onChangeLoginData({mobileEmail: res.data.Data?.["MobileNumber"]});

        return true;
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data?.["Data"]?.["Message"]);
            Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function FaceMatchingRequests(Photo1, Photo2) {
    try {
        if (Photo1 !== "" && Photo2 !== "") {
            utilityStore.getState().setIsLoading(true);
            const data = {img1: Photo1, img2: Photo2};
            console.log(data.img1.slice(0, 100), data.img2.slice(0, 100));
            const res = await axios.post("https://app7.idlc.com:7070/api/match", data);
            //console.log("result face Match",res.data.match)
            ekycStore.getState().onChangeEkyc3({
                photoVerificationResult: res.data.match?.["_distance"].toString(),
            });
            //console.log(res.data.match?.["_distance"],res.data.match?.["_distance"]<0.51 && res.data.match?.["_label"]==="person 1");
            return res.data.match?.["_distance"]<0.51 && res.data.match?.["_label"]==="person 1";
            //return true;
        } else {
            console.log("Both Images are required");
            return false;
        }
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            //console.log("Data:", error.response?.data);
            Toast.error(error.response.data?.["Data"]?.["Message"] || "ERROR FOUND");
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function FaceDetectionRequests(Photo1) {
    try {
        utilityStore.getState().setIsLoading(true);
        const data = {img1: `data:image/jpeg;base64,${Photo1}`};
        console.log(data.img1.slice(0, 100));
        const res = await axios.post(
            "https://app7.idlc.com:7070/api/faceDetector",
            data
        );
        // console.log("result from api face detector",res?.data?.Detection)
        return res?.data?.Detection;
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data);
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

export async function BarcodeScanner(uri) {

    const formData = new FormData();
    const fileInfo = getFileInfo(uri);
    formData.append('image', {
    uri: uri,
    type: fileInfo.type,
    name: fileInfo.name
    });

    try {
        utilityStore.getState().setIsLoading(true);
        const response = await axios.post("https://app7.idlc.com:6060/api/barcodeScanner", formData, {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          });
        //    console.log("result from api ",response?.data)
        // console.log("result from api ",res?.data?.Result)
        return response?.data;
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data);
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return null;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}

//CRM Request CIF Create api

export async function CRM_Contact_Create_Req(preLogin,ekyc1,ekyc2,ekyc3,ekyc4) {
    try {

        const appVariant = Constants.expoConfig?.extra?.APP_VARIANT;

        const mappedVariant = appVariant === "fl-app"
            ? "FL"
            : appVariant === "sl-app"
            ? "SL"
            : appVariant === "il-app"
            ? "IL"
            : appVariant === "aml-app"
            ? "AML"
            : "GROUP"; // Default value if none match
        console.log("EKYC 3",ekyc3)


        const crmData = {
            "MobilePhone": !validationHelper.isEmpty(preLogin?.MobileNumber)? preLogin?.MobileNumber: preLogin?.WhatsAppNumber , //** */
            "Email": preLogin?.EmailAddress, //** */
            "FirstName": ekyc1?.NidName, //** */
            "MiddleName": "",
            "LastName": "",
            "NidNumber": ekyc1?.NidNumber,//** */s
            "BloodGroup": "",
            "ClientCategory": "",
            "ContactType": "Contact person",
            "MaritalStatus": "",
            "Nationality": "Bangladesh",
            "Occupation": "",
            "Religion": "",
            "ResidentialStatus": "",
            "FatherName": ekyc4?.FatherName, //** */
            "MotherName": ekyc4?.MotherName, //** */
            "SpouseName": "",
            "IDLCTin": "",
            "BirthDate": new Date(ekyc1?.Dob.split("-").reverse().join("-")).toLocaleDateString("en-US", { day: "2-digit", month: "2-digit", year: "numeric" }),
            "Gender": "",
            "HighestEducationLevel": "",
            "IsDeceased": false,
            "DateOfAnniversary": "",
            "ContactSalutationType": "",
            "CompanyName": mappedVariant, //** */
            "Communication": [],
            "Identification": [],
            "ProfilePicture": await uriToBase64(ekyc3?.photoPath),
            "NidFront": await uriToBase64(ekyc1?.NidFrontImg), //** */
            "NidBack": await uriToBase64(ekyc2?.NidBackImg),
            "Utilities":"",
            "SignatureImage":"",
            "Address": [//**
                {                    
                    "AddressLine1": ekyc4?.MailingAddress,
                    "AddressLine2": "",
                    "AddressType": "Mailing Address",
                    "City": ekyc4?.District,
                    "Division": ekyc4?.Division,
                    "Country": "Bangladesh",
                    "Primary": true
                },
                {
                    "AddressLine1": "",
                    "AddressLine2": "",
                    "AddressType": "Permanent",
                    "City": "",
                    "Division": "",
                    "Country": "Bangladesh",
                    "Primary": false
                }
            ],
            "BankDetails": [],
            "attachments": [//**
                {
                    "Name": ekyc1?.NidNumber+"_FrontNid.pdf",
                    "FileType": "NID Front Side",
                    "SiteAddress": ekyc1?.NidFrontImg,
                    "MakerName": "",
                    "SourceFileName": "",
                    "Remarks": "",
                    "SpAttachmentListID": "",
                    "DocumentLibrary": ""
                },
                {
                    "Name": ekyc1?.NidNumber+"_BackNid.pdf",
                    "FileType": "NID Back Side",
                    "SiteAddress": ekyc2?.NidBackImg,
                    "MakerName": "",
                    "SourceFileName": "",
                    "Remarks": "",
                    "SpAttachmentListID": "",
                    "DocumentLibrary": ""
                }
            ]
        }

        //// Normal Check
        // console.log("crm data in api",crmData)
        await saveAndShareCRMData(crmData);
        
        ///
        utilityStore.getState().setIsLoading(true);
        const res = await axios.post(`${BaseUrl}/CRMServiceRequest/open/contact/request`, crmData, {withCredentials: true});
        console.log("result from CRM CIF ",res?.data)
        // res && (await AsyncStorage.setItem("CRMContactID", res?.Data?.Data));
        return res?.data?.Data?.Data;
    } catch (error) {
        if (error.response) {
            console.log("Server responded with a status:", error.response.status);
            console.log("Data:", error.response.data);
        } else if (error.request) {
            console.log("No response received:", error.request);
        } else {
            console.log("Error setting up request:", error.message);
        }
        return false;
    } finally {
        utilityStore.getState().setIsLoading(false);
    }
}
