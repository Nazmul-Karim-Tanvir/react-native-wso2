import Constants from 'expo-constants';

// export const BaseUrl =  "https://app7.idlc.com:4040/api";
// export const BasePath = "https://app7.idlc.com:4040";
// export const AppType =  "fl-app" // fl-app / sl-app / il-app / aml-app


export const BaseUrl =  Constants.expoConfig?.extra?.BaseUrl || "https://app7.idlc.com:4040/api";
export const BasePath = Constants.expoConfig?.extra?.BasePath || "https://app7.idlc.com:4040";
export const AppType = Constants.expoConfig?.extra?.APP_VARIANT || "fl-app"; // "fl-app" / sl-app / il-app / aml-app

