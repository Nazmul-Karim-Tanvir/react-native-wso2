import React, { useEffect, useState } from "react";
import Constants from "expo-constants";
import { useCallback } from "react";
import {
  Dimensions,
  StyleSheet,
  Text,
  View,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import TableComponent from "../ui-custom-component/table-component";
import PTextInput from "../ui-custom-component/paper-text-input";
import PSelect from "../ui-custom-component/paper-select";
import { Colors } from "../../assets/styles/colors";
import ekycStore from "../../store/ekyc-store";
import {
  GetDistrictByDivisionCode,
  GetDivisionByCountryCode,
  GetPoliceStationByDivisionDistrictCode,
} from "../../apiRequests/auth/common-requests";
import validationHelper from "../../utility/validationHelper";
import { FontStyle } from "../../assets/styles/commonStyles";
import translate from "translate";
import utilityStore from "../../store/utility-store";
import authStore from "../../store/auth-store";


const Ekyc4_1 = () => {
  const { nidInfo, ekyc1,ekyc2,ekyc3,ekyc4, onChangeEkyc4, stage, setStage } = ekycStore();
  const { preLogin } = authStore();

  
  const NIDInformation = [
    {
      Header: "Full Name",
      Data: nidInfo?.FullName,
    },
    {
      Header: "NID Number",
      Data: nidInfo?.NidNo,
    },
    {
      Header: "Date of Birth",
      Data: nidInfo?.BirthDate,
    },
  ];
  const [divisionList, setDivisionList] = useState([]);
  const [districtList, setDistrictList] = useState([]);
  const [policeStationList, setPoliceStationList] = useState([]);

  useEffect(() => {
    (async () => {
      let res1 = await GetDivisionByCountryCode();
      setDivisionList(
        res1.map((item) => {
          return { value: item?.DivisionCode, label: item?.Division };
        })
      );
      if (!validationHelper.isEmpty(ekyc4.DivisionCode)) {
        let res2 = await GetDistrictByDivisionCode(ekyc4.DivisionCode);
        setDistrictList(
          res2.map((item) => {
            return { value: item?.CityCode, label: item?.city };
          })
        );
      }
      if (
        !validationHelper.isEmpty(ekyc4.DivisionCode) &&
        !validationHelper.isEmpty(ekyc4.DistrictCode)
      ) {
        let res3 = await GetPoliceStationByDivisionDistrictCode(
          ekyc4.DistrictCode
        );
        setPoliceStationList(
          res3.map((item) => {
            return { value: item?.PSID, label: item?.PS };
          })
        );
      }
    })();
  }, [ekyc4.DivisionCode, ekyc4.DistrictCode]);

  // useEffect(() => {
  //   const fetchCRMData = async () => {
  //     if (stage !== "Step-5-NID-Info-Confirm") {
  //       setStage("Step-5-NID-Info-Confirm");
  //     }
  
  //     const appVariant = Constants.expoConfig?.extra?.APP_VARIANT;
  
  //     const mappedVariant =
  //       appVariant === "fl-app"
  //         ? "FL"
  //         : appVariant === "sl-app"
  //         ? "SL"
  //         : appVariant === "il-app"
  //         ? "IL"
  //         : appVariant === "aml-app"
  //         ? "AML"
  //         : "GROUP"; // Default value if none match
  
  //     const crmData = {
  //       MobilePhone: !validationHelper.isEmpty(preLogin?.MobileNumber)
  //         ? preLogin?.MobileNumber
  //         : preLogin?.WhatsAppNumber,
  //       Email: preLogin?.EmailAddress,
  //       FirstName: ekyc1?.NidName,
  //       MiddleName: "",
  //       LastName: "",
  //       NidNumber: ekyc1?.NidNumber,
  //       BloodGroup: "",
  //       ClientCategory: "",
  //       ContactType: "Contact person",
  //       MaritalStatus: "",
  //       Nationality: "Bangladesh",
  //       Occupation: "",
  //       Religion: "",
  //       ResidentialStatus: "",
  //       FatherName: ekyc4?.FatherName,
  //       MotherName: ekyc4?.MotherName,
  //       SpouseName: "",
  //       IDLCTin: "",
  //       BirthDate: new Date(
  //         ekyc1?.Dob.split("-").reverse().join("-")
  //       ).toLocaleDateString("en-US", {
  //         day: "2-digit",
  //         month: "2-digit",
  //         year: "numeric",
  //       }),
  //       Gender: "",
  //       HighestEducationLevel: "",
  //       IsDeceased: false,
  //       DateOfAnniversary: "",
  //       ContactSalutationType: "",
  //       CompanyName: mappedVariant,
  //       Communication: [],
  //       Identification: [],
  //       ProfilePicture: await uriToBase64(ekyc3?.photoPath),
  //       NidFront: await uriToBase64(ekyc1?.NidFrontImg),
  //       NidBack: await uriToBase64(ekyc1?.NidBackImg),
  //       Utilities: "",
  //       SignatureImage: "",
  //       Address: [
  //         {
  //           AddressLine1: ekyc4?.MailingAddress,
  //           AddressLine2: "",
  //           AddressType: "Mailing Address",
  //           City: ekyc4?.District,
  //           Division: ekyc4?.Division,
  //           Country: "Bangladesh",
  //           Primary: true,
  //         },
  //         {
  //           AddressLine1: "",
  //           AddressLine2: "",
  //           AddressType: "Permanent",
  //           City: "",
  //           Division: "",
  //           Country: "Bangladesh",
  //           Primary: false,
  //         },
  //       ],
  //       BankDetails: [],
  //       attachments: [
  //         {
  //           Name: `${ekyc1?.NidNumber}_FrontNid.pdf`,
  //           FileType: "NID Front Side",
  //           SiteAddress: ekyc1?.NidFrontImg,
  //           MakerName: "",
  //           SourceFileName: "",
  //           Remarks: "",
  //           SpAttachmentListID: "",
  //           DocumentLibrary: "",
  //         },
  //         {
  //           Name: `${ekyc1?.NidNumber}_BackNid.pdf`,
  //           FileType: "NID Back Side",
  //           SiteAddress: ekyc2?.NidBackImg,
  //           MakerName: "",
  //           SourceFileName: "",
  //           Remarks: "",
  //           SpAttachmentListID: "",
  //           DocumentLibrary: "",
  //         },
  //       ],
  //     };
  
  //     console.log("crmData", crmData);
  //   };
  
  //   fetchCRMData(); // 👈 call the async function
  
  // }, [ekyc4]);
  

  // useEffect(() => {
  //     (async () => {
  //         utilityStore.getState().setIsLoading(true);
  //         let address = await translate(nidInfo?.Address, {from: "bn", to: "en"});

  //         let res1 = await GetDivisionByCountryCode();
  //         res1 = res1.map((item) => {return {value: item?.DivisionCode, label: item?.Division}});
  //         setDivisionList(res1);

  //         let DivisionCode = res1?.find(item => item.label.toLowerCase() === address.split(",")[0].toLowerCase()?.replace(/\s/g, ""))?.value;
  //         let Division = address.split(",")[0];

  //         let res2 = await GetDistrictByDivisionCode(DivisionCode);
  //         res2 = res2.map((item) => {return {value: item?.CityCode, label: item?.city}});
  //         setDistrictList(res2);

  //         let DistrictCode = res2?.find(item => item.label.toLowerCase() === address.split(",")[1].toLowerCase()?.replace(/\s/g, ""))?.value;
  //         let District = address.split(",")[1];

  //         onChangeEkyc4({
  //             "FatherName": await translate(nidInfo?.FatherName, {from: "bn", to: "en"}),
  //             "MotherName": await translate(nidInfo?.MotherName, {from: "bn", to: "en"}),
  //             "MailingAddress": address,
  //             "DivisionCode": DivisionCode,
  //             "Division": Division,
  //             "DistrictCode": DistrictCode,
  //             "District": District,
  //             "PostCode": address.split(",")[address.split(",").length - 1]
  //         })
  //         utilityStore.getState().setIsLoading(false);
  //     })()
  // }, [nidInfo])

  const handleDivisionChange = useCallback(
    async (data) => {
      const division = divisionList?.find(
        (item) => item.value === parseInt(data)
      )?.label;
      onChangeEkyc4({ DivisionCode: data, Division: division });

      const res = await GetDistrictByDivisionCode(data);
      setDistrictList(
        res.map((item) => ({ value: item.CityCode, label: item.city }))
      );
    },
    [divisionList]
  );

  const handleDistrictChange = useCallback(
    async (data) => {
      const district = districtList.find(
        (item) => item.value === parseInt(data)
      )?.label;
      onChangeEkyc4({ DistrictCode: data, District: district });

      const res = await GetPoliceStationByDivisionDistrictCode(data);
      setPoliceStationList(
        res.map((item) => ({ value: item.PSID, label: item.PS }))
      );
    },
    [districtList]
  );

  const handlePoliceStationChange = useCallback(
    (data) => {
      onChangeEkyc4({
        PoliceStationCode: data,
        PoliceStation: policeStationList.find(
          (item) => item.value === parseInt(data)
        )?.label,
      });
    },
    [policeStationList]
  );

  return (
      <View style={{ flex: 1, padding: 15 }}>
          <Text style={styles.labelStyle}>NID Information</Text>
          <TableComponent rowData={NIDInformation} style={{ marginBottom: 20 }} />
          <View style={{ borderBottomWidth: 1, borderColor: "gray", marginBottom: 10 }}>
              <Text style={styles.labelStyle}>
                  Please fill-up your personal information in English
              </Text>
          </View>


          <View style={{ flex: 1,width:"100%", alignSelf:"center" }}>
          <PTextInput
              value={ekyc4?.FatherName}
              onChange={(data) => onChangeEkyc4({ FatherName: data })}
              label="Father's Name"
              placeholder="Enter Father's Name in English"
              style={{ marginVertical: 5 }}
          />
          <PTextInput
              value={ekyc4?.MotherName}
              onChange={(data) => onChangeEkyc4({ MotherName: data })}
              label="Mother's Name"
              placeholder="Enter Mother's Name in English"
              style={{ marginVertical: 5 }}
          />
          <PTextInput
              value={ekyc4?.MailingAddress}
              onChange={(data) => onChangeEkyc4({ MailingAddress: data })}
              type="textarea"
              label="Mailing Address"
              placeholder="Enter Mailing Address in English"
              style={{ marginVertical: 5 }}
          />

          <PSelect
              value={ekyc4?.DivisionCode}
              onChange={handleDivisionChange}
              options={divisionList}
              label="Division"
              style={{ marginVertical: 5 }}
          />

          <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <PSelect
                  value={ekyc4?.DistrictCode}
                  onChange={handleDistrictChange}
                  options={districtList}
                  label="District"
                  style={{ marginVertical: 5, width: "49%" }}
              />
              <PTextInput
                  value={ekyc4?.PostCode}
                  keyboardType="numeric"
                  onChange={(data) => onChangeEkyc4({ PostCode: data })}
                  label="Postal Code"
                  placeholder="Postal Code"
                  style={{ marginVertical: 5, width: "49%" }}
              />
          </View>

          <PSelect
              value={ekyc4?.PoliceStationCode}
              onChange={handlePoliceStationChange}
              options={policeStationList}
              label="Police Station"
              style={{ marginVertical: 5 }}
          />
          </View>
      </View>
  );
};

export default Ekyc4_1;

const styles = StyleSheet.create({
  labelStyle: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 5,
    fontFamily: FontStyle?.regular,
  },
  nidContainer: {
    width: Dimensions.get("window").width - 50,
    height: ((Dimensions.get("window").width - 40) * 10) / 16,
    borderColor: Colors.primary,
    borderWidth: 1,
    padding: 5,
    borderRadius: 8,
    marginBottom: 6,
  },
  nidStyle: {
    flex: 1,
    objectFit: "contain",
    height: "100%",
    width: "100%",
    borderRadius: 6,
  },
});
