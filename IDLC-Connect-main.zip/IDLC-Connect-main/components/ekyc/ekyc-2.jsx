import React, {useEffect, useRef} from 'react';
import {Dimensions, Image, StyleSheet, Text, View,Platform} from "react-native";
import CButton from "../ui-custom-component/paper-button";
import {Feather, AntDesign} from "@expo/vector-icons";
import {Colors} from "../../assets/styles/colors";
import {pickImageFromCamera, pickImageFromGallery} from "../ui-custom-component/image-picker-component";
import ekycStore from "../../store/ekyc-store";
import { FontStyle } from '../../assets/styles/commonStyles';
import moment from 'moment';
import * as ImageManipulator from "expo-image-manipulator";
import {Camera, useCameraPermissions} from "expo-camera";
import { cropImage } from '../../utility/utility-functions';
import { BarcodeScanner } from '../../apiRequests/auth/auth-requests';
import utilityStore from "../../store/utility-store";
import { CropImageExpo } from '../ui-custom-component/image-picker-component';


const Ekyc2 = () => {
    const {ekyc2,onChangeEkyc2, setStage}=ekycStore();
    const imageRef = useRef(null);
    const [status, requestPermission] = useCameraPermissions();

    const extractDataBack = (decodedText) => {
        const nameMatch = decodedText.match(/<name>(.*?)<\/name>/);
        const name1Match = decodedText.match(/NM(.*?)NW/);
        const cleanedName = name1Match?.[1]?.replace(/<GS>/g, '')?.trim();
        const dobMatch = decodedText.match(/<DOB>(.*?)<\/DOB>/);
        console.log("Old: "+nameMatch, "New: "+ cleanedName);

        const formattedDob = dobMatch ? moment(dobMatch[1], 'DD MMM YYYY').format('DD-MM-YYYY') : null;
        return {
            name: nameMatch ? nameMatch[1] : cleanedName ? cleanedName : null,
            dob: formattedDob
        };
    };

    useEffect(() => {
        (async () => !status?.granted && await requestPermission())()
    }, [status])

    const handleImage = async (ImageSource) => {
        let FinalImg = ImageSource === 'Camera' ? await pickImageFromCamera() : await pickImageFromGallery();


        if(FinalImg){
            FinalImg =  Platform.OS=== "ios" ? await CropImageExpo(FinalImg,[16,10]) : await ImageManipulator.manipulateAsync(FinalImg, [{ resize: {width: 1000}}]);
            console.log("After Crop: ", FinalImg);
            let cropTopPortion = await cropImage(FinalImg , 0, 0, 1, 0.3);
            let cropBottomPortion = await cropImage(FinalImg, 0, 0.7, 1, 0.4);


            let data = await Camera.scanFromURLAsync(FinalImg.uri , "pdf417");
            console.log(data, data[0]?.['origin'], data[0]?.['size'], data[0]?.['cornerPoints']);
            if(data.length === 0) {
                let data2= await BarcodeScanner(cropTopPortion.uri);
                let data3= await BarcodeScanner(cropBottomPortion.uri);

                console.log(data2,data3);
                if(data2 == null && data3 === null) {
                    console.log("No Data Found");
                    onChangeEkyc2({"NidBackImg": FinalImg?.uri , "ExtractedName": null, "ExtractedDOB": null});
                } else {
                    let extractedData2 = data2 !== null && extractDataBack(data2?.barcodes);
                    let extractedData3 = data3 !== null && extractDataBack(data3?.barcodes);
                    console.log("extracted Data 2",extractedData2)
                    console.log("extracted Data 3",extractedData3)

                    extractedData3 && onChangeEkyc2({"NidBackImg": FinalImg?.uri ,"ExtractedName": extractedData3?.name,"ExtractedDOB": extractedData3?.dob})
                    extractedData2 && onChangeEkyc2({"NidBackImg": FinalImg?.uri ,"ExtractedName": extractedData2?.name})

                    setStage("Step-3-NID-Back");
                }
            } else {
                let extractedData = extractDataBack(data[0]?.data);
                console.log(extractedData)
                onChangeEkyc2({"NidBackImg": FinalImg.uri , "ExtractedName": extractedData?.name, "ExtractedDOB": extractedData?.dob});
                setStage("Step-3-NID-Back");
            }
        }
        else {
            utilityStore.getState().setIsLoading(false);
        }
    }

    return (
        <View style={styles.container}>
            <Text style={styles.headerText}>Attach back side of your NID</Text>
            <View style={styles.nidContainer}>
                <Image ref={imageRef} source={ekyc2?.NidBackImg ? {uri: ekyc2?.NidBackImg} : require('../../assets/images/NID_Back.png')} style={styles.nidStyle}/>
            </View>
            <View style={styles.nidPickerContainer}>
                <CButton onPress={() => handleImage('Camera')} mode='outlined'
                         buttonStyles={styles.nidPickerBtnContainer}>
                    <Feather name={'camera'} size={25} color={Colors.primary}/>
                </CButton>
                <CButton onPress={() => handleImage('Gallery')} mode='outlined'
                         buttonStyles={styles.nidPickerBtnContainer}>
                    <Feather name={'upload'} size={25} color={Colors.primary}/>
                </CButton>
            </View>

            {ekyc2?.ExtractedName === null &&
                <View style={styles.nidResultFailContainer}>
                    <AntDesign name="infocirlceo" size={24} color="black" style={{color: Colors.primary, marginEnd: 10}}/>
                    <Text style={{color: Colors.primary, fontSize: 16, flexShrink: 1, fontFamily: FontStyle?.medium}}>NID back side data is incorrect, Please try again!!</Text>
                </View>
            }
        </View>
    );
};

export default Ekyc2;

const styles = StyleSheet.create({
    container: {
        flex: 1, justifyContent: 'center', alignItems: 'center'
    },
    headerText: {
        fontSize: 24,
        textAlign: "center",
        marginBottom: 10,
        marginTop: 20,
        fontFamily:FontStyle?.regular
    },
    nidContainer: {
        width: Dimensions.get("window").width - 50,
        height: (Dimensions.get("window").width - 40) * 10 / 16,
        borderColor: Colors.primary,
        borderWidth: 1,
        padding: 5,
        borderRadius: 8
    },
    nidStyle: {
        flex: 1, objectFit: 'contain', height: '100%', width: '100%', borderRadius: 6,
    },
    nidPickerContainer: {
        flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 20, width: '40%'
    },
    nidPickerBtnContainer: {
        borderRadius: 100, width: 60, height: 60, justifyContent: 'center', alignItems: 'center', marginInline: 2,backgroundColor:'#FFECEBF2'
    },
    nidResultFailContainer: {
        width: 'auto',
        height: 'auto',
        padding: 10,
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.primary,
        backgroundColor: Colors.primary + '19',
        marginTop: 20,
        marginBottom: 10,
        marginHorizontal: 15,
        borderRadius: 8
    },
    nidResultContainer: {
        width: '100%',
        height: "auto",
        marginTop: 20,
        paddingInline: 20,
        alignItems: 'center',
        justifyContent: 'center'
    }
})
