import React, {useEffect, useRef} from 'react';
import {StyleSheet, Text, View, Image, TouchableOpacity, ToastAndroid,Dimensions} from "react-native";
import {Octicons, Ionicons} from "@expo/vector-icons";
import {Colors} from "../../assets/styles/colors";
import FaceDetectionComponent from "../ui-custom-component/face-detection-component";
import LottieView from "lottie-react-native";
import ekycStore from "../../store/ekyc-store";
import Icon from "react-native-vector-icons/AntDesign";
import validationHelper from "../../utility/validationHelper";
import {FaceMatchingRequests, GetEkycDataRequest} from "../../apiRequests/auth/auth-requests";
import {uriToBase64} from "../../utility/utility-functions";
import { FontStyle } from '../../assets/styles/commonStyles';
import AsyncStorage from "@react-native-async-storage/async-storage";
import {Toast} from "toastify-react-native";
import {useCameraPermissions} from "expo-camera";


const Ekyc3 = () => {
    const stepRef = useRef(0)
    const {ekyc3, setStage, onChangeEkyc3} = ekycStore();
    const [status, requestPermission] = useCameraPermissions();

    useEffect(() => {
        (async () => {
            let RegRefID = await AsyncStorage.getItem("RegistrationReferenceID");
            console.log(RegRefID);
            RegRefID && await GetEkycDataRequest(RegRefID);
            ToastAndroid.show(
                ekyc3.blinkCount + " - " +
                ekyc3.faceExpression + ' - ' + ekyc3.photoPath +
                ' - ' + ekyc3.nidPhoto + ' - ' + stepRef.current + ' - ' +
                ekyc3.photoVerificationResult, ToastAndroid.LONG
            );
        })()
    }, []);

    useEffect(() => {
        (async () => !status?.granted && await requestPermission())()
    }, [status])

    // useEffect(() => {
    //     (async () => {
    //         if (stepRef?.current !== 3 && ekyc3?.nidPhoto !== "") {
    //             const {blinkCount, faceExpression, photoPath, photoBase64, nidPhoto, photoVerificationResult} = ekyc3;
    //             console.log("pppp",blinkCount,faceExpression,photoPath,nidPhoto,stepRef.current,photoVerificationResult)
    //             if (blinkCount === 0) {
    //                 stepRef.current = 0;
    //             } else if (blinkCount >= 2 && stepRef.current === 0) {
    //                 stepRef.current = 1;
    //             } else if (blinkCount >= 2 && faceExpression === 'smiling' && photoPath !== "" && nidPhoto !== "" && stepRef.current <= 2 && photoVerificationResult === "") {
    //                 stepRef.current = 2;
                 
    //                 if(photoPath !== ""){
    //                     setStage("Step-4-Live-Photo");
    //                     stepRef.current = 3;
    //                     console.log("hellllooo",photoPath,nidPhoto)
    //                     const NidUserBase64Image = await uriToBase64(nidPhoto);
    //                     console.log(NidUserBase64Image)
    //                     let success = await FaceMatchingRequests(NidUserBase64Image, photoBase64);
    //                     print("Face Matching Result: ", success);
    //                     success ? Toast.success("Face matching completed!!") : Toast.error("Face matching failed!!");
    //                 }
    //             }
    //             else {
    //                 console.log(blinkCount + " - " + faceExpression + ' - ' + photoPath + ' - ' + nidPhoto + ' - ' + stepRef.current + ' - ' + photoVerificationResult);
    //             }
    //         }
    //     })()
    // }, [ekyc3])


    useEffect(() => {
        (async () => {
            if (stepRef?.current !== 3 && ekyc3?.nidPhoto !== "") {
                const {blinkCount, faceExpression, photoPath, photoBase64, nidPhoto, photoVerificationResult} = ekyc3;
                //console.log("pppp", blinkCount, faceExpression, photoPath, nidPhoto, stepRef.current, photoVerificationResult);
                if (blinkCount === 0) {
                    stepRef.current = 0;
                } else if (blinkCount >= 2 && stepRef.current === 0) {
                    stepRef.current = 1;
                } else if (blinkCount >= 2 && faceExpression === 'smiling' && photoPath !== "" && nidPhoto !== "" && stepRef.current <= 2 && photoVerificationResult === "") {
                    stepRef.current = 2;
    
                    if (photoPath !== "") {
                        try {
                            setStage("Step-4-Live-Photo");
                            stepRef.current = 3;
                            console.log("hellllooo", photoPath, nidPhoto);
    
                            // Check if nidPhoto is accessible
                            const response = await fetch(nidPhoto, { method: 'HEAD' });
                            if (!response.ok) {
                                //console.error("NID photo link is inaccessible:", nidPhoto);
                                Toast.error("NID photo is inaccessible. Please try again.");
                                return; // Exit early if the link is inaccessible
                            }
    
                            const NidUserBase64Image = await uriToBase64(nidPhoto);
                            //console.log(NidUserBase64Image);
    
                            let success = await FaceMatchingRequests(NidUserBase64Image, photoBase64);
                            console.log("Face Matching Result:", success);
    
                            success ? Toast.success("Face matching completed!!") : Toast.error("Face matching failed!!");
                        } catch (error) {
                            console.error("An error occurred during the face matching process:", error);
                            Toast.error("An error occurred. Please try again.");
                        }
                    }
                } else {
                    console.log(blinkCount + " - " + faceExpression + ' - ' + photoPath + ' - ' + nidPhoto + ' - ' + stepRef.current + ' - ' + photoVerificationResult);
                }
            }
        })();
    }, [ekyc3]);

    const resetEkyc3Data = () => {
        console.log(ekyc3?.blinkCount, ekyc3?.faceExpression, ekyc3?.photoPath, ekyc3?.photoVerificationResult, ekyc3?.nidPhoto, stepRef.current);
        onChangeEkyc3({
            photoBase64: "",
            blinkCount: 0,
            faceExpression: '',
            photoPath: '',
            photoVerificationResult: ''
        });
        stepRef.current=0;
    }



    return (
        <View style={styles.container}>
            <Text style={styles.headerText}>Take your live photo</Text>
            <View style={{position: 'relative'}}>
                {!validationHelper.isEmpty(ekyc3?.photoPath) && <View style={{position: 'absolute', right: 30, top: 30, zIndex: 9999}}>
                    <TouchableOpacity onPress={resetEkyc3Data}>
                        <Icon name='closecircleo' size={30}/>
                    </TouchableOpacity>
                </View>}
                <View style={styles.cameraContainer}>

                    {ekyc3.photoPath === "" ? (status?.granted ? <FaceDetectionComponent style={styles.camera}/> : null) :
                        <View style={styles.animationContainer}>
                            {!validationHelper.isEmpty(ekyc3?.photoPath) && (
                                <Image source={{uri: ekyc3?.photoPath}} style={styles?.previewImage} resizeMode="contain"/>
                            )}
                            {/*<LottieView*/}
                            {/*    loop={false} autoPlay*/}
                            {/*    style={{width: 360, height: 360, opacity: 0.5, position: "absolute", top: 0, bottom: 0, right: 0, left: 0}}*/}
                            {/*    source={require('../../assets/animation/success.json')}*/}
                            {/*/>*/}
                        </View>
                    }
                </View>
            </View>
            <View style={[
                styles.instructionContainer, {
                    borderColor: ekyc3?.faceExpression === 'smiling' ? 'green' : Colors.primary,
                    backgroundColor: ekyc3?.faceExpression === 'smiling' ? '#00ff001e' : Colors.primary + '1e'
                }
            ]}
            >
                {ekyc3?.blinkCount >= 2  ?
                    <View style={styles.instructionStyle}>
                        <Octicons name={'check-circle'} size={20} color={'green'}/>
                        <Text style={[styles.instructionText, {color: 'green'}]}>Blinked 2 times</Text>
                    </View>
                    : <View style={styles.instructionStyle}>
                        <Octicons name={'circle'} size={20} color={Colors.primary}/>
                        <Text style={styles.instructionText}>Please Blink 2 times</Text>
                    </View>
                }
                {ekyc3?.faceExpression === 'smiling' ?
                    <View style={[styles.instructionStyle, {marginTop: 5}]}>
                        <Octicons name={'check-circle'} size={20} color={'green'}/>
                        <Text style={[styles.instructionText, {color: 'green'}]}>Smile Detected</Text>
                    </View>
                    : <View style={[styles.instructionStyle, {marginTop: 5}]}>
                        <Octicons name={'circle'} size={20} color={Colors.primary}/>
                        <Text style={styles.instructionText}>Please Smile</Text>
                    </View>
                }
            </View>

            {!validationHelper.isEmpty(ekyc3?.photoVerificationResult) && (parseFloat(ekyc3?.photoVerificationResult) < 0.5 ?
                <View style={[styles.instructionContainer, {backgroundColor: '#00ff001e', borderColor: 'green'}]}>
                    <View style={styles.instructionStyle}>
                        <Octicons name={'check-circle'} size={20} color={'green'}/>
                        <Text style={[styles.instructionText, {color: 'green'}]}>Face Verification is Successful !!</Text>
                    </View>
                </View> :
                <View style={[styles.instructionContainer, {backgroundColor: Colors.primary + '1e', borderColor: Colors.primary}]}>
                    <View style={styles.instructionStyle}>
                        <Ionicons name={'close-circle-outline'} size={24} color={Colors.primary}/>
                        <Text style={[styles.instructionText, {color: Colors.primary, marginLeft: 10}]}>Face Verification is Unsuccessful !!</Text>
                    </View>
                </View>
            )}
        </View>
    );
};

export default Ekyc3;

const cameraContainer = {
    width: 250,
    height: 250,
}
const { width: screenWidth, height: screenHeight } = Dimensions.get('window');
const containerWidth = Math.min(screenWidth * 0.85, 360);
const containerHeight = containerWidth; // Maintain square aspect ratio (adjust as needed)

// Adjust for tablets (larger screens)
const isTablet = screenWidth >= 768; // Common tablet threshold
const scaleFactor = isTablet ? 1.2 : 1; // Increase size slightly for tablets

const styles = StyleSheet.create({
    container: {
        flex: 1, justifyContent: 'center', alignItems: 'center'
    },
    headerText: {
        fontSize: 24,
        textAlign: "center",
        marginBottom: 20,
        marginTop: 10,
        fontFamily: FontStyle?.regular
    },
    instructionContainer: {
        // flex: 1,
        width: '100%',
        marginVertical: 5,
        padding: 10,
        borderRadius: 8,
        borderWidth: 1,
    },
    instructionStyle: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start'
    },
    instructionText: {
        fontSize: 16, marginLeft: 15, color: Colors.primary,fontFamily:FontStyle?.medium
    },
    cameraContainer: {
        // width: 360,
        // height: 360,
        width: containerWidth * scaleFactor,
        height: containerHeight * scaleFactor,
        borderRadius: (containerWidth * scaleFactor)/2,
       // borderRadius:180,
        overflow: 'hidden',
    },
    camera: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    animationContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
    },
    previewImage: {
        width: containerWidth * scaleFactor, height: containerWidth * scaleFactor, borderRadius: (containerWidth * scaleFactor)/2
    },
})
