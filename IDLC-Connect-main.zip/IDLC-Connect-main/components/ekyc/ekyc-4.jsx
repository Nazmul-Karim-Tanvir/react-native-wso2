import React, {useEffect, useState} from 'react';
import {Dimensions, StyleSheet, Text, View, KeyboardAvoidingView, Platform} from "react-native";
import TableComponent from "../ui-custom-component/table-component";
import PTextInput from "../ui-custom-component/paper-text-input";
import PSelect from "../ui-custom-component/paper-select";
import {Colors} from "../../assets/styles/colors";
import ekycStore from "../../store/ekyc-store";
import {
    GetDistrictByDivisionCode,
    GetDivisionByCountryCode,
    GetPoliceStationByDivisionDistrictCode
} from "../../apiRequests/auth/common-requests";
import validationHelper from "../../utility/validationHelper";
import {FontStyle} from '../../assets/styles/commonStyles';
import translate from "translate";
import utilityStore from "../../store/utility-store";

const Ekyc4 = () => {
    const {nidInfo, ekyc4, onChangeEkyc4, stage, setStage} = ekycStore();
    const NIDInformation = [
        {
            Header: 'Full Name',
            Data: nidInfo?.FullName
        },
        // {
        //     Header: 'পিতা/ স্বামীর নাম',
        //     Data: nidInfo?.FatherName
        // },
        // {
        //     Header: 'মাতার নাম',
        //     Data: nidInfo?.MotherName
        // },
        {
            Header: 'NID Number',
            Data: nidInfo?.NidNo
        },
        {
            Header: 'Date of Birth',
            Data: nidInfo?.BirthDate
        },
    ];
    const [divisionList, setDivisionList] = useState([]);
    const [districtList, setDistrictList] = useState([]);
    const [policeStationList, setPoliceStationList] = useState([]);

    useEffect(() => {
        (async () => {
            let res1 = await GetDivisionByCountryCode();
            setDivisionList(res1.map((item) => {
                return {value: item?.DivisionCode, label: item?.Division}
            }));
            if (!validationHelper.isEmpty(ekyc4.DivisionCode)) {
                let res2 = await GetDistrictByDivisionCode(ekyc4.DivisionCode);
                setDistrictList(res2.map((item) => {
                    return {value: item?.CityCode, label: item?.city}
                }));
            }
            if (!validationHelper.isEmpty(ekyc4.DivisionCode) && !validationHelper.isEmpty(ekyc4.DistrictCode)) {
                let res3 = await GetPoliceStationByDivisionDistrictCode(ekyc4.DistrictCode);
                setPoliceStationList(res3.map((item) => {
                    return {value: item?.PSID, label: item?.PS}
                }));
            }
        })()
    }, [ekyc4.DivisionCode, ekyc4.DistrictCode]);

    useEffect(() => {
        stage !== "Step-5-NID-Info-Confirm" && setStage("Step-5-NID-Info-Confirm");
        // console.log("division",ekyc4?.DivisionCode,ekyc4?.Division)
    }, [ekyc4])

    // useEffect(() => {
    //     (async () => {
    //         utilityStore.getState().setIsLoading(true);
    //         let address = await translate(nidInfo?.Address, {from: "bn", to: "en"});

    //         let res1 = await GetDivisionByCountryCode();
    //         res1 = res1.map((item) => {return {value: item?.DivisionCode, label: item?.Division}});
    //         setDivisionList(res1);

    //         let DivisionCode = res1?.find(item => item.label.toLowerCase() === address.split(",")[0].toLowerCase()?.replace(/\s/g, ""))?.value;
    //         let Division = address.split(",")[0];

    //         let res2 = await GetDistrictByDivisionCode(DivisionCode);
    //         res2 = res2.map((item) => {return {value: item?.CityCode, label: item?.city}});
    //         setDistrictList(res2);

    //         let DistrictCode = res2?.find(item => item.label.toLowerCase() === address.split(",")[1].toLowerCase()?.replace(/\s/g, ""))?.value;
    //         let District = address.split(",")[1];

    //         onChangeEkyc4({
    //             "FatherName": await translate(nidInfo?.FatherName, {from: "bn", to: "en"}),
    //             "MotherName": await translate(nidInfo?.MotherName, {from: "bn", to: "en"}),
    //             "MailingAddress": address,
    //             "DivisionCode": DivisionCode,
    //             "Division": Division,
    //             "DistrictCode": DistrictCode,
    //             "District": District,
    //             "PostCode": address.split(",")[address.split(",").length - 1]
    //         })
    //         utilityStore.getState().setIsLoading(false);
    //     })()
    // }, [nidInfo])

    return (
        <View style={{flex: 1, padding: 15}}>
            <Text style={styles.labelStyle}>NID Information</Text>
            <TableComponent rowData={NIDInformation} style={{marginBottom: 20}}/>

            <View style={{borderBottomWidth: 1, borderColor: 'gray', marginBottom: 10}}>
                <Text style={styles.labelStyle}>Please fill-up your personal information in English</Text>
            </View>
            <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{flex: 1}}>
                {/* <View> */}
                    <PTextInput value={ekyc4?.FatherName} onChange={(data) => onChangeEkyc4({"FatherName": data})} label="Father's Name" placeholder="Enter Father's Name in English" style={{marginBlock: 5}}/>
                    <PTextInput value={ekyc4?.MotherName} onChange={(data) => onChangeEkyc4({"MotherName": data})} label="Mother's Name" placeholder="Enter Mother's Name in English" style={{marginBlock: 5}}/>
                    <PTextInput value={ekyc4?.MailingAddress} onChange={(data) => onChangeEkyc4({"MailingAddress": data})} type='textarea' label="Mailing Address" placeholder="Enter Mailing Address in English" style={{marginBlock: 5}}/>
                   
                    <PSelect
                        value={ekyc4?.DivisionCode}
                        onChange={async (data) => {
                            console.log(data);
                            let division = divisionList?.find(item => item.value === parseInt(data))?.label;
                            onChangeEkyc4({"DivisionCode": data, "Division": division})

                            let res2 = await GetDistrictByDivisionCode(data);
                            setDistrictList(res2.map((item) => {return {value: item?.CityCode, label: item?.city}}));
                        }}
                        options={divisionList} label="Division" style={{marginBlock: 5}}
                    />
                    <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                        <PSelect
                            value={ekyc4?.DistrictCode}
                            onChange={async (data) => {
                                let district = districtList.find(item => item.value === parseInt(data))?.label;
                                onChangeEkyc4({"DistrictCode": data, "District": district});

                                let res3 = await GetPoliceStationByDivisionDistrictCode(data);
                                setPoliceStationList(res3.map((item) => {return {value: item?.PSID, label: item?.PS}}));
                            }}
                            options={districtList} label="District" style={{marginBlock: 5, width: '49%'}}/>
                        <PTextInput value={ekyc4?.PostCode} keyboardType='numeric' onChange={(data) => {onChangeEkyc4({"PostCode": data})}}
                                    label="Postal Code" placeholder="Postal Code" style={{marginBlock: 5, width: '49%'}}/>
                    </View>
                    <PSelect value={ekyc4?.PoliceStationCode} onChange={(data) => {
                        onChangeEkyc4({
                            "PoliceStationCode": data,
                            "PoliceStation": policeStationList.find(item => item.value === parseInt(data))?.label,
                        });
                    }} options={policeStationList} label="Police Station" style={{marginBlock: 5}}/>
                {/* </View> */}
            </KeyboardAvoidingView>
        </View>
    );
};

export default Ekyc4;

const styles = StyleSheet.create({
    labelStyle: {
        fontSize: 16, fontWeight: 'bold', marginBottom: 5, fontFamily: FontStyle?.regular
    },
    nidContainer: {
        width: Dimensions.get("window").width - 50,
        height: (Dimensions.get("window").width - 40) * 10 / 16,
        borderColor: Colors.primary,
        borderWidth: 1,
        padding: 5,
        borderRadius: 8,
        marginBottom: 6
    },
    nidStyle: {
        flex: 1, objectFit: 'contain', height: '100%', width: '100%', borderRadius: 6
    },
})
