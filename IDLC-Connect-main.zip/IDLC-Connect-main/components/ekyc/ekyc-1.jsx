import React from 'react';
import {View, Text, StyleSheet, Image, Dimensions, Platform, Alert} from "react-native";
import {Colors} from "../../assets/styles/colors";
import {AntDesign, Feather} from "@expo/vector-icons";
import CButton from "../ui-custom-component/paper-button";
import {
    NIDCheckOCR,
    NIDTopOCR,
    pickImageFromCamera,
    pickImageFromGallery,
    CropImageExpo
} from "../ui-custom-component/image-picker-component";
import ekycStore from "../../store/ekyc-store";
import {cropImage} from '../../utility/utility-functions';
import {FaceDetectionRequests} from '../../apiRequests/auth/auth-requests';
import utilityStore from "../../store/utility-store";
import { FontStyle } from '../../assets/styles/commonStyles';
import validationHelper from "../../utility/validationHelper";
import * as ImageManipulator from "expo-image-manipulator";
import * as FileSystem from 'expo-file-system';
import UtilityStore from "../../store/utility-store";

const Ekyc1 = () => {
    const {ekyc1, onChangeEkyc1, setStage} = ekycStore();


    const handleImage = async (ImageSource) => {
        utilityStore.getState().setIsLoading(true);
        console.log("Image handle", ImageSource);
        let FinalImg = ImageSource === 'Camera' ? await pickImageFromCamera() : await pickImageFromGallery();
        if(!validationHelper.isEmpty(FinalImg)){
            console.log("Before Crop: ", FinalImg);
            FinalImg =  Platform.OS=== "ios" ? await CropImageExpo(FinalImg,[16,10]) : await ImageManipulator.manipulateAsync(FinalImg, [{ resize: {width: 1000}}]);
            console.log("After Crop: ", FinalImg);
            let cropTopPortion = await cropImage(FinalImg, 0, 0, 1, 0.3);
            let cropLeftPortion = await cropImage(FinalImg, 0, 0.30, 0.35, 0.7);
            let cropRightPortion = await cropImage(FinalImg, 0.25, 0.30, 0.75, 0.7);

            let TopData = await NIDTopOCR(cropTopPortion?.uri)
            let leftImgDetect = await FaceDetectionRequests(cropLeftPortion?.base64)

            let NIDData = (TopData && leftImgDetect) && await NIDCheckOCR(cropRightPortion?.uri);

            if(!validationHelper.isEmpty(NIDData)){
                onChangeEkyc1({
                    NidFrontImg: FinalImg?.uri,
                    NidNumber: NIDData?.NidNumber,
                    NidName: NIDData?.Name,
                    Dob: NIDData?.DOB,
                })
                setStage("Step-2-NID-Front");
            }
        }
        else {
            utilityStore.getState().setIsLoading(false);
        }

    }

    return (
        <View style={styles.container}>
            <Text style={styles.headerText}>Attach front side of your NID</Text>
            <View style={styles.nidContainer}>
                <Image
                    source={!validationHelper.isEmpty(ekyc1?.NidFrontImg) ? {uri: ekyc1?.NidFrontImg} : require('../../assets/images/NID_Front.png')}
                    style={styles.nidStyle}/>
            </View>
            <View style={styles.nidPickerContainer}>
                <CButton onPress={() => handleImage('Camera')} mode='outlined'
                         buttonStyles={styles.nidPickerBtnContainer}>
                    <Feather name={'camera'} size={25} color={Colors.primary}/>
                </CButton>
                <CButton onPress={() => handleImage('Gallery')} mode='outlined'
                         buttonStyles={styles.nidPickerBtnContainer}>
                    <Feather name={'upload'} size={25} color={Colors.primary}/>
                </CButton>
            </View>
            { !validationHelper.isEmpty(ekyc1.NidFrontImg) && validationHelper.isEmpty(ekyc1?.NidNumber) ?
                <View style={styles.nidResultFailContainer}>
                    <AntDesign name="infocirlceo" size={24} color="black" style={{color: Colors.primary, marginEnd: 10}}/>
                    <Text style={{color: Colors.primary, fontSize: 16, flexShrink: 1, fontFamily: FontStyle?.medium}}>NID data is incorrect, Please make sure to attach your valid NID and try again!!</Text>
                </View>
                : ekyc1?.NidNumber === "" ?
                    <></>
                    : <View style={styles.nidResultContainer}>
                        <View style={styles.nidDataContainer}>
                            <View style={styles.nidDataHeaderContainer}>
                                <Text style={{textAlign: 'center', color: '#888',fontFamily: FontStyle?.regular}}>Extracted NID Data </Text>
                            </View>

                            <View style={styles.nidDataTextContainer}>
                                <Text style={{fontSize: 16, color: '#ff4444', fontFamily: FontStyle?.medium}}>Name </Text>
                                <Text style={{fontSize: 16, fontFamily: FontStyle?.medium}}>{ekyc1?.NidName}</Text>
                            </View>
                            <View style={styles.nidDataTextContainer}>
                                <Text style={{fontSize: 16, color: '#ff4444',fontFamily:FontStyle?.medium}}>Date of Birth </Text>
                                <Text style={{fontSize: 16, fontFamily: FontStyle?.medium}}>{ekyc1?.Dob}</Text>
                            </View>
                            <View style={styles.nidDataTextContainer}>
                                <Text style={{fontSize: 16, color: '#ff4444', fontFamily: FontStyle?.medium}}>NID No </Text>
                                <Text style={{fontSize: 16, fontFamily: FontStyle?.medium}}>{ekyc1?.NidNumber}</Text>
                            </View>
                        </View>
                        {/*<View style={styles.nidResultFailContainer}>*/}
                        {/*    <AntDesign name="infocirlceo" size={24} color="black"*/}
                        {/*               style={{color: Colors.primary, marginEnd: 10}}/>*/}
                        {/*    <Text style={{color: Colors.primary, fontSize: 16, flexShrink: 1, fontFamily: FontStyle?.medium}}>If your NID information seems wrong, Please attach your NID again!!</Text>*/}
                        {/*</View>*/}
                    </View>}
        </View>
    );
};

export default Ekyc1;

const styles = StyleSheet.create({
    container: {
        flex: 1, justifyContent: 'center', alignItems: 'center'
    },
    headerText: {
        fontSize: 24,
        textAlign: "center",
        marginBottom: 20,
        marginTop: 10,
        fontFamily: FontStyle?.regular,
        lineHeight: 26
    },
    nidContainer: {
        width: Dimensions.get("window").width - 50,
        height: (Dimensions.get("window").width - 40) * 10 / 16,
        borderColor: Colors.primary,
        borderWidth: 1,
        padding: 5,
        borderRadius: 8
    },
    nidStyle: {
        flex: 1, objectFit: 'contain', height: '100%', width: '100%', borderRadius: 6,
    },
    nidPickerContainer: {
        flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 20, width: '40%'
    },
    nidPickerBtnContainer: {
        borderRadius: 100,
        width: 60,
        height: 60,
        justifyContent: 'center',
        alignItems: 'center',
        marginInline: 2,
        backgroundColor: '#FFECEBF2'
    },
    nidResultFailContainer: {
        width: 'auto',
        height: 'auto',
        padding: 10,
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.primary,
        backgroundColor: Colors.primary + '19',
        marginVertical: 10,
        marginHorizontal: 15,
        borderRadius: 8
    },
    nidResultContainer: {
        width: '100%',
        height: "auto",
        marginTop: 10,
        alignItems: 'center',
        justifyContent: 'center'
    },
    nidDataContainer: {
        backgroundColor: 'rgb(237,237,237)', paddingInline: 20, paddingBlock: 10, width: '100%'
    },
    nidDataHeaderContainer: {
        width: '100%', borderBottomWidth: 1, borderColor: '#888', marginBottom: 5, paddingBottom: 5
    },
    nidDataTextContainer: {
        width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between'
    },
})
