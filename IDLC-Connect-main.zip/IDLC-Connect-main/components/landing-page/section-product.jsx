import React from 'react';
import OpenDeposit from "../../assets/images/new_deposit.svg";
import IDLCLogo from "../../assets/images/IDLC_Logo_mini.svg";
import ReferCustomer from "../../assets/images/reference.svg";
import TradeOnline from "../../assets/images/bo_account.svg";
import MutualFund from "../../assets/images/mutual_fund.svg";
import ManageInvestments from "../../assets/images/investment.svg";
import {Dimensions, FlatList, StyleSheet, View, Image, Text, TouchableOpacity} from "react-native";
import {useNavigation, useRouter} from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { FontStyle } from '../../assets/styles/commonStyles';

const numColumns = 3;
const size = (Dimensions.get('window').width - 40) / numColumns;

const SectionProduct = () => {
    const router = useRouter();
    const LandingIconList = [
        {
            Id: 1,
            Icon: OpenDeposit,
            Title: "Open Deposit",
            Path: '/open-deposit',
        },
        {
            Id: 2,
            Icon: MutualFund,
            Title: "Mutual Fund",
            Path: '/mutual-fund/aml-onboarding',
        },
        {
            Id: 3,
            Icon: ManageInvestments,
            Title: "Manage Investments",
            Path: '/manage-investments/il-onboarding',
        },
        {
            Id: 4,
            Icon: TradeOnline,
            Title: "Trade Online",
            Path: '/bo-account/sl-onboarding',
        },
        {
            Id: 5,
            Icon: ReferCustomer,
            Title: "Refer Customer",
            Path: '/',
        },
        {
            Id: 6,
            Icon: IDLCLogo,
            Title: "My IDLC",
            Path: '/',
        },
    ];

    const handleProductOpen = async (product) => {
        console.log(product);
        await AsyncStorage.setItem("RedirectTo", product?.Path);
        router.push('page-phone-entry');
    }

    const GridItem = ({item}) => (
        <TouchableOpacity onPress={async () => await handleProductOpen(item)} style={styles.item}>
            <Image source={require('../../assets/images/cornerIcon.png')} style={{position: 'absolute', top: 10, left: 10, width: 20, height: 20 }} />
            <item.Icon width={40} height={40} />
            <Text style={styles.title}>{item.Title}</Text>
        </TouchableOpacity>
    );

    return (
        <FlatList
            data={LandingIconList}
            renderItem={({item, index }) => <GridItem item={item} />}
            keyExtractor={(item) => item.Id}
            numColumns={numColumns}
            contentContainerStyle={styles.container}
        />
    );
};

export default SectionProduct;

const styles = StyleSheet.create({
    container: {
        padding: 5,
    },
    item: {
        position: 'relative',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 5,
        backgroundColor: '#ffffff',
        padding: 10,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#cd0a13',
        width: size,
        height: size
    },
    image: {
        width: 60, // adjust based on padding
        height: 60,
        borderRadius: 8,
    },
    title: {
        marginTop: 8,
        fontSize: 12,
        textAlign: 'center',
        fontFamily:FontStyle?.light,
    },
});
