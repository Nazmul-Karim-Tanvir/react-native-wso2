import {TouchableOpacity, View, StyleSheet} from "react-native";
import {Feather, Octicons} from "@expo/vector-icons";
import {useNavigation, useRouter} from "expo-router";

const SectionFooterButtons = () => {
    const router = useRouter();

    return (
        <View style={styles.buttonContainer}>
            <TouchableOpacity onPress={() => {}} style={[styles.buttonStyle, styles.phoneBtnStyle]} >
                <Feather name="phone" size={24} color="#cd0a13" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => {}} style={[styles.buttonStyle, styles.facebookBtnStyle]}>
                <Feather name="facebook" size={24} color="#2563eb" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => {}} style={[styles.buttonStyle, styles.linkedInBtnStyle]}>
                <Feather name="linkedin" size={24} color="#0369a1" />
            </TouchableOpacity>
            <TouchableOpacity
                onPress={() => {router.push("page-branch")}}
                style={[styles.buttonStyle, styles.branchBtnStyle]}
            >
                <Octicons name="organization" size={24} color="#15803d" />
            </TouchableOpacity>
        </View>
    );
};

export default SectionFooterButtons;

const styles = StyleSheet.create({
    buttonContainer: {
        flexDirection: "row", justifyContent: "center", alignItems: "center", marginBottom: 15
    },
    buttonStyle: {
        marginInline: 3,
        width:50, height:50, borderRadius: 100, borderWidth: 1, justifyContent: "center", alignItems: "center", padding: 1
    },
    phoneBtnStyle: {
        borderColor:'#cd0a13', backgroundColor:'#cd0a131a'
    },
    facebookBtnStyle: {
        borderColor:'#2563eb', backgroundColor:'#dbeafe'
    },
    linkedInBtnStyle: {
        borderColor:'#0369a1', backgroundColor:'#e0f2fe'
    },
    branchBtnStyle: {
        borderColor:'#15803d', backgroundColor:'#dcfce7'
    },
})
