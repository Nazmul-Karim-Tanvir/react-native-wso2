import React from 'react';
import TradeOnline from "../../assets/images/trade.svg";
import OpenBoAccount from "../../assets/images/open_bo.svg";
import KnowledgePortal from "../../assets/images/research.svg";
import DepositFund from "../../assets/images/deposit.svg";
import WithdrawFund from "../../assets/images/withdraw.svg";
import ApplyIPO from "../../assets/images/ipo.svg";
import {Dimensions, FlatList, StyleSheet, Image, Text, TouchableOpacity} from "react-native";
import {useRouter} from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {FontStyle} from "../../assets/styles/commonStyles";
import OpenDeposit from "../../assets/images/new_deposit.svg";
import MutualFund from "../../assets/images/mutual_fund.svg";
import ManageInvestments from "../../assets/images/investment.svg";
import ReferCustomer from "../../assets/images/reference.svg";
import IDLCLogo from "../../assets/images/IDLC_Logo_mini.svg";
import {AppType} from "../../apiRequests/base-url-config";

const numColumns = 3;
const size = (Dimensions.get('window').width - 40) / numColumns;

const SectionProductOthers = () => {
    const router = useRouter();
    const LandingProductsSL = [
        {
            Id: 1,
            Icon: TradeOnline,
            Title: "Trade Online",
            Path: '/',
        },
        {
            Id: 2,
            Icon: OpenBoAccount,
            Title: "Open BO Account",
            Path: '/',
        },
        {
            Id: 3,
            Icon: KnowledgePortal,
            Title: "Knowledge Portal",
            Path: '/',
        },
        {
            Id: 4,
            Icon: DepositFund,
            Title: "Deposit Fund",
            Path: '/',
        },
        {
            Id: 5,
            Icon: WithdrawFund,
            Title: "Withdraw Fund",
            Path: '/',
        },
        {
            Id: 6,
            Icon: ApplyIPO,
            Title: "Apply IPO",
            Path: '/',
        },
    ];
    const LandingProductsAML = [
        {
            Id: 1,
            Icon: OpenDeposit,
            Title: "Open Deposit",
            Path: '/open-deposit',
        },
        {
            Id: 2,
            Icon: MutualFund,
            Title: "Mutual Fund",
            Path: '/mutual-fund/aml-onboarding',
        },
        {
            Id: 3,
            Icon: ManageInvestments,
            Title: "Manage Investments",
            Path: '/manage-investments/il-onboarding',
        },
        {
            Id: 4,
            Icon: TradeOnline,
            Title: "Trade Online",
            Path: '/bo-account/sl-onboarding',
        },
        {
            Id: 5,
            Icon: ReferCustomer,
            Title: "Refer Customer",
            Path: '/',
        },
        {
            Id: 6,
            Icon: IDLCLogo,
            Title: "My IDLC",
            Path: '/',
        },
    ];

    const handleProductOpen = async (product) => {
        await AsyncStorage.setItem("RedirectTo", product?.Path);
        router.push('page-phone-entry');
    }

    const GridItem = ({item}) => (
        <TouchableOpacity onPress={async () => await handleProductOpen(item)} style={styles.item}>
            <Image source={require('../../assets/images/cornerIcon.png')} style={{position: 'absolute', top: 10, left: 10, width: 20, height: 20 }} />
            <item.Icon width={40} height={40} />
            <Text style={styles.title}>{item.Title}</Text>
        </TouchableOpacity>
    );

    return (
        <FlatList
            data={AppType.split("-").find(item => item === "sl") ? LandingProductsSL : LandingProductsAML}
            renderItem={({item, index }) => <GridItem item={item} />}
            keyExtractor={(item) => item.Id}
            numColumns={numColumns}
            contentContainerStyle={styles.container}
        />
    );
};

export default SectionProductOthers;

const styles = StyleSheet.create({
    container: {
        padding: 5,
    },
    item: {
        position: 'relative',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 5,
        backgroundColor: '#ffffff',
        padding: 10,
        borderRadius: 4,
        width: size,
        height: size,
        shadowColor: '#000000',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.25,
        shadowRadius: 1,
        elevation: 5
    },
    image: {
        width: 60, // adjust based on padding
        height: 60,
        borderRadius: 8,
    },
    title: {
        marginTop: 8,
        fontSize: 12,
        textAlign: 'center',
        fontFamily: FontStyle.medium,
        lineHeight: 14,
    },
});
