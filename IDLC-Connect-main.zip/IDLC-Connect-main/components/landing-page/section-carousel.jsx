import React from "react";
import Carousel from "../ui-custom-component/carousel";
import {Text, TouchableOpacity, View, StyleSheet} from "react-native";
import { FontStyle } from "../../assets/styles/commonStyles";

const carouselData = [
    {
        id: "1",
        image: require("../../assets/images/Product_Finance.jpg"),
    },
    {
        id: "2",
        image: require("../../assets/images/Product_BO_Account.jpg"),
        title: "Secure Savings",
    },
    {
        id: "3",
        image: require("../../assets/images/Product_ShariahFund.jpg"),
        title: "Smart Returns",
    },
    {
        id: "4",
        image: require("../../assets/images/Product_IncomeFund.jpg"),
    },
    {
        id: "5",
        image: require("../../assets/images/Product_EasyInvest.jpg"),
        title: "Secure Savings",
    },
];

export default function SectionCarousel() {
    return (
        <>
            <Carousel options={carouselData}/>
            <View style={styles.viewMoreContainer}>
                <TouchableOpacity>
                    <Text style={styles.viewMoreText}>View More</Text>
                </TouchableOpacity>
            </View>
        </>
    );
};

const styles = StyleSheet.create({
    viewMoreContainer: {
        width:'100%', justifyContent:'flex-end', alignItems: 'flex-end', padding: 10, marginTop: -35
    },
    viewMoreText: {
        color: '#097df1', textDecorationLine: 'underline',fontFamily: FontStyle?.regular
    }
})