import React, {useRef, useState} from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    Platform, TouchableWithoutFeedback,
} from 'react-native';
import { Picker,PickerIOS } from '@react-native-picker/picker';
import Modal from 'react-native-modal';
import {TextInput} from "react-native-paper";
import {Colors} from "../../assets/styles/colors";
import {FontStyle} from "../../assets/styles/commonStyles";

const PSelect = ({value='', onChange, options=[], label='', style}) => {
    const [isModalVisible, setModalVisible] = useState(false);
    const pickerRef = useRef();

    function open() {
        console.log("OPEN");
        pickerRef.current.focus()
    }

    const toggleModal = () => setModalVisible(!isModalVisible);

    return (
        <View style={[styles.container, style]}>
            {Platform.OS === "android" ? (
                <View style={{width: '100%'}}>
                    <TouchableOpacity onPress={open}>
                        <TextInput
                            style={{
                                width: "100%",
                                fontSize: 18,
                                backgroundColor: "transparent",
                                alignContent: "center",
                                fontFamily: FontStyle.medium,
                                lineHeight: 20
                            }}
                            contentStyle={{fontFamily: FontStyle.medium, marginTop: 2, marginBottom: 2, lineHeight: 30}}
                            dense
                            theme={{colors: {primary: "#777", background: "transparent"}, roundness: 8}}
                            mode={'flat'}
                            label={label}
                            editable={false}
                            value={options.find(item => item.value === value)?.label}
                        />
                    </TouchableOpacity>
                    <View style={{display: 'none'}}>
                        <Picker
                            ref={pickerRef}
                            selectedValue={value}
                            onValueChange={(itemValue) => {onChange(itemValue)}}
                            style={{height: 50, width: '100%'}}
                            selectionColor={Colors.primary}
                        >
                            <Picker.Item style={{color: '#a1a1a1'}} enabled={false} value='' label={label} />
                            {options?.length > 0 ? options?.map((option, idx) => (
                                <Picker.Item key={idx} value={option.value} label={option.label} />
                            )) : null}
                        </Picker>
                    </View>
                </View>
            ) : (
                <>
                <TextInput
                    style={{
                        width: "100%",
                        fontSize: 18,
                        backgroundColor: "transparent",
                        alignContent: "center",
                        fontFamily: FontStyle.medium,
                        lineHeight: 20
                    }}
                    contentStyle={{fontFamily: FontStyle.medium, marginTop: 2, marginBottom: 2, lineHeight: 30}}
                    theme={{ colors: { primary: "#777", background: "transparent" }, roundness: 8 }}
                    mode={'flat'}
                    label={label}
                    editable={false}
                    value={options.find(item => item.value === parseInt(value))?.label}
                    onPressIn={toggleModal}
                />

                <Modal
                    isVisible={isModalVisible}
                    onBackdropPress={toggleModal}
                    style={styles.modal}
                >
                    <View style={styles.modalContent}>
                        <Text style={styles.modalTitle}>Choose an Option</Text>
                        <PickerIOS
                            selectedValue={value}
                            onValueChange={onChange}
                            selectionColor={Colors.primary}
                            style={styles.picker}

                        >
                            {options?.length > 0 ? options?.map((option, idx) => (
                                <PickerIOS.Item key={option.value} value={option.value} label={option.label} color='#000' />
                            )) : []}
                        </PickerIOS>
                        <TouchableOpacity onPress={toggleModal} style={styles.closeButton}>
                            <Text style={styles.closeButtonText}>Done</Text>
                        </TouchableOpacity>
                    </View>
                </Modal>
            </>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        width: '100%',
        justifyContent: "center",
        alignItems: "center",
    },
    button: {
        backgroundColor: "#007BFF",
        padding: 10,
        borderRadius: 5,
    },
    buttonText: {
        color: "#fff",
        fontSize: 16,
    },
    selectedText: {
        marginTop: 20,
        fontSize: 18,
        color: "#333",
    },
    androidPicker: {
        borderColor: '#777',
        borderWidth: 1,
        borderRadius: 8,
        width: "100%",
        backgroundColor: "white",
        marginTop: 6,
        position: "relative",
    },
    androidLabelContainer: {
        position: 'absolute',
        top: -1,
        left: 8,
        paddingInline: 5,
        backgroundColor: 'white',
        width: 'auto'
    },
    modal: {
        justifyContent: "flex-end",
        margin: 0,
    },
    modalContent: {
        backgroundColor: "#fff",
        padding: 10,
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
    },
    modalTitle: {
        fontSize: 18,
        fontWeight: "bold",
        marginBottom: 0,
    },
    closeButton: {
        backgroundColor: "#007BFF",
        padding: 10,
        borderRadius: 5,
        alignSelf: "center",
        marginTop: 0,
        marginBottom: 10,
    },
    closeButtonText: {
        color: "#fff",
        fontSize: 16,
    },
    outlinedPicker: {
        width: "80%",
        borderWidth: 1,
        borderColor: "#ccc",
        borderRadius: 4,
        backgroundColor: "#fff",
        justifyContent: "center",
        paddingVertical: Platform.OS === "android" ? 0 : 5,
    },


    picker: {
        width: '100%',
    },




});

export default PSelect;
