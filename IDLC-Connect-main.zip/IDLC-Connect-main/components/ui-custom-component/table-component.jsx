import React from 'react';
import {StyleSheet, Text, View} from "react-native";
import { FontStyle } from '../../assets/styles/commonStyles';

const TableComponent = ({rowData, style}) => {
    return (
        <View style={[styles.container, style]}>
            {rowData?.map((item, index) => (
                <View key={index.toString()} style={[styles.rowContainer, {marginBottom: index === rowData.length -1 ? 0 : 5}]}>
                    <Text style={{fontSize: 14, width: '35%',fontFamily:FontStyle?.regular}}>{item?.Header}</Text>
                    <Text style={{fontSize: 14, width: '5%', textAlign: 'center',fontFamily:FontStyle?.regular}}>:</Text>
                    <Text style={{fontSize: 14, width: '60%',fontFamily:FontStyle?.light}}>{item?.Data}</Text>
                </View>
            ))}
        </View>
    );
};

export default TableComponent;

const styles = StyleSheet.create({
    container: {
        width: '100%', padding: 5, borderWidth: 1, borderColor: 'gray'
    },
    rowContainer: {
        flexDirection: 'row', alignItems: 'flex-start',
    }
})