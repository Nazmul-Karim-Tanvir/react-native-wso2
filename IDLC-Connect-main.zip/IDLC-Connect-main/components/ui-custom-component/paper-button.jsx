import {StyleSheet, Text, TouchableOpacity} from 'react-native';
import {Icon} from 'react-native-paper';
import React from 'react';
import {Colors} from "../../assets/styles/colors";
import { FontStyle } from '../../assets/styles/commonStyles';

export default function CButton({id, disabled=false, mode='outlined', onPress=()=>{}, icon, children, leftIcon=false, buttonStyles=null, textStyle=null}) {

    return (
        <TouchableOpacity disabled={disabled} id={id} style={[styles.buttonStyles, mode === 'outlined' ? styles.buttonOutlined : mode === 'primary' ? styles.buttonPrimary : styles.buttonLink, {flexDirection: leftIcon ? 'row' : 'row-reverse'},buttonStyles]} onPress={onPress}>
            {icon && <Icon size={20} color={mode === 'primary' ? 'white' : Colors.primary} source={icon}/>}
            <Text style={[mode === 'primary' ? styles.buttonTextPrimary : mode === 'outlined' ? styles.buttonTextOutlined : styles.buttonTextLink, textStyle]}>
                {children}
            </Text>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    buttonStyles: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPrimary: {
        borderRadius: 8,
        borderWidth: 1,
        borderColor: Colors.primary,
        backgroundColor: Colors.primary,
        height: 50,
        width: '100%',
    },
    buttonOutlined: {
        borderRadius: 8,
        borderWidth: 1,
        borderColor: Colors.primary,
        height: 50,
        width: '100%',
    },
    buttonLink: {
        borderRadius: 8,
        backgroundColor: 'transparent',
        height: 'auto',
        width: 'auto',
        padding: 0,
    },
    buttonTextPrimary: {
        color: 'white',
        fontSize: 18,
        fontWeight: 400,
        fontFamily: FontStyle?.regular,
    },
    buttonTextOutlined: {
        color: Colors.primary,
        fontSize: 18,
        fontWeight: 400,
        fontFamily: FontStyle?.regular,
    },
    buttonTextLink: {
        color: '#4949ff',
        fontSize: 18,
        fontWeight: 400,
        textDecorationLine: 'underline',
        fontFamily:FontStyle?.regular,
    },
    RightIcon: {
        color: Colors.primary,
        marginLeft: 20,
    },
    LeftIcon:{
        color: Colors.primary,
        marginRight: 20,
    },
});
