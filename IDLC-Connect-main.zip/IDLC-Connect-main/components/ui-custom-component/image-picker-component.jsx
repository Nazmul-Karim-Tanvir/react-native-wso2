import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import TextRecognition from "@react-native-ml-kit/text-recognition";
import moment from "moment";

export const CropImageExpo = async (uri, aspectRatio=[16,10]) => {
    try {
        if (!uri) throw new Error('No image URI provided');

        // Get image dimensions using manipulateAsync
        const info = await ImageManipulator.manipulateAsync(
            uri,
            [],
            { base64: false }
        );

        const { width, height } = info;

        const newWidth = Math.min(width, height * (aspectRatio[0] / aspectRatio[1]));
        const newHeight = Math.min(height, width * (aspectRatio[1] / aspectRatio[0]));

        return await ImageManipulator.manipulateAsync(
            uri,
            [
                {
                    crop: {
                        originX: (width - newWidth) / 2,
                        originY: (height - newHeight) / 2,
                        width: newWidth,
                        height: newHeight,
                    },
                },
            ],
            {
                compress: 1,
                format: ImageManipulator.SaveFormat.JPEG,
                base64: true
            }
        );
    } catch (error) {
        console.error('Error cropping image:', error);
        throw error;
    }
};

export const pickImageFromCamera = async (aspectRatio=[16,10]) => {
    let result = await ImagePicker.launchCameraAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: aspectRatio,
        quality: 1,
    });


    if (!result.canceled) {
        return result.assets[0].uri;
    } else return null;
};
export const pickImageFromGallery = async (aspectRatio=[16,10]) => {

    let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: aspectRatio,
        quality: 1,
    });

    if (!result.canceled) {
        return result.assets[0].uri;
    } else return null;
};
export const NIDCheckOCR = async (imageURL) => {
    console.log("Inside NID OCR");
    const result = await TextRecognition.recognize(imageURL);
    console.log(imageURL, result);
    let textList = [];
    for (let block of result.blocks) {
        for (let line of block.lines) {
            textList.push(line.text);
        }
    }
    let lowerCaseText = textList.map(item => (item.replace(/\s+/g, '')).toLowerCase());
    console.log(lowerCaseText);

    let name = textList.map(str => {
        const match = str.match(/Name\s*(.+)/g);
        return match ? (match[0].replace(":", "")).split("Name")[1] : null;
    }).filter(Boolean)[0];
    name = (name === null || name === undefined) ? textList.find(item => item === 'Name') ? textList[textList.findIndex(item => item === 'Name')+1] : (textList[3].match(/^[^0-9]*$/g) || '') : name;

    let dobText = lowerCaseText.map(str => {
        const match = str.match(/(\d{1,2})([a-zA-Z]{3})(\d{4})/g);
        return match ? moment(match[0], 'DDMMMYYYY').format('YYYY-MM-DD') : null;
    }).filter(Boolean)[0];

    let nidNumberText = lowerCaseText.map(str => {
        const match = str.match(/\d{10,}/g);
        return match ? match[0] : null;
    }).filter(Boolean)[0];

    console.log(name, dobText, nidNumberText);

    return {
        Name: name,
        DOB: dobText,
        NidNumber: nidNumberText
    };
}
export const NIDTopOCR = async (imageURL) => {
    const result = await TextRecognition.recognize(imageURL);
    console.log(imageURL, result);
    let textList = [];
    for (let block of result.blocks) {
        for (let line of block.lines) {
            textList.push(line.text);
        }
    }
    let lowerCaseText = textList.map(item => (item.replace(/\s+/g, '')).toLowerCase()).join("");

    console.log("lowercase Result", lowerCaseText);

    return (lowerCaseText?.includes("government") || lowerCaseText?.includes("republicof") || false) && (lowerCaseText?.includes("nationalid") || lowerCaseText?.includes("card") || false);
}
