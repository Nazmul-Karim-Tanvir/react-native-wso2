import { StyleSheet, Text, View } from "react-native";
import React from "react";
import Modal from "react-native-modal";
import Icon from "react-native-vector-icons/Entypo";

import { TouchableOpacity } from "react-native";
import { FontStyle } from "../../assets/styles/commonStyles";
export default function ModalComponent({visible, hideModal, position = "center", content, containerStyle, title}) {

    const getPositionStyle = () => {
        if (position === "bottom") {
            return {
                ...styles.modalContainer,
                width: "100%",
                marginBottom: 0,
                alignSelf: "center",
                bottom: 0,
                paddingBottom: 10,
                position: "absolute",
                borderTopLeftRadius: 16,
                borderTopRightRadius: 16,
            };
        } else if (position === "top") {
            return {
                ...styles.modalContainer,
                width: "100%",
                alignSelf: "center",
                marginTop: 0,
                top: 0,
                position: "absolute",
            };
        } else {
            return {
                ...styles.modalContainer,
                margin: 10,
                alignSelf: "center",
                justifyContent: "center",
            };
        }
    };


    return (
            <View style={styles.container}>
                <Modal
                    isVisible={visible}
                    onBackdropPress={hideModal}
                    onModalHide={hideModal}
                    animationIn={position === "center" ? "fadeIn" : "slideInUp"}
                    animationOut={position === "center" ? "fadeOut" : "slideOutDown"}
                    style={{ justifyContent: "center", margin: 0 }}
                >
                    <View style={[getPositionStyle(), containerStyle]}>
                        <View style={styles.modalTitleContainer}>
                            <Text style={styles.modalTitleText}>{title}</Text>
                            <View style={styles.iconButtonContainer}>
                                <TouchableOpacity style={styles.iconContainer} onPress={hideModal}>
                                    <Icon name="cross" size={24} />
                                </TouchableOpacity>
                            </View>
                        </View>
                        {content}
                    </View>
                </Modal>
            </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    modalContainer: {
        backgroundColor: "#fff",
        borderRadius: 8,
        maxHeight: "90%", // Ensure the modal doesn't exceed the screen height
        alignItems: "center",
    },
    iconButtonContainer: {
        borderWidth: 1,
        padding: 1,
        borderRadius: 8,
    },
    iconContainer: {
        borderWidth: 1,
        borderRadius: 8,
        borderColor: "#e5e7eb",
    },
    modalTitleContainer: {
        width: "100%",
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        borderBottomWidth: 2,
        borderBottomColor: "#e5e7eb",
        paddingVertical: 12,
        paddingHorizontal: 12,
    },
    modalTitleText: {
        fontSize: 24,
        fontWeight: "bold",
        fontFamily: FontStyle?.regular,
    },
});

