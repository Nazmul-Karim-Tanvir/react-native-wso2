import { StyleSheet, Text, View, ScrollView, TouchableOpacity } from "react-native";
import React, { useEffect, useState } from "react";
import { Marquee } from "@animatereactnative/marquee";
import AntDesign from '@expo/vector-icons/AntDesign';
import StockMarketJson from "../../assets/files/StockMarket.json";
import {FontStyle} from "../../assets/styles/commonStyles";

export default function MarqueeComponent() {
  const [speed,setSpeed] = useState(0.4);

  const increaseSpeed = ()=>{
    if(speed<2){
      setSpeed(speed+0.1);
    }
  }

  const lowerSpeed = ()=>{
    if(speed>0.1){
      setSpeed(speed-0.1)
    }
  }

  const stop=()=>{
    setSpeed(0);
  }

  return (
    <View style={styles.container}>
      {/*<View style={{*/}
      {/*  position: 'absolute',*/}
      {/*  right: 0,*/}
      {/*  top: 0,*/}
      {/*  backgroundColor: 'white',*/}
      {/*}}>*/}
      {/*  <TouchableOpacity onPress={increaseSpeed}>*/}
      {/*    <Text>+</Text>*/}
      {/*  </TouchableOpacity>*/}
      {/*  <TouchableOpacity onPress={lowerSpeed}>*/}
      {/*    <Text>-</Text>*/}
      {/*  </TouchableOpacity>*/}
      {/*  <TouchableOpacity onPress={stop}>*/}
      {/*    <Text>||</Text>*/}
      {/*  </TouchableOpacity>*/}
      {/*</View>*/}
      <Marquee spacing={20} speed={speed}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.contentContainer}
        >
          {StockMarketJson.map((item, index) => (
            <View key={index} style={styles.singleItemContainer}>
            <View style={styles.percentageContainer}>
              <Text style={styles.text}>{item.trading_code}</Text>
              <Text style={styles.text}>{item.last_trading_price}</Text>
            </View>
            <View style={{...styles.percentageContainer,justifyContent:"center"}}>

              {item.indicator==="Down"?<AntDesign name="arrowdown" size={12} color="red" />:<AntDesign name="arrowup" size={12} color="#11cd04" />}
              <Text style={styles.text}>{item.change}</Text>
              <Text style={{...styles.text,textAlign:"center"}}>{item.change_percent}</Text>
            </View>
            </View>

          ))}
        </ScrollView>
      </Marquee>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    backgroundColor: "#FFFFFFD9",
    paddingVertical: 5,
    justifyContent: "center",
    borderWidth:1,
    borderColor:"rgba(211,211,211,0.5)"
  },
  contentContainer: {
    gap:10,
    flexDirection: "row",
    alignItems: "center",
  },
  singleItemContainer:{
    gap:3
  },
  percentageContainer:{
    flexDirection:"row",
    gap:3,
    alignItems:"center",
    justifyContent:"center"
  },
  text: {
    textAlign:"center",
    fontSize: 12,
    fontWeight:"600",
    fontFamily: FontStyle.medium,
    lineHeight: 14,
  },
});
