import React, { forwardRef, useState } from "react";
import { StyleSheet, View } from "react-native";
import {MD3TypescaleKey, TextInput} from "react-native-paper";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import moment from "moment";
import { Colors } from "../../assets/styles/colors";
import ModalSelector from "react-native-modal-selector";
import { AntDesign } from "@expo/vector-icons";
import { FontStyle } from "../../assets/styles/commonStyles";

const PTextInput = forwardRef(function PTextInput(props, ref) {
  const {
    value,
    onChange,
    label,
    leftIcon = null,
    rightIcon = null,
    rightIconPress = () => {},
    leftIconPress = () => {},
    placeholder,
    readOnly=false,
    type,
    date,
    inputTextStyles,
    keyboardType = "default",
    style,
  } = props;
  const [selectedDate, setSelectedDate] = useState(
    moment().format("DD-MM-YYYY")
  );
  const handleDateConfirm = (date) => {
    setSelectedDate(moment(date).format("DD-MM-YYYY"));
    rightIconPress();
  };
  return (
    <View style={[styles.container, style]}>
      <DateTimePickerModal
        isVisible={date}
        mode="date"
        date={
          selectedDate
            ? moment(selectedDate, "DD-MM-YYYY").toDate()
            : new Date()
        }
        onConfirm={handleDateConfirm}
        onCancel={rightIconPress}
      />
      {type === "date" ? (
        <TextInput
          mode="outlined"
          value={selectedDate}
          onChangeText={onChange}
          label={label}
          placeholder={placeholder}
          theme={{ colors: { primary: "black", background: "transparent" }, roundness: 8 }}
          style={{
            width: "100%",
            fontSize: 18,
            alignContent: "center",
            fontFamily: FontStyle.medium,
            lineHeight: 20
          }}
          contentStyle={{fontFamily: FontStyle.medium, marginTop: 2, marginBottom: 2, lineHeight: 30}}
          dense
          right={
            rightIcon ? (
              <TextInput.Icon
                icon={rightIcon}
                size={26}
                onPress={rightIconPress}
              />
            ) : null
          }
          readOnly={readOnly}
        />
      ) : type === "textarea" ? (
        <TextInput
          mode="flat"
          value={value}
          onChangeText={onChange}
          label={label}
          multiline
          numberOfLines={3}
          theme={{ colors: { primary: "black", background: "transparent" }, roundness: 8}}
          style={{
            width: "100%",
            fontSize: 18,
            backgroundColor: readOnly ? "#e2e8f0" : "transparent",
            alignContent: "center",
            fontFamily: FontStyle.medium,
            lineHeight: 20
          }}
          contentStyle={{fontFamily: FontStyle.medium, marginTop: 6, marginBottom: 2, lineHeight: 20}}
          dense
          keyboardType="default"
          left={
            leftIcon ? (
              <TextInput.Icon
                icon={leftIcon}
                size={26}
                onPress={leftIconPress}
              />
            ) : null
          }
          right={
            rightIcon ? (
              <TextInput.Icon
                icon={rightIcon}
                size={26}
                onPress={rightIconPress}
              />
            ) : null
          }
          readOnly={readOnly}
        />
      ) : type === "select" ? (
        <ModalSelector
          data={props.options}
          supportedOrientations={["landscape"]}
          accessible={true}
          scrollViewAccessibilityLabel={"Scrollable options"}
          cancelButtonAccessibilityLabel={"Cancel Button"}
          onChange={(option) => {
            onChange(option.label);
          }}
          style={{ width: "100%" }}
          animationType="fade"
        >
          <TextInput
            {...props}
            ref={ref}
            value={value}
            mode="flat"
            theme={{ colors: { primary: "black", background: "transparent" }, roundness: 8 }}
            editable={false}
            label={label}
            placeholder={placeholder}
            style={{
              width: "100%",
              fontSize: 18,
              backgroundColor: readOnly ? "#e2e8f0" : "transparent",
              alignContent: "center",
              fontFamily: FontStyle.medium,
              lineHeight: 20
            }}
            contentStyle={{fontFamily: FontStyle.medium, marginTop: 2, marginBottom: 2, lineHeight: 30}}
            dense
            right={<AntDesign name={"caretdown"} size={26} color="#000" />}
          />
        </ModalSelector>
      ) : (
            <TextInput
                {...props}
                ref={ref}
                mode="flat"
                value={value}
                onChangeText={onChange}
                label={label}
                placeholder={placeholder}
                theme={{
                  colors: { primary: "black", background: "transparent" },
                  roundness: 0
                }}
                style={{
                  width: "100%",
                  fontSize: 18,
                  backgroundColor: "transparent",
                  alignContent: "center",
                  fontFamily: FontStyle.medium,
                  lineHeight: 20,
                }}
                contentStyle={{
                  fontFamily: FontStyle.medium,
                  color: readOnly ? "#a8a8a8" : "#000",
                  marginTop: 2, marginBottom: 2,
                  lineHeight: 24}}
                dense
                keyboardType={keyboardType}
                left={
                  leftIcon ? (
                      <TextInput.Icon
                          icon={() => leftIcon}
                          size={15}
                          onPress={leftIconPress}
                          style={{marginStart: -8, backgroundColor: "#CC0A13", borderRadius: 4, marginBottom: 0}}
                      />
                  ) : null
                }
                right={
                  rightIcon ? (
                      <TextInput.Icon
                          icon={() => rightIcon}
                          size={26}
                          color="#000"
                          onPress={rightIconPress}
                      />
                  ) : null
                }
                readOnly={readOnly}
            />
          // </View>

      )}
    </View>
  );
});

export default PTextInput;

const baseContainerStyle = {
  flexDirection: "row",
  width: "100%",
  alignItems: "center",
};
const textField = {
  flex: 1,
  fontSize: 16,
  fontFamily: FontStyle?.regular,
};

const styles = StyleSheet.create({
  container: {
    ...baseContainerStyle,
  },
  readOnlyContainer: {
    ...baseContainerStyle,
    backgroundColor: "#F3E0E0",
  },
  textField: {
    ...textField,
  },
  readOnlyInput: {
    ...textField,
    backgroundColor: "#F3E0E0",
  },
  iconContainer: {
    backgroundColor: "red",
    borderRadius: 8,
    padding: 8,
    marginLeft: 0,
  },
  leftIconTextField: {
    ...textField,
    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
  },
  leftIconContainer: {
    height: 50,
    borderTopLeftRadius: 8,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#98A1B3",
    paddingVertical: 8,
    backgroundColor: Colors.primary,
  },
});
