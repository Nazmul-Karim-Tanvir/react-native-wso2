import { useState, useEffect, useRef } from 'react';
import { Text, View, Platform } from 'react-native';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { router } from 'expo-router';
import asyncStorage from "@react-native-async-storage/async-storage/src/AsyncStorage";

// Notification handler config
Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
    }),
});

async function registerForPushNotificationsAsync() {
    let token;

    if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('myNotificationChannel', {
            name: 'Default Channel',
            importance: Notifications.AndroidImportance.MAX,
            vibrationPattern: [0, 250, 250, 250],
            lightColor: '#FF231F7C',
        });
    }

    if (Device.isDevice) {
        const { status: existingStatus } = await Notifications.getPermissionsAsync();
        let finalStatus = existingStatus;
        if (existingStatus !== 'granted') {
            const { status } = await Notifications.requestPermissionsAsync();
            finalStatus = status;
        }
        if (finalStatus !== 'granted') {
            alert('Failed to get push token for push notification!');
            return;
        }
        try {
            const projectId = Constants?.expoConfig?.extra?.eas?.projectId ?? Constants?.easConfig?.projectId;
            if (!projectId) {
                throw new Error('Project ID not found');
            }
            token = (await Notifications.getExpoPushTokenAsync({projectId})).data;
            console.log('Expo Push Token:', token);
        } catch (e) {
            token = `${e}`;
        }
    } else {
        alert('Must use physical device for Push Notifications');
    }
    return token;
}

export default function PushNotification() {
    const [expoPushToken, setExpoPushToken] = useState('');
    const [channels, setChannels] = useState<Notifications.NotificationChannel[]>([]);
    const [notification, setNotification] = useState<
        Notifications.Notification | undefined
    >(undefined);

    // Ref ensures we only process the "cold start" notification once
    const hasHandledInitial = useRef(false);

    // --- 1. Handle cold start ---
    // useEffect(() => {
    //     (async () => {
    //         if (!hasHandledInitial.current) {
    //             const response = await Notifications.getLastNotificationResponseAsync();
    //
    //             if (response?.notification?.request?.content?.data?.screen) {
    //                 const data = response.notification.request.content.data;
    //                 console.log('Cold start navigation:', data);
    //
    //                 // Use replace so it doesn’t block future navigations
    //                 router.replace({
    //                     pathname: data.screen, // e.g. "/details"
    //                     params: data.params || {},
    //                 });
    //             }
    //
    //             hasHandledInitial.current = true; // ✅ ensure we do this only once
    //         }
    //     })();
    // }, []);

    // --- 2. Handle taps when the app is running (foreground / background) ---
    useEffect(() => {
        registerForPushNotificationsAsync().then(token => token && setExpoPushToken(token));

        if (Platform.OS === 'android') {
            Notifications.getNotificationChannelsAsync().then(value => setChannels(value ?? []));
        }

        const responseSubscription =
            Notifications.addNotificationResponseReceivedListener(async response => {
                const data = response.notification.request.content.data;
                if (data?.screen) {
                    router.push({
                        pathname: data.screen,
                        params: data.params || {},
                    });
                    await asyncStorage.setItem("RedirectTo", data.web_redirect);
                }
            });

        const notificationSubscription = Notifications.addNotificationReceivedListener(note => {
            console.log('Foreground notification received:', note);
            setNotification(note);
        });

        return () => {
            responseSubscription.remove();
            notificationSubscription.remove();
        };
    }, []);

    // --- UI ---
    return (
        <View style={{ display: "none" }}>
            {/*<Text>Your expo push token: {expoPushToken}</Text>*/}
            {/*<Text>{`Channels: ${JSON.stringify(channels.map(c => c.id))}`}</Text>*/}
            {/*<View style={{ alignItems: 'center', justifyContent: 'center' }}>*/}
            {/*    <Text>Title: {notification?.request.content.title} </Text>*/}
            {/*    <Text>Body: {notification?.request.content.body}</Text>*/}
            {/*    <Text>Data: {notification && JSON.stringify(notification.request.content.data)}</Text>*/}
            {/*</View>*/}
        </View>
    );
}
