import React, {useState, useRef} from "react";
import {Text, View, StyleSheet, Platform} from "react-native";
import {Camera} from "react-native-vision-camera-face-detector";
import {
    useCameraDevice
} from "react-native-vision-camera";
import {BlinkAndExpression} from "./BlinkAndExpression";
import ProgressBar from "./ProgressBarCircular";
import ekycStore from "../../store/ekyc-store";
import {uriToBase64} from "../../utility/utility-functions";

const FaceDetectionComponent = ({style}) => {
    const camera = useRef(null)
    const snapFlag = useRef(true)
    const [faceDetected, setFaceDetected] = useState(false);
    const [steps, setSteps] = useState(0);
    const [CONSEC_FRAMES, setCONSEC_FRAMES] = useState(3);
    const {onChangeEkyc3, ekyc3} = ekycStore();
    const leftEyeClosedFrames = useRef(0);
    const rightEyeClosedFrames = useRef(0);
    const blinkInProgress = useRef(false);

    const faceDetectionOptions = {
        performanceMode: "fast",
        classificationMode: "all",
        landmarkMode: "all",
        trackingEnabled: true,
    };
    const device = useCameraDevice("front");

    const takePhoto = async () => {
        const snapshot = await camera.current.takeSnapshot({quality: 100});
        console.log("photoPath in snapShot:", snapshot?.path);
        const base64Image = await uriToBase64(snapshot?.path);

        onChangeEkyc3({
            photoPath: (Platform.OS === "android" ? "file://" : "") + snapshot?.path,
            photoBase64: base64Image
        });
    };

    function handleFacesDetection(faces, frame) {
        faces.forEach(async (face, index) => {
            setFaceDetected(true);
            BlinkAndExpression(face, CONSEC_FRAMES, leftEyeClosedFrames, rightEyeClosedFrames, blinkInProgress, onChangeEkyc3, ekyc3);

            if (ekyc3?.blinkCount === 1) {
                snapFlag.current = true;
                setSteps(1);
                setCONSEC_FRAMES(2);
                console.log("Blink1");
            }
            if (ekyc3?.blinkCount === 2) {
                setSteps(2);
                console.log("Blink2");
            }
            if (ekyc3?.blinkCount >= 2 && face.smilingProbability > 0.95 && snapFlag.current) {
                console.log(face.smilingProbability);
                onChangeEkyc3({faceExpression: "smiling"});
                snapFlag.current = false; // Prevent multiple calls
                await takePhoto();
                setSteps(3);
            }
        });

        if (faces.length === 0) {
            setSteps(0)
            setFaceDetected(false);
            setCONSEC_FRAMES(3);
            snapFlag.current = true;
            onChangeEkyc3({
                photoBase64: "",
                blinkCount: 0,
                faceExpression: '',
                photoPath: '',
                photoVerificationResult: ''
            })
        }
    }

    if (device === null) return <Text>No Device Found</Text>;

    return (
        <>
            <Camera
                ref={camera}
                style={style}
                isActive={true}
                device={device}
                faceDetectionCallback={handleFacesDetection}
                faceDetectionOptions={faceDetectionOptions}
                photo={true}
                photoQualityBalance="speed"
            />
            {faceDetected && (
                <View style={styles.progressOverlay}>
                    <ProgressBar
                        currentStep={steps}
                        totalStep={3}
                        tintColor="#008000"
                        backgroundColor="#87080EB0"
                    />
                </View>
            )}
        </>
    );
};

export default FaceDetectionComponent;

const styles = StyleSheet.create({
    progressOverlay: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "transparent", // Ensure it doesn't block the camera
    },
});
