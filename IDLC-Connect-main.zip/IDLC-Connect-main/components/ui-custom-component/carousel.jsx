import React, { useState } from "react";
import {Image, StyleSheet, View, Dimensions, Text} from "react-native";
import { SwiperFlatList } from "react-native-swiper-flatlist";

const { width } = Dimensions.get("window");

export default function Carousel({options}) {
    const [activeIndex, setActiveIndex] = useState(0);

    const renderItem = ({ item }) => (
        <View style={styles.imageWrapper}>
            <Image source={item.image} style={styles.image} />
        </View>
    );

    const renderCustomPagination = <View style={styles.paginationContainer}>
        {options.map((_, index) => (
            <View
                key={index}
                style={[
                    styles.dot,
                    activeIndex === index ? styles.activeDot : styles.inactiveDot,
                ]}
            />
        ))}
    </View>;

    return (
        <View style={styles.innerContainer}>
            <SwiperFlatList
                autoplay
                autoplayDelay={3}
                autoplayLoop
                data={options}
                renderItem={renderItem}
                onChangeIndex={({ index }) => setActiveIndex(index)}
                keyExtractor={(item) => item.id}
            />
            {renderCustomPagination}
        </View>
    );
}

const styles = StyleSheet.create({
    innerContainer: {
        width: "100%",
        backgroundColor: "#FFFFFF",
        justifyContent: "flex-end",
    },
    imageWrapper: {
        width: width,
        height: 200,
        marginBlock: 10
    },
    image: {
        width: "100%",
        height: 200,
        resizeMode: "contain",
    },
    paginationContainer: {
        position: "absolute",
        bottom: 10,
        left: 0,
        right: 0,
        flexDirection: "row",
        justifyContent: "center",
    },
    dot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        marginHorizontal: 4,
    },
    activeDot: {
        backgroundColor: "#ED1C24",
        width: 10,
        height: 10,
        borderRadius: 6,
    },
    inactiveDot: {
        width: 10,
        height: 10,
        backgroundColor: "transparent",
        borderColor: "#ED1C24",
        borderWidth: 1,
        borderRadius: 6,
    },
});
