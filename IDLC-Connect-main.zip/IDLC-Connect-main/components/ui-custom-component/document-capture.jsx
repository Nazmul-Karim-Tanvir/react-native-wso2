import React, {useState, useRef} from "react";
import {View, StyleSheet, TouchableOpacity, Image, Text, Dimensions} from "react-native";
import {Camera, CameraView} from "expo-camera";
import * as MediaLibrary from "expo-media-library";
import {AntDesign, Feather, MaterialIcons} from "@expo/vector-icons";
import {GestureHandlerRootView} from "react-native-gesture-handler";

const {width, height} = Dimensions.get("window");

const DocumentCapture = ({handleClose, handleComplete}) => {
        const [hasPermission, setHasPermission] = useState(null);
        const [capturedPhoto, setCapturedPhoto] = useState(null);
        const [cameraReady, setCameraReady] = useState(false);
        const cameraRef = useRef(null);
        const [editImage, setEditImage] = useState(false);
        const [flashMode, setFlashMode] = useState('off');

        const requestPermissions = async () => {
            const cameraStatus = await Camera.requestCameraPermissionsAsync();
            const mediaStatus = await MediaLibrary.requestPermissionsAsync();
            setHasPermission(cameraStatus.status === "granted" && mediaStatus.status === "granted");
        };

        const handleCapture = async () => {
            if (cameraRef.current) {
                const photo = await cameraRef.current.takePictureAsync();
                setCapturedPhoto(photo.uri);
            }
        };

        const handleCompleteCapture = async () => {
            if (capturedPhoto) {
                handleComplete(capturedPhoto);
                setCapturedPhoto(null); // Reset photo after saving
                handleClose();
            }
        };

        React.useEffect(() => {
            (async () => await requestPermissions())()
        }, []);

        if (hasPermission === null) return <Text>Requesting camera permission...</Text>;
        if (hasPermission === false) return <Text>No access to camera</Text>;

        return (
            <View style={styles.container}>
                {capturedPhoto ? (
                    editImage ? <View style={styles.previewContainer}>
                        <Image source={{uri: capturedPhoto}} style={styles.previewImage}/>
                        <View style={styles.buttonContainer}>
                            <TouchableOpacity style={styles.captureButton}>
                                <AntDesign name={'check'} size={30} color={'#fff'}/>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.captureButton} onPress={() => setEditImage(false)}>
                                <AntDesign name={'close'} size={30} color='#fff'/>
                            </TouchableOpacity>
                        </View>
                    </View> : <GestureHandlerRootView style={styles.previewContainer}>
                        <Image source={{uri: capturedPhoto}} style={styles.previewImage}/>
                        <View style={styles.buttonContainer}>
                            <TouchableOpacity style={styles.captureButton} onPress={() => setCapturedPhoto(null)}>
                                <AntDesign name={'reload1'} size={30} color={'#fff'}/>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.captureButton} onPress={handleCompleteCapture}>
                                <AntDesign name={'check'} size={30} color={'#fff'}/>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={styles.captureButton}
                                onPress={() => setEditImage(true)}
                            >
                                <Feather name={'edit'} size={30} color={'#fff'}/>
                            </TouchableOpacity>
                        </View>
                    </GestureHandlerRootView>
                ) : (
                    <CameraView
                        flash={flashMode}
                        autofocus
                        style={styles.camera}
                        ref={cameraRef}
                        onCameraReady={() => setCameraReady(true)}
                    >
                        <View style={styles.cameraWindowContainer}>
                            <View style={styles.cameraWindow}></View>
                        </View>
                        <View style={styles.cameraOverlay}>
                            <TouchableOpacity style={[styles.captureButton, {backgroundColor: 'rgba(0,0,0,0.3)'}]}
                                              onPress={() => setFlashMode(flashMode === 'off' ? 'auto' : flashMode === 'auto' ? 'on' : 'off')}>
                                <MaterialIcons name={flashMode === 'off' ? 'flash-off' : flashMode === 'auto' ? 'flash-auto' : 'flash-on'} size={30} color='#fff'/>
                            </TouchableOpacity>
                            <TouchableOpacity style={[styles.captureButton, {backgroundColor: 'rgba(0,0,0,0.3)'}]}
                                              onPress={handleCapture}>
                                <Feather name={'camera'} size={30} color='#fff'/>
                            </TouchableOpacity>
                            <TouchableOpacity style={[styles.captureButton, {backgroundColor: 'rgba(0,0,0,0.3)'}]}
                                              onPress={handleClose}>
                                <AntDesign name={'close'} size={30} color='#fff'/>
                            </TouchableOpacity>
                        </View>
                    </CameraView>
                )
                }
            </View>
        )
            ;
    }
;

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    camera: {
        flex: 1,
    },
    cameraWindowContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 100,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
    },
    cameraWindow: {
        width: Dimensions.get("window").width-30,
        height: (Dimensions.get("window").width-30) * 9 / 16,
        borderWidth: 4,
        borderColor: '#fff',
    },
    cameraOverlay: {
        flex: 1,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "flex-end",
        marginBottom: 20,
    },
    captureButton: {
        marginInline: 5,
        width: 70,
        height: 70,
        backgroundColor: "rgba(255,255,255,0.1)",
        borderRadius: 35,
        justifyContent: "center",
        alignItems: "center",
        borderWidth: 3,
        borderColor: "#fff",
    },
    captureButtonText: {
        fontSize: 18,
        fontWeight: "bold",
    },
    previewContainer: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#000",
    },
    previewImage: {
        width: width - 40,
        height: (width - 40) * 1.5,
        resizeMode: "contain",
        borderRadius: 10,
    },
    buttonContainer: {
        flexDirection: "row",
        marginTop: 20,
    },
    button: {
        padding: 10,
        backgroundColor: "#6200ee",
        marginHorizontal: 10,
        borderRadius: 5,
    },
    buttonText: {
        color: "#fff",
        fontSize: 16,
    },
    cropBox: {
        position: "absolute",
        borderWidth: 2,
        borderColor: "red",
    },
    cropButton: {
        position: "absolute",
        bottom: 20,
        backgroundColor: "blue",
        padding: 10,
        borderRadius: 5,
    },
});

export default DocumentCapture;