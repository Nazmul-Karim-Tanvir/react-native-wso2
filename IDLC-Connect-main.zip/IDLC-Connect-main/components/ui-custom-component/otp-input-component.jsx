import React, {useEffect, useRef, useState} from 'react';
import CButton from "./paper-button";
import {StyleSheet, Text, View} from "react-native";
import {OtpInput} from "react-native-otp-entry";
import { FontStyle } from '../../assets/styles/commonStyles';
import {Colors} from "../../assets/styles/colors";

const OtpInputComponent = ({otpRef,digits=6, value, onValueChange, onFilled, timeoutInMin=3, onOtpResend=()=>{}}) => {
    const initialTime = timeoutInMin * 60; // Total duration in seconds
    const [timeLeft, setTimeLeft] = useState(initialTime); // State for time left
    const [isExpired, setIsExpired] = useState(false);
    const startTimeRef = useRef(Date.now()); // Reference to the start time
    // const otpRef = useRef(null);

    useEffect(() => {
        const interval = setInterval(() => {
            if(!isExpired){
                const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000); // Calculate elapsed time
                const remaining = initialTime - elapsed;

                if (remaining >= 0) {
                    setTimeLeft(remaining);
                } else {
                    clearInterval(interval);
                    setIsExpired(true);
                }
            }
        }, 1000);

        return () => clearInterval(interval); // Cleanup interval
    }, [isExpired]);

    const formatTime = (seconds) => {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
    };

    const resendOtp = () => {
        setTimeLeft(initialTime);
        setIsExpired(false);
        startTimeRef.current = Date.now();
        onOtpResend();
    };

    return (
        <View style={{width:'100%'}}>
            <OtpInput
                ref={otpRef}
                value={value}
                onTextChange={onValueChange}
                numberOfDigits={digits}
                focusColor={Colors.primary}
                blurOnFilled
                onFilled={onFilled}

                theme={{
                    pinCodeContainerStyle: {width: 50, height: 50, marginInline: 2, borderWidth: 0, borderBottomWidth: 1, borderRadius: 0},
                    containerStyle: {justifyContent: 'center'},
                }}
            />
            <View style={{justifyContent: 'center', alignItems: 'center', marginTop: 20}}>
                {isExpired ?
                    <CButton mode='link' onPress={resendOtp} >Resend OTP</CButton> :
                    <Text style={styles.timerText}>{`OTP expires in: ${formatTime(timeLeft)}s`}</Text>
                }
            </View>
        </View>
    );
};

export default OtpInputComponent;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f8f8ff',
    },
    timerText: {
        fontSize: 18,
        marginBottom: 20,
        color: '#333',
        fontFamily:FontStyle?.light

    },
});
