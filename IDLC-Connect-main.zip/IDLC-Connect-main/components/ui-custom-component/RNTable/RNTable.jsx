import React, {useCallback, useState} from 'react';
import {StyleSheet, Text, TouchableOpacity, View} from "react-native";
import {FlashList} from "@shopify/flash-list";
import Icon from "react-native-vector-icons/Ionicons";
import { FontStyle } from '../../../assets/styles/commonStyles';

const RnTable = ({rows, columns, onClick, isCollapsable=true}) => {

    const [activeSections, setActiveSections] = useState([]);

    const toggleSection = (section) => {
        console.log(activeSections);
        setActiveSections((prevSections) =>
            prevSections.includes(section)
                ? prevSections.filter((sec) => sec !== section)
                : [...prevSections, section]
        );
    };

    const renderItem = useCallback(({item, index}) => <View key={index} style={{
        borderBottomWidth: (index === rows?.length - 1) ? 0 : 1,
        borderColor: '#fff'
    }}>
        <TouchableOpacity style={{padding: 10}} onPress={() => isCollapsable ? toggleSection(index) : onClick(item, index)}>
            <View style={{flexDirection: 'column'}}>
                {
                    columns.filter((a) => a?.align === "full" && !a?.collapsable)?.map((a, idx) => !a?.isHidden && <View key={idx?.toString()} style={{...styles.accountDetails, marginTop: idx === 0 ? 0 : 5}}>
                        {!a?.hideHeader && <Text style={styles.accountTitle}>{a?.header}</Text>}
                        {a?.cell ? a?.cell(item[a?.accessor]) : <Text style={{...styles.accountSubTitle}}>{item[a?.accessor]}</Text>}
                    </View>)
                }
            </View>
            <View style={styles.accountItem}>
                <View style={{flexDirection: 'column'}}>
                    {
                        columns.filter((a) => a?.align === "left" && !a?.collapsable)?.map((a, idx) => !a?.isHidden && <View key={idx?.toString()} style={{...styles.accountDetails, marginTop: idx === 0 ? 0 : 5}}>
                            {!a?.hideHeader && <Text style={styles.accountTitle}>{a?.header}</Text>}
                            {a?.cell ? a?.cell(a?.accessor ? item[a?.accessor] : item) : <Text style={{...styles.accountSubTitle}}>{item[a?.accessor]}</Text>}
                        </View>)
                    }
                </View>

                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <View style={{flexDirection: 'column', marginRight: 10}}>
                        {
                            columns.filter((a) => a?.align === "right" && !a?.collapsable)?.map((a, idx) => !a?.isHidden && <View key={idx?.toString()} style={{...styles.accountDetails, marginTop: idx === 0 ? 0 : 5}}>
                                    {!a?.hideHeader && <Text style={styles.accountTitle}>{a?.header}</Text>}
                                    {a?.cell ? a?.cell(a?.accessor ? item[a?.accessor] : item) : <Text style={{...styles.accountSubTitle}}>{item[a?.accessor]}</Text>}
                                </View>
                            )
                        }
                    </View>
                    {isCollapsable && <Icon
                        name={activeSections.includes(index) ? "chevron-up-outline" : "chevron-down-outline"}
                        size={24}
                        color="#000"
                    />}
                </View>
            </View>

        </TouchableOpacity>
        {isCollapsable && <View style={{display: activeSections.includes(index) ? "block" : "none"}}>
            <View style={styles.collapsibleContent}>
                {
                    columns.filter((a) => a?.align === "full" && a?.collapsable)?.map((a, idx) => !a?.isHidden &&
                        <View key={idx?.toString()} style={{...styles.accountDetails, marginTop: idx === 0 ? 0 : 5}}>
                            <View style={styles.collapsibleAccountDetails}>
                                {!a?.hideHeader && <Text style={styles.accountTitle}>{a?.header}</Text>}
                                {a?.cell ? a?.cell(a?.accessor ? item[a?.accessor] : item) :
                                    <Text style={{...styles.accountSubTitle}}>{item[a?.accessor]}</Text>}
                            </View>
                        </View>)
                }
                <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                    <View style={{flexDirection: 'column', justifyContent: 'center'}}>
                        {
                            columns.filter((a) => a?.align === "left" && a?.collapsable)?.map((a, idx) => !a?.isHidden &&
                                <View key={idx?.toString()}
                                      style={{...styles.accountDetails, marginTop: idx === 0 ? 0 : 5}}>
                                    <View style={styles.collapsibleAccountDetails}>
                                        {!a?.hideHeader && <Text style={styles.accountTitle}>{a?.header}</Text>}
                                        {a?.cell ? a?.cell(a?.accessor ? item[a?.accessor] : item) :
                                            <Text style={{...styles.accountSubTitle}}>{item[a?.accessor]}</Text>}
                                    </View>
                                </View>)
                        }
                    </View>
                    <View style={{flexDirection: 'column', justifyContent: 'flex-end'}}>
                        {
                            columns.filter((a) => a?.align === "right" && a?.collapsable)?.map((a, idx) => !a?.isHidden &&
                                <View key={idx?.toString()}
                                      style={{...styles.accountDetails, marginTop: idx === 0 ? 0 : 5}}>
                                    <View style={styles.collapsibleAccountDetails}>
                                        {!a?.hideHeader && <Text style={styles.accountTitle}>{a?.header}</Text>}
                                        {a?.cell ? a?.cell(a?.accessor ? item[a?.accessor] : item) :
                                            <Text style={{...styles.accountSubTitle}}>{item[a?.accessor]}</Text>}
                                    </View>
                                </View>
                            )
                        }
                    </View>
                </View>
            </View>
        </View>}
    </View>, [activeSections])

    return (
        <View style={{flex: 1, minHeight: 100}}>
            <FlashList
                renderItem={renderItem}
                data={rows}
                estimatedItemSize={100}
                getItemType={(index) => index.toString()}
                extraData={activeSections}
            />
        </View>
    );
};

export default RnTable;

const styles = StyleSheet.create({
    previewDataTitle: {
        backgroundColor:'#fff',
        paddingVertical: 5,
        paddingHorizontal: 10,
        borderRadius: 10,
        marginTop: 10,
        marginBottom: 5,
    },
    previewDataContent: {
        paddingVertical: 5,
        paddingHorizontal: 10,
        borderBottomColor: '#f1f1f1',
        flexDirection: 'row',
        alignItems: 'center'
    },
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    accountSection: {
        margin: 20,
        backgroundColor: '#fff',
        borderRadius: 10,
        marginBottom: 0,
    },
    accountItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    accountDetails: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    collapsibleAccountDetails: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'center',
        marginBottom: 8
    },
    accountTitle: {
        fontFamily: FontStyle?.regular,
        fontSize: 12,
        color: '#333',
        lineHeight: 14,
    },
    accountSubTitle: {
        fontFamily: FontStyle?.regular,
        fontSize: 14,
        fontWeight: '500',
        lineHeight: 16,
    },
    accountButton: {
        backgroundColor: '#007310',
        borderRadius: 5,
        padding: 5,
        marginRight: 10,
    },
    accountButtonText: {
        fontFamily: FontStyle?.regular,
        color: '#fff',
        fontSize: 12,
        textAlign: 'center',
    },
    actionGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        padding: 10,
        marginHorizontal: 8,
        marginVertical: 0,
        justifyContent: 'center',
    },
    actionButton: {
        width: '23%',
        backgroundColor: '#ffffff',
        padding: 10,
        borderRadius: 10,
        margin: '0.75%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    collapsibleContent: {
        padding: 10,
        backgroundColor: 'rgba(0,0,0,0.03)',
    },
    collapsibleText: {
        fontFamily: FontStyle?.regular,
        fontSize: 14,
        color: '#000000',
    },
    actionText: {
        fontFamily: FontStyle?.regular,
        marginTop: 5,
        fontSize: 8,
        color: '#333',
    },
});
