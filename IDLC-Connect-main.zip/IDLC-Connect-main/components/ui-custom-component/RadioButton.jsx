import * as React from 'react';
import {View, StyleSheet, TouchableOpacity} from 'react-native';
import { RadioButton,Checkbox, Text } from 'react-native-paper';
import { Colors } from '../../assets/styles/colors';
import { FontStyle } from '../../assets/styles/commonStyles';

const CustomRadioButton = ({
    options = [
      { value: 'first', label: 'WhatsApp' },
      { value: 'second', label: 'Email' }
    ],
    initialValue = 'first',
    onChange,
    color = '#000000',
    containerStyle,
    labelStyle,
  }) => {
    const [value, setValue] = React.useState(initialValue);

    const handleChange = (newValue) => {
      setValue(newValue);
      onChange?.(newValue);
    };

    return (
      <View style={[styles.container, containerStyle]}>
        <RadioButton.Group
          onValueChange={handleChange}
          value={value}
        >
          <View style={styles.radioContainer}>
            {options?.map((option) => (
              <TouchableOpacity onPress={() => handleChange(option.value)} key={option.value} style={styles.rowStyle}>
                  <RadioButton.Android value={option.value} color={color} uncheckedColor="#000000" />
                  <Text style={[styles.radioLabel, labelStyle]}>{option.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </RadioButton.Group>
      </View>
    );
  };


  const styles = StyleSheet.create({
    container: {
      padding: 8,
    },
    radioContainer: {
        width: '100%',
      flexDirection: 'row',
      alignItems: 'center',
        justifyContent: 'space-between',
    },
    rowStyle: {
      flexDirection: 'row',
      alignItems: 'center',
      minWidth: 100, // Ensure minimum width for each option
    },
    radioLabel: {
      fontFamily: FontStyle?.medium,
      fontWeight:400,
      fontSize: 20,
      color: Colors.primary
    },
  });

export default CustomRadioButton;
