import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';

import {AntDesign} from "@expo/vector-icons";
import {FontStyle} from "../../assets/styles/commonStyles";
const { width } = Dimensions.get('window');
const CompactMarketInfo = () => {

  const isCompact = width < 350; // Adjust layout for smaller screens

  return (
    <View style={styles.container}>
        <View style={styles.row}>
          <Text style={styles.titleText}>DSEX</Text>
          <View style={styles.row}>
            <AntDesign name='caretup' size={8} color='green' style={{marginRight: 3}} />
            <Text style={styles.valueText}>75.90</Text>
          </View>
        </View>
        <View style={[styles.row, isCompact && styles.compactRow]}>
          <Text style={styles.valueText}>5756.71</Text>
          <Text style={styles.percentageText}>1.70%</Text>
        </View>
        <View style={[styles.marketStatusContainer, isCompact && styles.compactMarketStatus]}>
          <Text style={styles.marketText}>Market:</Text>
          <Text style={[styles.marketText, {color: 'green'}]}>Open</Text>
        </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    // padding: 5,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 0,
    justifyContent:'space-around',
  },
  titleText: {
    fontWeight: '800',
    fontSize: 10,
    marginRight: 5,
    fontFamily: FontStyle.medium,
    lineHeight: 12,
  },
  valueText: {
    fontSize: 10,
    color: '#000000',
    fontWeight:'600',
    fontFamily: FontStyle.medium,
    lineHeight: 12,
  },
  percentageText: {
    fontSize: 10,
    color: '#272324', // Adjust color as needed#272324
    marginLeft: 5,
    fontWeight:'600',
    fontFamily: FontStyle.medium,
    lineHeight: 12,
  },
  marketStatusContainer: {
    flexDirection: 'row',
    backgroundColor: '#DFE9FCA6',
    borderRadius: 5,
    justifyContent: 'center',
    width: width>450? width*0.15 :'auto',
    height:'auto',
    gap:5
  },
  marketText: {
    fontWeight:'bold',
    fontSize: 10,
    color: '#000000',
    marginRight: 5,
    marginLeft:5,
    fontFamily: FontStyle.medium,
    lineHeight: 12,
  },
  compactRow: {
    marginBottom: 0,
  },
  compactMarketStatus: {
    paddingVertical: 2,
    paddingHorizontal: 4,
  },
});

export default CompactMarketInfo;
