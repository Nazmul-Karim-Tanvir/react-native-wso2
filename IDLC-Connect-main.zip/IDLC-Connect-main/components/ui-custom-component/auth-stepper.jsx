import {Dimensions, ScrollView, StyleSheet, Text, View,KeyboardAvoidingView, Platform,FlatList} from "react-native";
import React from "react";
import { AnimatedCircularProgress } from "react-native-circular-progress";
import CButton from "./paper-button";
import { FontStyle } from "../../assets/styles/commonStyles";

export default function AuthStepper(props) {
    const {
        currentStep, setCurrentStep, steps, onStepNext, onStepComplete,
        tintColor='#ffffff',backgroundColor='rgba(255,255,255,0.35)'
    } = props;

    const stepsComplete = Number(currentStep)/Number(steps.length);

    const handlePrevious = () => {
        currentStep > 1 && setCurrentStep(currentStep - 1);
    }
    const handleNext = async () => {
        if(currentStep < steps.length) {
            let success = await onStepNext();
            success && setCurrentStep(currentStep + 1);
        }
        else onStepComplete();
    }

    return (
        <View style={{height: "90%", justifyContent: 'space-between', alignItems: 'center'}}>
            <View style={styles.progressbarContainer}>
                <AnimatedCircularProgress
                    size={60}
                    width={8}
                    fill={stepsComplete*100}
                    tintColor={tintColor}
                    backgroundColor={backgroundColor}
                    style={styles.circularProgress}
                    rotation={0}
                    lineCap='round'
                >
                    {() => (
                        <View style={styles.progressTextContainer}>
                            <Text style={styles.progressText}>{currentStep} of {steps.length}</Text>
                        </View>
                    )}
                </AnimatedCircularProgress>
                <View style={styles.stepsDescription}>
                    <Text style={{...styles.descriptionText,fontSize:20,fontFamily:FontStyle?.regular}}>{steps[currentStep-1].StepName}</Text>
                    {
                        currentStep === steps.length ?
                            <Text style={{...styles.descriptionText,fontSize:14,fontFamily:FontStyle?.regular}}> Previous : {steps[currentStep-2].StepName}</Text> :
                            <Text style={{...styles.descriptionText,fontSize:14,fontFamily:FontStyle?.regular}}> Next : {steps[currentStep].StepName}</Text>
                    }
                </View>
            </View>
            <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{flex: 1}}>
                <ScrollView 
                    contentContainerStyle={{ flexGrow: 1}} 
                    keyboardShouldPersistTaps="handled"
                    showsVerticalScrollIndicator={false}
                    scrollEventThrottle={16}
                >
                    {props.children}
                </ScrollView>
            </KeyboardAvoidingView>

            {/* <View style={{ flex: 1,width:"100%"}}>
                <ScrollView contentContainerStyle={{ flexGrow: 1}}>
                    {props.children}
                </ScrollView>
                <FlatList
                    data={[props.children]}
                    renderItem={({ item }) => item}
                    keyExtractor={() => 'ekyc4'}
                    contentContainerStyle={{ flexGrow: 1 }}
                />
            </View> */}

            <View  style={{paddingInline: 15, width: '100%', flexDirection: 'row'}}>
                {currentStep === 1 ?
                    <CButton onPress={handleNext} id={`NextBtnID`} icon='arrow-right'>Next</CButton> :
                    <>
                        <CButton onPress={handlePrevious} id={`PreviousBtnID`} buttonStyles={{width: '50%', borderTopRightRadius: 0, borderBottomRightRadius: 0,fontFamily:FontStyle?.medium}} icon='arrow-left' leftIcon>Previous</CButton>
                        <CButton onPress={handleNext} id={`NextBtnID`} buttonStyles={{width: '50%', borderTopLeftRadius: 0, borderBottomLeftRadius: 0,fontFamily:FontStyle?.medium}} mode='primary' icon='arrow-right'>{currentStep === steps.length ? "Complete" : "Next"}</CButton>
                    </>
                }
            </View>

        </View>
    );

    
}

const styles = StyleSheet.create({
    progressbarContainer: {
        width: "100%",
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: '#dc2626',
        padding: 10,
    },
    circularProgress: {

    },
    progressTextContainer: {
        position: "absolute",
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: '#dc2626',
        justifyContent: "center",
        alignItems: "center",
    },
    progressText: {
        fontSize: 12,
        fontWeight: "bold",
        color: "#fff",
        fontFamily:FontStyle?.regular

    },
    stepsDescription:{
        gap:4,
        alignItems:"flex-end",
        // justifyContent:"flex-end"
    },
    descriptionText:{
        color:"#fff"
    }
});
