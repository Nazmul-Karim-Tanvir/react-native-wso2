export function BlinkAndExpression(face, CONSEC_FRAMES, leftEyeClosedFrames, rightEyeClosedFrames, blinkInProgress, onChangeEkyc3, ekyc3) {

    const isLeftEyeClosed = face?.leftEyeOpenProbability < 0.20 && face?.leftEyeOpenProbability !== -1;
    const isRightEyeClosed = face?.rightEyeOpenProbability < 0.20 && face?.rightEyeOpenProbability !== -1;

    // Increment closed frames count if either eye is detected as closed
    if (isLeftEyeClosed) {
        leftEyeClosedFrames.current += 1;
    } else {
        leftEyeClosedFrames.current = 0;
    }

    if (isRightEyeClosed) {
        rightEyeClosedFrames.current += 1;
    } else {
        rightEyeClosedFrames.current = 0;
    }

    // Detect a blink if either eye has been below the threshold for enough consecutive frames
    let isBlinkDetected = leftEyeClosedFrames.current >= CONSEC_FRAMES && rightEyeClosedFrames.current >= CONSEC_FRAMES;

    // console.log(CONSEC_FRAMES, leftEyeClosedFrames.current, rightEyeClosedFrames.current, isBlinkDetected, blinkInProgress.current);

    if (isBlinkDetected && !blinkInProgress.current) {
        blinkInProgress.current = true;
        onChangeEkyc3({blinkCount: ekyc3?.blinkCount+1})
        // Reset frame counters after a blink
        leftEyeClosedFrames.current = 0;
        rightEyeClosedFrames.current = 0;
    }
    if (face?.leftEyeOpenProbability >= 0.98 && face?.rightEyeOpenProbability >= 0.98) blinkInProgress.current = false;
}
